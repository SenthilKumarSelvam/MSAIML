"""
Prompt template loader for the LLM generator.
Templates are stored as .txt files in the prompts/ directory.
"""

from pathlib import Path

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"


def load_template(filename: str) -> str:
    """
    Load a prompt template by filename.

    Args:
        filename: Name of the template file (e.g., 'generation_standard.txt').

    Returns:
        Template string with {requirement} placeholder.
    
    Raises:
        FileNotFoundError: If the template file does not exist.
    """
    path = PROMPTS_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Prompt template not found: {path}")
    return path.read_text(encoding="utf-8")
