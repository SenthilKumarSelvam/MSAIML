"""
Main Pipeline Orchestrator
Runs the full LLM-assisted PLC code generation and evaluation framework.

Usage:
    python main.py --task motor_control_low --condition framework
    python main.py --task all --condition framework
    python main.py --summarize
"""

import argparse
import json
import sys
import threading
import queue
import openai
import httpx
from pathlib import Path
from dotenv import load_dotenv

# Load .env file before importing config so env vars are set first
load_dotenv()

# Ensure Unicode output works on Windows terminals (cp1252 → utf-8)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import config
from config import validate_config
from src.normalizer import format_for_prompt
from src.llm_generator import generate_st_code, save_generated_code
from src.rag_retriever import RagRetriever

# Module-level lazy RAG singleton
_rag_lock     = threading.Lock() if True else None
_rag_instance: RagRetriever | None = None

def _get_rag(client=None) -> RagRetriever | None:
    global _rag_instance
    if not config.RAG_ENABLED:
        return None
    with threading.Lock():
        if _rag_instance is None:
            _rag_instance = RagRetriever(
                benchmark_dir=config.BENCHMARK_DIR,
                persist_dir=config.RAG_STORE_DIR,
                openai_client=client,
            )
            _rag_instance.index_tasks()
        return _rag_instance
from src.compiler_feedback import refine_until_compiled
from src.cross_lang_mapper import translate_and_save
from src.evaluator import (
    create_experiment_log,
    compute_bleu,
    compute_semantic_equivalence,
    compute_hallucination_rate,
    compute_statement_coverage,
    save_log,
    load_all_logs,
    summarize_results,
    Timer
)
from src.test_runner import run_test_cases, run_test_cases_with_coverage, compute_functional_correctness, format_test_report
from src.inconsistency_detector import detect_inconsistencies, compare_raw_vs_normalized
from src.llm_judge import check_spec_compliance, format_compliance_report
from src.semantic_refiner import semantic_refinement_loop
from src.gap_detector import detect_requirement_gaps, format_gap_summary


# ─── Load Benchmark Task ──────────────────────────────────────────────────────

def load_task(task_id: str) -> dict:
    task_file = config.BENCHMARK_DIR / f"{task_id}.json"
    if not task_file.exists():
        raise FileNotFoundError(f"Benchmark task not found: {task_file}")
    return json.loads(task_file.read_text(encoding="utf-8"))


def list_tasks() -> list:
    return [p.stem for p in config.BENCHMARK_DIR.glob("*.json")]


# ─── Semantic Equivalence Proxy (shared by framework + direct_llm) ──────────

import xml.etree.ElementTree as _ET_xml
_TC6_NS_SE = "http://www.plcopen.org/xml/tc6_0200"


def _xml_body_output_vars(xml_str: str) -> set:
    """
    Return output variable names found in LD coil bodies or FBD output
    expressions — structural proxy for whether each output is assigned.
    More meaningful than interface-based check (interface always has all vars).
    """
    found = set()
    try:
        root = _ET_xml.fromstring(xml_str)
        # LD: <coil ...><variable>VARNAME</variable></coil>
        for coil in root.iter(f"{{{_TC6_NS_SE}}}coil"):
            for child in coil:
                if child.tag in (f"{{{_TC6_NS_SE}}}variable", "variable"):
                    if child.text and child.text.strip():
                        found.add(child.text.strip().upper())
        # FBD: <variable formalParameter="OUT"><expression>VARNAME</expression></variable>
        for var in root.iter(f"{{{_TC6_NS_SE}}}variable"):
            if var.get("formalParameter", "").upper() == "OUT":
                expr = var.find(f"{{{_TC6_NS_SE}}}expression")
                if expr is not None and expr.text and expr.text.strip():
                    found.add(expr.text.strip().upper())
    except _ET_xml.ParseError:
        pass
    return found


def _compute_se_proxy(translate_result: dict, st_test_results: list, test_cases: list) -> dict:
    """
    Compute semantic equivalence using a structural proxy:
    LD/FBD 'pass' for a test case if ALL expected output variables appear
    in the program body (coil targets in LD / output block expressions in FBD).
    Returns a compute_semantic_equivalence() result dict.
    """
    if not st_test_results or not test_cases:
        return {"score": None, "level": "no_test_cases"}
    try:
        ld_xml  = Path(translate_result["ld"]).read_text(encoding="utf-8")
        fbd_xml = Path(translate_result["fbd"]).read_text(encoding="utf-8")
    except (KeyError, OSError):
        return {"score": None, "level": "translation_missing"}
    ld_vars  = _xml_body_output_vars(ld_xml)
    fbd_vars = _xml_body_output_vars(fbd_xml)

    def _vec(body_vars: set) -> list:
        return [
            all(v.upper() in body_vars for v in tc.get("expected_outputs", {}).keys())
            for tc in test_cases
        ]

    return compute_semantic_equivalence(
        [r["passed"] for r in st_test_results],
        _vec(ld_vars),
        _vec(fbd_vars),
    )


# ─── Single Run ───────────────────────────────────────────────────────────────

def run_framework(task: dict, client: openai.OpenAI, prompt_style: str = "standard", rag=None, live_normalize: bool = False, participant_id: str = None, experiment_number: int = None, rag_override: bool = None) -> dict:
    """
    Execute the full framework pipeline for a single benchmark task.

    Phase 1: Normalize requirement (live LLM call if live_normalize=True,
             otherwise use pre-validated spec from benchmark JSON).
    Phase 2: Generate ST code using LLM.
    Phase 3: Iterative compiler-guided refinement.
    Phase 4: Cross-language translation + metrics collection.

    Args:
        task: Loaded benchmark task dictionary.
        client: Authenticated OpenAI client.
        prompt_style: Prompting strategy to use.

    Returns:
        Completed experiment log dictionary.
    """
    task_id   = task["task_id"]
    condition = "framework"
    print(f"\n{'='*60}")
    print(f"  Task      : {task_id}")
    print(f"  Condition : {condition}")
    print(f"  Prompt    : {prompt_style}")
    print(f"{'='*60}")

    log = create_experiment_log(task_id, condition, task["complexity"])
    if participant_id:
        log["participant_id"] = participant_id
    if experiment_number is not None:
        log["experiment_number"] = experiment_number
    # RAG: rag_override explicitly enables/disables; None means use config default
    _rag_active = config.RAG_ENABLED if rag_override is None else rag_override
    log["rag_used"] = _rag_active
    print("\n[Phase 1] Requirement Normalisation & Inconsistency Detection...")

    if live_normalize:
        # Live LLM normalization — call the normalizer on the raw requirement
        from src.normalizer import normalize_requirement
        print("  [Phase 1] Running live LLM normalization on raw requirement...")
        try:
            normalized = normalize_requirement(task.get("raw_requirement", ""), client, config.LLM_MODEL)
            # Compute normalization fidelity: fraction of expected output variable names
            # present in the live-normalized spec vs. the pre-validated benchmark spec
            ref_outputs = {v["name"].upper() for v in task.get("normalized_requirement", {}).get("outputs", [])}
            live_outputs = {v["name"].upper() for v in normalized.get("outputs", [])}
            fidelity = round(len(ref_outputs & live_outputs) / max(len(ref_outputs), 1), 4)
            log["normalization_fidelity"] = fidelity
            print(f"  [Phase 1] Live normalization complete. Fidelity vs. reference spec: {fidelity:.0%}")
        except Exception as e:
            print(f"  [Phase 1] Live normalization failed ({e}), falling back to pre-validated spec.")
            normalized = task.get("normalized_requirement", {})
            log["normalization_fidelity"] = None
    else:
        normalized = task.get("normalized_requirement", {})
        log["normalization_fidelity"] = None  # not applicable when using pre-validated spec

    # ── Agent 3: Requirements Gap Detection ──────────────────────────────────
    print("\n[Agent 3] Requirements Gap Detection...")
    gap_result = detect_requirement_gaps(
        raw_requirement=task.get("raw_requirement", ""),
        normalized_requirement=normalized,
    )
    log["gaps_detected"] = gap_result["gaps_detected"]
    log["gap_report"]    = gap_result["gap_report"]
    print(format_gap_summary(gap_result))

    # Build prompt string — inject gap block so LLM knows what's missing
    req_str = format_for_prompt(normalized, gap_block=gap_result["gap_prompt_block"])

    incon_result = detect_inconsistencies(normalized)
    raw_compare  = compare_raw_vs_normalized(task.get("raw_requirement", ""), normalized)
    log["logical_inconsistencies"] = incon_result["count"] + raw_compare["count"]
    if incon_result["issues"] or raw_compare["dropped_concepts"]:
        all_issues = incon_result["issues"] + raw_compare["dropped_concepts"]
        print(f"\n[RQ2] {len(all_issues)} inconsistency/gap(s) detected in normalized requirement:")
        for issue in all_issues:
            print(f"  ⚠  {issue}")
    log["phase1_seconds"] = 0  # Phase 1 is CPU-only (no LLM); negligible
    print(f"[Phase 1] done — {log['logical_inconsistencies']} issue(s) detected.")

    # ── Phase 2: LLM Code Generation ─────────────────────────────────────────
    print("\n[Phase 2] Generating Structured Text code...")
    # RAG: retrieve similar solved tasks as few-shot examples
    _rag = (rag or _get_rag(client)) if _rag_active else None
    rag_ctx = _rag.codegen_context(req_str, k=config.RAG_TOP_K) if _rag else ""
    if _rag_active:
        if rag_ctx:
            print(f"[RAG] Enabled: injecting up to {config.RAG_TOP_K} similar example(s) into generation prompt.")
        else:
            print(
                "[RAG] Enabled but no retrieval context found for this task "
                "(generation will proceed without injected examples)."
            )

    def _run_phase2_with_heartbeat():
        result_q: queue.Queue = queue.Queue(maxsize=1)

        def _worker():
            try:
                result_q.put(("ok", generate_st_code(
                    req_str, client, config.LLM_MODEL, prompt_style,
                    reference_st=task.get("reference_st_code", ""),
                    rag_context=rag_ctx,
                )))
            except Exception as exc:  # noqa: BLE001
                result_q.put(("err", exc))

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        waited = 0
        heartbeat_secs = 15
        max_wait_secs = 1200  # 20-minute safety limit (double the HTTP timeout)
        
        while t.is_alive():
            if waited >= max_wait_secs:
                print(
                    f"[Phase 2] ABORT: Generation exceeded {max_wait_secs}s safety limit. "
                    f"Thread may be stuck in API call."
                )
                raise TimeoutError(
                    f"Generation thread did not complete within {max_wait_secs}s. "
                    f"Gemini API may be unresponsive."
                )
            
            t.join(timeout=heartbeat_secs)
            if t.is_alive():
                waited += heartbeat_secs
                print(
                    f"[Phase 2] Still generating with {config.LLM_MODEL}... "
                    f"{waited}s elapsed (prompt={prompt_style}, rag_config={'on' if _rag_active else 'off'}, "
                    f"rag_ctx={'present' if bool(rag_ctx) else 'none'})."
                )

        # Safety timeout on queue.get() in case thread silently crashed
        try:
            status, payload = result_q.get(timeout=5)
        except queue.Empty:
            raise RuntimeError(
                "Generation thread completed but never put result in queue (internal crash?)"
            )
        
        if status == "err":
            raise payload
        return payload

    with Timer() as gen_timer:
        gen_result = _run_phase2_with_heartbeat()

    log["phase2_seconds"] = gen_timer.elapsed_seconds
    initial_st = gen_result["code"]
    print(f"  Generated {len(initial_st.splitlines())} lines of ST code. ({gen_timer.elapsed_seconds}s)")

    # Quick initial compile to record baseline error count
    from src.compiler_feedback import compile_with_openplc
    initial_compile = compile_with_openplc(initial_st, config.COMPILER_PATH)
    log["syntax_errors_initial"] = len(initial_compile["errors"])

    # ── Phase 3: Compiler-Guided Refinement ──────────────────────────────────
    print("\n[Phase 3] Running compiler-guided refinement...")
    with Timer() as refine_timer:
        refine_result = refine_until_compiled(
            initial_st,
            client,
            max_iterations=config.MAX_REFINEMENT_ITERATIONS,
            compiler_path=config.COMPILER_PATH,
            model=config.LLM_MODEL,
            interactive=False,
        )

    final_st = refine_result["final_code"]
    log["compilation_success"]  = refine_result["success"]
    log["iterations_needed"]    = refine_result["iterations"]
    log["iteration_log"]        = refine_result["iteration_log"]
    log["syntax_errors_final"]  = 0 if refine_result["success"] else \
                                  len(refine_result["iteration_log"][-1]["errors"])
    log["phase3_seconds"] = refine_timer.elapsed_seconds
    log["dev_time_minutes"]     = round(gen_timer.elapsed_minutes + refine_timer.elapsed_minutes, 3)
    # Errors resolved by the refinement loop
    if log["syntax_errors_initial"] is not None and log["syntax_errors_final"] is not None:
        log["syntax_errors_delta"] = log["syntax_errors_initial"] - log["syntax_errors_final"]

    # Store provenance metadata
    log["model_used"]  = config.LLM_MODEL
    log["prompt_style"] = prompt_style

    # Save generated code
    code_out = config.GENERATED_CODE / f"{task_id}_{prompt_style}.st"
    save_generated_code(final_st, str(code_out))

    # ── Phase 3b: Test Case Execution (RQ2.3 + RQ3 baseline) ─────────────────
    test_cases = task.get("test_cases", [])
    if test_cases:
        print("\n[RQ2/RQ3] Running test cases against generated ST...")
        st_test_results, cov = run_test_cases_with_coverage(final_st, test_cases)
        log["functional_correctness_rate"] = compute_functional_correctness(st_test_results)
        log["st_test_results"] = st_test_results
        log["statement_coverage"] = round(cov, 4)
        print(format_test_report(st_test_results))
        print(f"  Statement coverage: {cov*100:.1f}%")
    else:
        st_test_results = []

    # ── Phase 3c: Semantic Refinement Loop (Agent 2) ──────────────────────────
    print("\n[Agent 2] Semantic Refinement Loop...")
    if test_cases:
        sem_result = semantic_refinement_loop(
            st_code=final_st,
            test_cases=test_cases,
            normalized_requirement=normalized,
            client=client,
            max_iterations=config.MAX_SEMANTIC_ITERATIONS,
        )
        # Update code and results if Agent 2 improved things
        if sem_result["improved"]:
            final_st        = sem_result["final_code"]
            st_test_results = sem_result["final_test_results"]
            log["functional_correctness_rate"] = sem_result["final_correctness_rate"]
            log["st_test_results"]             = st_test_results
            log["statement_coverage"]          = round(
                run_test_cases_with_coverage(final_st, test_cases)[1], 4)
            # Re-save improved code
            save_generated_code(final_st, str(code_out))
            print(f"  [Agent 2] Logic improved — new pass rate: "
                  f"{sem_result['final_correctness_rate']:.0%}")
        else:
            print("  [Agent 2] No improvement achieved (or already 100%).")
        log["semantic_refinement_iterations"] = sem_result["semantic_refinement_iterations"]
        log["semantic_refinement_log"]        = sem_result["semantic_refinement_log"]
    else:
        log["semantic_refinement_iterations"] = 0
        log["semantic_refinement_log"]        = []

    # Re-compile FINAL code after Agent 2 so compile metrics reflect the code
    # actually saved/evaluated (not the pre-refinement snapshot).
    final_compile = compile_with_openplc(final_st, config.COMPILER_PATH)
    log["compilation_success"] = final_compile["success"]
    log["syntax_errors_final"] = len(final_compile["errors"])
    if log.get("syntax_errors_initial") is not None:
        log["syntax_errors_delta"] = log["syntax_errors_initial"] - log["syntax_errors_final"]

    # ── Phase 3d: Spec Compliance Verification (Agent 1) ─────────────────────
    print("\n[Agent 1] Spec Compliance Verification...")
    compliance = check_spec_compliance(
        normalized_requirement=normalized,
        generated_st_code=final_st,
        client=client,
    )
    log["spec_compliance_score"]  = compliance["spec_compliance_score"]
    log["spec_compliance_detail"] = compliance["spec_compliance_detail"]
    log["conditions_checked"]     = compliance["conditions_checked"]
    log["conditions_met"]         = compliance["conditions_met"]
    log["conditions_partial"]     = compliance["conditions_partial"]
    log["conditions_missing"]     = compliance["conditions_missing"]
    print(format_compliance_report(compliance))

    # ── Phase 4a: BLEU Score ──────────────────────────────────────────────
    reference = task.get("reference_st_code", "")
    if reference:
        log["bleu_score"] = round(compute_bleu(final_st, reference), 4)
        print(f"\n[Evaluator] BLEU score: {log['bleu_score']}")

    # ── Hallucination Rate ───────────────────────────────────────────────────
    hr = compute_hallucination_rate(final_st, task)
    log["hallucination_rate"] = hr
    if hr >= 0:
        print(f"[Evaluator] Hallucination rate: {hr*100:.1f}% of identifiers not in spec")

    # ── Phase 4b: Cross-Language Translation ─────────────────────────────────
    print("\n[Phase 4] Translating to LD and FBD...")
    with Timer() as p4_timer:
        translate_result = translate_and_save(
            final_st,
            system_name=f"{task_id}_{prompt_style}",
            output_dir=str(config.TRANSLATED_CODE),
            task=task,
        )

    # Use proper XML structural validation results returned by translate_and_save().
    # validate_plcopen_xml() checks: (1) well-formed XML parse, (2) PLCopen TC6
    # namespace, (3) expected output variable names present in <outputVars>.
    # This is a structural proxy for compilation — full runtime validation via a
    # live OpenPLC instance is outside the automated pipeline scope (see limitations).
    log["phase4_seconds"] = p4_timer.elapsed_seconds
    ld_val  = translate_result.get("ld_validation",  {})
    fbd_val = translate_result.get("fbd_validation", {})
    log["ld_compilation_success"]  = ld_val.get("valid", False)
    log["fbd_compilation_success"] = fbd_val.get("valid", False)
    log["ld_validation_detail"]    = ld_val
    log["fbd_validation_detail"]   = fbd_val

    # ── Phase 4c: Semantic Equivalence (RQ3) ─────────────────────────────────
    # Equivalence proxy: compare ST test-case pass/fail vectors against LD/FBD
    # variable-presence vectors derived from proper XML parse (not string search).
    # ── Phase 4c: Semantic Equivalence (RQ3) ─────────────────────────────────
    equiv = _compute_se_proxy(translate_result, st_test_results, test_cases)
    log["semantic_equivalence_score"] = equiv["score"]
    log["equivalence_level"]          = equiv["level"]
    if equiv["score"] is not None:
        print(f"\n[RQ3] Semantic equivalence: {equiv['score']} ({equiv['level']})")

    # ── Save Log ──────────────────────────────────────────────────────────────
    log_path = save_log(log, str(config.EXPERIMENT_LOGS))

    print(f"\n[Done] Task '{task_id}' complete.")
    print(f"  Compiled   : {log['compilation_success']}")
    print(f"  Iterations : {log['iterations_needed']}")
    print(f"  Dev Time   : {log['dev_time_minutes']} min")
    print(f"  Log        : {log_path}")

    return log


# ─── Manual Programming Condition ────────────────────────────────────────────

def run_manual(task: dict) -> dict:
    """
    Condition (i): Traditional manual PLC programming by a domain expert.
    The engineer writes ST code themselves while the framework records
    development time, runs test cases, and saves the log.
    Enables direct comparison against conditions (ii) and (iii).
    No OpenAI API key required for this condition.
    """
    task_id = task["task_id"]
    print(f"\n{'='*60}")
    print(f"  Condition : manual")
    print(f"  Task      : {task_id}  |  {task['complexity']}")
    print(f"{'='*60}")
    print("\nRequirement (raw industrial specification):")
    raw_req_display = task.get("raw_requirement", "")
    print(raw_req_display if raw_req_display else "(no raw requirement found — showing normalized spec)")
    if not raw_req_display:
        from src.normalizer import format_for_prompt as _ffp
        print(_ffp(task.get("normalized_requirement", {})))
    print("\n" + "-"*60)
    print("Write the IEC 61131-3 Structured Text program.")
    print("Type your code below, then type END on a new line when done.")
    print("(The timer starts now.)")
    print("-"*60 + "\n")

    log = create_experiment_log(task_id, "manual", task["complexity"])

    with Timer() as t:
        lines = []
        while True:
            line = input()
            if line.strip().upper() == "END":
                break
            lines.append(line)
        manual_code = "\n".join(lines).strip()

    log["dev_time_minutes"] = round(t.elapsed_minutes, 3)
    print(f"\n  Time recorded: {log['dev_time_minutes']} min")

    # Compile the submitted code
    from src.compiler_feedback import compile_with_openplc
    compile_result = compile_with_openplc(manual_code, config.COMPILER_PATH)
    log["compilation_success"]   = compile_result["success"]
    log["syntax_errors_initial"] = len(compile_result["errors"])
    log["syntax_errors_final"]   = len(compile_result["errors"])
    log["iterations_needed"]     = 1

    if compile_result["errors"]:
        print(f"  Compiler errors: {len(compile_result['errors'])}")
        for e in compile_result["errors"]:
            print(f"    - {e}")

    # Manual correction count
    try:
        n_corrections = int(input("\nHow many manual corrections did you make while writing? ").strip())
    except ValueError:
        n_corrections = 0
    log["manual_corrections_count"] = n_corrections

    # Run test cases
    test_cases = task.get("test_cases", [])
    if test_cases:
        print("\n[Evaluator] Running test cases...")
        tc_results, cov = run_test_cases_with_coverage(manual_code, test_cases)
        log["functional_correctness_rate"] = compute_functional_correctness(tc_results)
        log["st_test_results"] = tc_results
        log["statement_coverage"] = round(cov, 4)
        print(format_test_report(tc_results))

    # Inconsistency check on normalized req
    incon = detect_inconsistencies(task.get("normalized_requirement", {}))
    log["logical_inconsistencies"] = incon["count"]

    # Save code
    code_out = config.GENERATED_CODE / f"{task_id}_manual.st"
    save_generated_code(manual_code, str(code_out))

    log_path = save_log(log, str(config.EXPERIMENT_LOGS))
    print(f"\n[Done] Manual task '{task_id}' complete. Log: {log_path}")
    return log


# ─── Direct LLM Condition ─────────────────────────────────────────────────────

def run_direct_llm(task: dict, client: openai.OpenAI, prompt_style: str = "standard", rag=None, experiment_number: int = None, rag_override: bool = None) -> dict:
    """
    Direct LLM condition: single-pass generation with no compiler feedback loop.
    RAG usage is controlled by rag_override/config so UI toggles can apply to
    both framework and direct_llm consistently.
    """
    task_id = task["task_id"]
    print(f"\n{'='*60}")
    print(f"  Task      : {task_id}")
    print(f"  Condition : direct_llm")
    print(f"  Prompt    : {prompt_style}")
    print(f"{'='*60}")

    log = create_experiment_log(task_id, "direct_llm", task["complexity"])
    if experiment_number is not None:
        log["experiment_number"] = experiment_number
    _rag_active_dl = config.RAG_ENABLED if rag_override is None else rag_override
    log["rag_used"] = _rag_active_dl

    # Phase 1 — use raw requirement directly (no normalisation step).
    # Inconsistency detection runs on a minimal parsed version of the raw text
    # so the baseline stays cleanly isolated from the framework's normalization.
    print("\n[Phase 1] Using raw requirement (no normalisation for direct_llm)...")
    raw_req = task.get("raw_requirement", "")
    # Build a minimal spec from raw text for inconsistency counting purposes
    # (avoids using the pre-validated normalized_requirement in the baseline)
    raw_as_spec = {
        "inputs": [],
        "outputs": [],
        "internal_variables": [],
        "control_conditions": [],
        "safety_constraints": [],
        "description": raw_req,
    }
    incon = detect_inconsistencies(raw_as_spec)
    log["logical_inconsistencies"] = incon["count"]

    # Agent 3: gap detection against pre-validated spec (measure only)
    print("\n[Agent 3] Requirements Gap Detection (measure only)...")
    _dl_gap = detect_requirement_gaps(
        raw_requirement=raw_req,
        normalized_requirement=task.get("normalized_requirement", {}),
    )
    log["gaps_detected"] = _dl_gap["gaps_detected"]
    log["gap_report"]    = _dl_gap["gap_report"]
    print(format_gap_summary(_dl_gap))

    print(f"[Phase 1] done — raw requirement ready (inconsistency check on raw text only).")

    # Phase 2 — single-pass LLM generation (optional RAG based on toggle/config)
    print(
        "\n[Phase 2] Generating Structured Text code "
        f"(single-pass, no feedback, rag_config={'on' if _rag_active_dl else 'off'})..."
    )
    #
    # In MOCK mode the generator parses INPUTS/OUTPUTS sections from the prompt
    # string to build a working program.  Raw text has no such sections so it
    # would produce an empty stub.  When MOCK_LLM is active (and no reference
    # code is available to substitute), synthesise a minimal formatted spec
    # from the task's declared variables so the mock can emit proper logic.
    # This code path is NEVER reached in real-LLM mode (MOCK_LLM=false).
    reference_st = task.get("reference_st_code", "")
    if config.MOCK_LLM and not reference_st.strip():
        # Use normalized_requirement as authoritative source; fall back to top-level keys
        _nreq = task.get("normalized_requirement", {})
        _inputs_src  = task.get("inputs", []) or _nreq.get("inputs", [])
        _outputs_src = task.get("outputs", []) or _nreq.get("outputs", [])
        _conds_src   = (_nreq.get("control_conditions", [])
                        or task.get("control_conditions", []))
        _inputs_fmt  = "\n".join(
            f"  - {v['name']} : {v.get('type','BOOL')}  // {v.get('description','')}"
            for v in _inputs_src
        )
        _outputs_fmt = "\n".join(
            f"  - {v['name']} : {v.get('type','BOOL')}  // {v.get('description','')}"
            for v in _outputs_src
        )
        _conditions_fmt = "\n".join(
            f"  [{c.get('priority','medium').upper()}] {c['condition']}"
            for c in _conds_src
        )
        _gen_input = (
            f"DESCRIPTION:\n  {raw_req[:300]}\n\n"
            f"INPUTS:\n{_inputs_fmt}\n\n"
            f"OUTPUTS:\n{_outputs_fmt}\n\n"
            f"CONTROL CONDITIONS:\n{_conditions_fmt}\n"
        )
    else:
        _gen_input = raw_req

    _rag_dl = (rag or _get_rag(client)) if _rag_active_dl else None
    rag_ctx_dl = _rag_dl.codegen_context(_gen_input, k=config.RAG_TOP_K) if _rag_dl else ""
    if _rag_active_dl:
        if rag_ctx_dl:
            print(f"[RAG] Enabled: injecting up to {config.RAG_TOP_K} similar example(s) into direct_llm prompt.")
        else:
            print("[RAG] Enabled but no retrieval context found for this direct_llm task.")

    with Timer() as t:
        gen_result = generate_st_code(
            _gen_input, client, config.LLM_MODEL, prompt_style,
            reference_st=reference_st,
            rag_context=rag_ctx_dl,
            task_spec=task,   # fallback for mock mode when text parsing finds nothing
        )
    log["phase2_seconds"] = t.elapsed_seconds
    print(f"  Generated {len(gen_result['code'].splitlines())} lines of ST code. ({t.elapsed_seconds}s)")

    # Phase 3 — compile (single pass, no iterative refinement)
    print("\n[Phase 3] Compiling (no iterative refinement for direct_llm)...")
    from src.compiler_feedback import compile_with_openplc
    compile_result = compile_with_openplc(gen_result["code"], config.COMPILER_PATH)

    log["compilation_success"]   = compile_result["success"]
    log["syntax_errors_initial"] = len(compile_result["errors"])
    log["syntax_errors_final"]   = len(compile_result["errors"])
    log["iterations_needed"]     = 1
    log["phase3_seconds"]        = 0  # heuristic compile only, negligible
    log["dev_time_minutes"]      = round(t.elapsed_minutes, 3)
    log["model_used"]            = config.LLM_MODEL
    log["prompt_style"]          = prompt_style
    print(f"  Compiled: {compile_result['success']}  Errors: {len(compile_result['errors'])}")
    save_generated_code(gen_result["code"], str(config.GENERATED_CODE / f"{task_id}_direct_llm_{prompt_style}.st"))

    # Phase 4 — Evaluation (test cases, BLEU, hallucination)
    print("\n[Phase 4] Evaluation — test cases, BLEU, hallucination rate...")
    test_cases = task.get("test_cases", [])
    if test_cases:
        tc_results, cov = run_test_cases_with_coverage(gen_result["code"], test_cases)
        log["functional_correctness_rate"] = compute_functional_correctness(tc_results)
        log["st_test_results"] = tc_results
        log["statement_coverage"] = round(cov, 4)
        print(format_test_report(tc_results))
        print(f"  Statement coverage: {cov*100:.1f}%")

    # Agent 2: Semantic Refinement Loop (logic-fix)
    _dl_code = gen_result["code"]
    if test_cases:
        print("\n[Agent 2] Semantic Refinement Loop...")
        with Timer() as agent2_timer:
            try:
                sem = semantic_refinement_loop(
                    st_code=_dl_code,
                    test_cases=test_cases,
                    normalized_requirement=task.get("normalized_requirement", {}),
                    client=client,
                    max_iterations=config.MAX_SEMANTIC_ITERATIONS,
                )
                if sem["improved"]:
                    _dl_code = sem["final_code"]
                    log["functional_correctness_rate"] = sem["final_correctness_rate"]
                    log["st_test_results"]             = sem["final_test_results"]
                    log["statement_coverage"]          = round(
                        run_test_cases_with_coverage(_dl_code, test_cases)[1], 4)
                    # Re-save improved version
                    save_generated_code(_dl_code, str(
                        config.GENERATED_CODE / f"{task_id}_direct_llm_{prompt_style}.st"))
                    print(f"  [Agent 2] Improved to {sem['final_correctness_rate']:.0%} pass rate.")
                else:
                    print("  [Agent 2] No improvement (already passing or MOCK mode).")
                log["semantic_refinement_iterations"] = sem["semantic_refinement_iterations"]
                log["semantic_refinement_log"]        = sem["semantic_refinement_log"]
            except Exception as exc:
                print(f"  [Agent 2] Refinement failed, continuing with current ST: {exc}")
                log["semantic_refinement_iterations"] = 0
                log["semantic_refinement_log"]        = [{"error": str(exc)}]
        log["agent2_seconds"] = agent2_timer.elapsed_seconds
    else:
        log["semantic_refinement_iterations"] = 0
        log["semantic_refinement_log"]        = []
        log["agent2_seconds"] = 0

    # Re-compile FINAL direct_llm code after Agent 2 so logged compile metrics
    # match the final saved/evaluated ST.
    final_compile = compile_with_openplc(_dl_code, config.COMPILER_PATH)
    log["compilation_success"] = final_compile["success"]
    log["syntax_errors_final"] = len(final_compile["errors"])
    if log.get("syntax_errors_initial") is not None:
        log["syntax_errors_delta"] = log["syntax_errors_initial"] - log["syntax_errors_final"]

    # ── Agent 1: Spec Compliance Verification ────────────────────────────
    print("\n[Agent 1] Spec Compliance Verification...")
    _norm_for_judge = task.get("normalized_requirement", {})
    compliance = check_spec_compliance(
        normalized_requirement=_norm_for_judge,
        generated_st_code=_dl_code,
        client=client,
    )
    log["spec_compliance_score"]  = compliance["spec_compliance_score"]
    log["spec_compliance_detail"] = compliance["spec_compliance_detail"]
    log["conditions_checked"]     = compliance["conditions_checked"]
    log["conditions_met"]         = compliance["conditions_met"]
    log["conditions_partial"]     = compliance["conditions_partial"]
    log["conditions_missing"]     = compliance["conditions_missing"]
    print(format_compliance_report(compliance))

    reference = task.get("reference_st_code", "")
    if reference:
        log["bleu_score"] = round(compute_bleu(_dl_code, reference), 4)
        print(f"[Evaluator] BLEU score: {log['bleu_score']}")

    hr = compute_hallucination_rate(_dl_code, task)
    log["hallucination_rate"] = hr
    if hr >= 0:
        print(f"[Evaluator] Hallucination rate: {hr*100:.1f}%")

    # Phase 5 — Cross-language translation parity with framework
    print("\n[Phase 5] Translating to LD and FBD...")
    with Timer() as p5_timer:
        translate_result = translate_and_save(
            _dl_code,
            system_name=f"{task_id}_direct_llm_{prompt_style}",
            output_dir=str(config.TRANSLATED_CODE),
            task=task,
        )
    log["phase5_seconds"] = p5_timer.elapsed_seconds
    ld_val  = translate_result.get("ld_validation", {})
    fbd_val = translate_result.get("fbd_validation", {})
    log["ld_compilation_success"]  = ld_val.get("valid", False)
    log["fbd_compilation_success"] = fbd_val.get("valid", False)
    log["ld_validation_detail"]    = ld_val
    log["fbd_validation_detail"]   = fbd_val
    print(f"  LD valid : {log['ld_compilation_success']}")
    print(f"  FBD valid: {log['fbd_compilation_success']}")

    # ── Phase 5b: Semantic Equivalence (RQ3) ─────────────────────────────────
    _st_res_dl = log.get("st_test_results") or []
    equiv_dl = _compute_se_proxy(translate_result, _st_res_dl, test_cases)
    log["semantic_equivalence_score"] = equiv_dl["score"]
    log["equivalence_level"]          = equiv_dl["level"]
    if equiv_dl["score"] is not None:
        print(f"\n[RQ3] Semantic equivalence: {equiv_dl['score']} ({equiv_dl['level']})")

    save_log(log, str(config.EXPERIMENT_LOGS))
    print(f"\n[Done] Task '{task_id}' complete (direct_llm).")
    return log


# ─── CLI Entry Point ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="LLM-Assisted PLC Code Generation Framework")
    parser.add_argument("--task",      type=str, default="motor_control_low",
                        help="Benchmark task ID or 'all'")
    parser.add_argument("--condition", type=str, default="framework",
                        choices=["framework", "direct_llm", "manual"],
                        help="Experimental condition")
    parser.add_argument("--prompt",    type=str, default=config.PROMPT_STYLE,
                        choices=["standard", "chain_of_thought", "program_of_thought"],
                        help="Prompting strategy")
    parser.add_argument("--summarize", action="store_true",
                        help="Print aggregate summary of all saved logs")
    parser.add_argument("--live-normalize", action="store_true",
                        help="Run LLM normalization on raw_requirement instead of using pre-validated spec")
    parser.add_argument("--participant-id", type=str, default=None,
                        help="Optional participant identifier for multi-participant studies (e.g. P01)")
    args = parser.parse_args()

    # Print summary mode
    if args.summarize:
        logs = load_all_logs(str(config.EXPERIMENT_LOGS))
        if not logs:
            print("No experiment logs found.")
            return
        summary = summarize_results(logs)
        print("\n=== Experiment Summary ===")
        print(json.dumps(summary, indent=2))
        return

    # Manual condition does not require OpenAI
    if args.condition == "manual":
        task_ids = list_tasks() if args.task == "all" else [args.task]
        for task_id in task_ids:
            run_manual(load_task(task_id))
        return

    # Validate config and create provider client
    validate_config()
    provider = config.active_provider()
    if provider == "ollama":
        client = openai.OpenAI(
            base_url=config.OLLAMA_BASE_URL,
            api_key=config.OLLAMA_API_KEY,
            http_client=httpx.Client(timeout=config.LLM_REQUEST_TIMEOUT_SECONDS),
            max_retries=config.LLM_MAX_RETRIES,
        )
        model_name = config.OLLAMA_MODEL
    elif provider == "gemini":
        client = openai.OpenAI(
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
            api_key=config.GEMINI_API_KEY,
            http_client=httpx.Client(timeout=config.LLM_REQUEST_TIMEOUT_SECONDS),
            max_retries=config.LLM_MAX_RETRIES,
        )
        model_name = config.GEMINI_MODEL
    elif provider == "openai_compatible":
        base_url, api_key, model_name = config.openai_compatible_config()
        client = openai.OpenAI(
            base_url=base_url,
            api_key=api_key,
            http_client=httpx.Client(timeout=config.LLM_REQUEST_TIMEOUT_SECONDS),
            max_retries=config.LLM_MAX_RETRIES,
        )
    else:
        client = openai.OpenAI(
            api_key=config.OPENAI_API_KEY,
            timeout=config.LLM_REQUEST_TIMEOUT_SECONDS,
            max_retries=config.LLM_MAX_RETRIES,
        )
        model_name = config.LLM_MODEL

    # Build RAG index once before the loop
    rag = _get_rag(client)

    # Determine tasks to run
    task_ids = list_tasks() if args.task == "all" else [args.task]
    live_norm = getattr(args, 'live_normalize', False)

    for task_id in task_ids:
        task = load_task(task_id)
        if args.condition == "framework":
            # Use selected provider model for this run
            _orig_model = config.LLM_MODEL
            config.LLM_MODEL = model_name
            run_framework(task, client, prompt_style=args.prompt, rag=rag,
                          live_normalize=live_norm,
                          participant_id=getattr(args, 'participant_id', None))
            config.LLM_MODEL = _orig_model
        elif args.condition == "direct_llm":
            _orig_model = config.LLM_MODEL
            config.LLM_MODEL = model_name
            run_direct_llm(task, client, rag=rag)
            config.LLM_MODEL = _orig_model
        elif args.condition == "manual":
            run_manual(task)


if __name__ == "__main__":
    main()
