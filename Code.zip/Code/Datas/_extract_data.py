import json, urllib.request, re

r = urllib.request.urlopen('http://localhost:5000/dashboard')
html = r.read().decode('utf-8')
m = re.search(r'const D = ({.*?});', html, re.DOTALL)
if not m:
    print("ERROR: Could not find chart_data")
    exit(1)

data = json.loads(m.group(1))

print("=== FRAMEWORK vs DIRECT LLM ===")
for k in ['fw_compile_rate','dl_compile_rate','fw_avg_test','dl_avg_test','fw_avg_cov','dl_avg_cov',
           'fw_avg_spec','dl_avg_spec','fw_lang_rate','dl_lang_rate','fw_pass_rate','dl_pass_rate']:
    print(f"  {k}: {data[k]}")

print("\n=== RAG IMPACT ===")
for k in ['rag_on_compile','rag_off_compile','rag_on_test','rag_off_test','rag_on_cov','rag_off_cov',
           'rag_on_spec','rag_off_spec','rag_on_lang','rag_off_lang','rag_on_pass','rag_off_pass',
           'rag_on_count','rag_off_count']:
    print(f"  {k}: {data[k]}")

print("\n=== PROMPT STRATEGY (Overall) ===")
for i, l in enumerate(['Standard', 'CoT', 'PoT']):
    print(f"  {l}: compile={data['prompt_all_compile'][i]} test={data['prompt_all_test'][i]} cov={data['prompt_all_cov'][i]} spec={data['prompt_all_spec'][i]} pass={data['prompt_all_pass'][i]}")

print("\n=== PROMPT x APPROACH ===")
for i, l in enumerate(['Standard', 'CoT', 'PoT']):
    print(f"  FW {l}: compile={data['prompt_fw_compile'][i]} test={data['prompt_fw_test'][i]} spec={data['prompt_fw_spec'][i]}")
    print(f"  DL {l}: compile={data['prompt_dl_compile'][i]} test={data['prompt_dl_test'][i]} spec={data['prompt_dl_spec'][i]}")

print("\n=== COMPLEXITY ===")
for i, l in enumerate(data['complexity_labels']):
    print(f"  {l}: compile={data['complexity_compile'][i]} test={data['complexity_test'][i]} cov={data['complexity_cov'][i]} spec={data['complexity_spec'][i]} pass={data['complexity_pass'][i]}")

print("\n=== COMBO RANKING ===")
for j, c in enumerate(data['combo_ranking']):
    print(f"  #{j+1} {c['label']}: score={c['score']} compile={c['compile']} test={c['test']} cov={c['cov']} spec={c['spec']} lang={c['lang']} pass={c['pass_rate']} n={c['n']}")

print("\n=== ADDITIONAL METRICS ===")
for k in ['fw_bleu','dl_bleu','fw_hallucination','dl_hallucination','fw_iterations','dl_iterations',
           'fw_syntax_errors','dl_syntax_errors','fw_syntax_errors_final','dl_syntax_errors_final',
           'fw_compile_pass','fw_compile_fail','dl_compile_pass','dl_compile_fail',
           'fw_inconsistencies','dl_inconsistencies','fw_semantic_eq','dl_semantic_eq',
           'fw_dev_time','dl_dev_time','fw_nasa_tlx','dl_nasa_tlx','fw_acceptance','dl_acceptance',
           'fw_expert_rating','dl_expert_rating']:
    print(f"  {k}: {data[k]}")

print("\n=== PER-METHOD ===")
for i, m in enumerate(data['method_labels']):
    print(f"  {m}: test={data['method_test_avg'][i]} spec={data['method_spec_avg'][i]} compile={data['method_compile_rate'][i]} pass={data['method_pass_rate'][i]}")

print(f"\n=== TOTALS ===")
print(f"  total_pass={data['total_pass']} total_fail={data['total_fail']}")
print(f"  tasks={data['task_labels']}")

print("\n=== FW vs DL PER TASK ===")
for i, t in enumerate(data['task_labels']):
    print(f"  {t}: fw_test={data['task_fw_test'][i]} dl_test={data['task_dl_test'][i]} fw_spec={data['task_fw_spec'][i]} dl_spec={data['task_dl_spec'][i]} fw_compile={data['task_fw_compile'][i]} dl_compile={data['task_dl_compile'][i]}")
