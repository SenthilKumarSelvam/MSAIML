"""
Web UI for LLM-Assisted PLC Code Generation Research Framework.
Run with:  python app.py
Then open: http://localhost:5000
"""

import json
import os
import queue
import ssl
import sys
import threading
import time
import traceback
from pathlib import Path

import httpx
import openai
from dotenv import load_dotenv
from flask import Flask, Response, after_this_request, flash, jsonify, redirect, render_template, request, send_file, stream_with_context, url_for

# Load .env file before importing config
load_dotenv()

import config
from src.rag_retriever import RagRetriever
from src.diagram_fidelity import verify_diagram_fidelity, fidelity_badge

app = Flask(__name__)
app.secret_key = "plc-research-ui-2026"

FULL_SIX_COMBINATION_SEQUENCE = [
    ("framework", "standard"),
    ("framework", "chain_of_thought"),
    ("framework", "program_of_thought"),
    ("direct_llm", "standard"),
    ("direct_llm", "chain_of_thought"),
    ("direct_llm", "program_of_thought"),
]


def _sequence_label(condition: str, prompt: str) -> str:
    condition_labels = {
        "framework": "Framework",
        "direct_llm": "Direct LLM",
    }
    return (
        f"{condition_labels.get(condition, condition.replace('_', ' ').title())}"
        f" - {prompt.replace('_', ' ').title()}"
    )


def _select_screening_tasks(task_summaries: list[dict], target_count: int = 3) -> list[str]:
    """
    Pick a small, representative subset: low + medium + high when available,
    then fill remaining slots deterministically.
    """
    if not task_summaries:
        return []

    target_count = max(1, min(target_count, len(task_summaries)))
    chosen: list[str] = []
    seen: set[str] = set()

    for cplx in ("low", "medium", "high"):
        pick = next((t for t in task_summaries if (t.get("complexity") or "").lower() == cplx), None)
        if pick and pick["id"] not in seen:
            chosen.append(pick["id"])
            seen.add(pick["id"])
        if len(chosen) >= target_count:
            return chosen

    for t in task_summaries:
        tid = t["id"]
        if tid in seen:
            continue
        chosen.append(tid)
        seen.add(tid)
        if len(chosen) >= target_count:
            break

    return chosen


def _summarize_results(results: list[dict]) -> dict:
    compiled = sum(1 for r in results if r.get("compilation_success"))
    bleu_scores = [r.get("bleu_score") for r in results if r.get("bleu_score") is not None]
    avg_bleu = sum(bleu_scores) / len(bleu_scores) if bleu_scores else 0.0
    passed = sum(
        sum(1 for tc in r.get("st_test_results", []) if tc.get("passed"))
        for r in results
    )
    total = sum(len(r.get("st_test_results", [])) for r in results)
    return {
        "count": len(results),
        "compiled": compiled,
        "tests_passed": passed,
        "tests_total": total,
        "avg_bleu": avg_bleu,
    }


def _canonicalize_task_like_builder(task: dict) -> dict:
    """
    Ensure benchmark and custom tasks share the same task shape before run.
    """
    if not isinstance(task, dict):
        return task

    t = dict(task)
    existing_norm = t.get("normalized_requirement") if isinstance(t.get("normalized_requirement"), dict) else {}

    raw_id = str(t.get("task_id") or t.get("system_name") or existing_norm.get("system_name") or "custom_task")
    task_id = raw_id.strip().lower().replace(" ", "_")

    import re as _re
    task_id = _re.sub(r"[^a-z0-9_]", "_", task_id)

    t["task_id"] = task_id
    t["scenario"] = t.get("scenario") or task_id
    t["complexity"] = t.get("complexity") or existing_norm.get("complexity") or "low"
    t["raw_requirement"] = t.get("raw_requirement") or t.get("description") or existing_norm.get("description") or ""

    system_name = t.get("system_name") or existing_norm.get("system_name") or task_id
    description = t.get("description") or existing_norm.get("description") or t["raw_requirement"]
    inputs = t.get("inputs") or existing_norm.get("inputs") or []
    outputs = t.get("outputs") or existing_norm.get("outputs") or []
    internal_variables = t.get("internal_variables") or existing_norm.get("internal_variables") or []
    timers = t.get("timers") or existing_norm.get("timers") or []
    counters = t.get("counters") or existing_norm.get("counters") or []
    control_conditions = t.get("control_conditions") or existing_norm.get("control_conditions") or []
    safety_constraints = (
        t.get("interlocks")
        or t.get("safety_constraints")
        or existing_norm.get("safety_constraints")
        or []
    )

    t["normalized_requirement"] = {
        "system_name": system_name,
        "description": description,
        "inputs": inputs,
        "outputs": outputs,
        "internal_variables": internal_variables,
        "timers": timers,
        "counters": counters,
        "control_conditions": control_conditions,
        "safety_constraints": safety_constraints,
        "complexity": t["complexity"],
    }

    t.setdefault("task_source", "benchmark")
    return t


def _to_normalized_requirement_from_analysis(analysis: dict, fallback_complexity: str = "low") -> dict:
    """Map Task Builder analyzer output to normalized_requirement shape used by run pipeline."""
    if not isinstance(analysis, dict):
        return {
            "system_name": "System",
            "description": "",
            "inputs": [],
            "outputs": [],
            "internal_variables": [],
            "control_conditions": [],
            "safety_constraints": [],
            "complexity": fallback_complexity,
        }
    return {
        "system_name": analysis.get("system_name", "System"),
        "description": analysis.get("description", ""),
        "inputs": analysis.get("inputs", []),
        "outputs": analysis.get("outputs", []),
        "internal_variables": analysis.get("internal_variables", []),
        "timers": analysis.get("timers", []),
        "counters": analysis.get("counters", []),
        "control_conditions": analysis.get("control_conditions", []),
        "safety_constraints": analysis.get("interlocks", []),
        "complexity": analysis.get("complexity", fallback_complexity),
    }


def _analyze_requirement_like_task_builder(raw_req: str) -> tuple[dict, dict]:
    """
    Run the same analyzer path as LLM Task Builder and return (analysis_json, metadata).
    metadata keys: provider, mock, warning
    """
    from pathlib import Path as _Path
    import config as _cfg

    raw_req = (raw_req or "").strip()
    if not raw_req:
        return _mock_analyze_requirement(""), {
            "provider": "mock",
            "mock": True,
            "warning": "Empty raw requirement; keyword fallback used.",
        }

    prompt_tmpl = (_Path(__file__).parent / "prompts" / "analyze_requirement.txt").read_text(encoding="utf-8")
    prompt_text = prompt_tmpl.format(requirement=raw_req)

    errors = []
    provider = _cfg.active_provider()

    # Keep parity with Task Builder: force real analysis attempts even if MOCK_LLM is enabled.
    _orig_mock_llm = config.MOCK_LLM
    config.MOCK_LLM = False
    try:
        if provider == "bedrock" and _cfg.AWS_ACCESS_KEY_ID and _cfg.AWS_SECRET_ACCESS_KEY:
            try:
                return _bedrock_analyze_text(prompt_text), {"provider": "bedrock", "mock": False}
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Bedrock: {exc}")

        if provider in ("gemini", "auto") and _cfg.GEMINI_API_KEY:
            try:
                return _gemini_analyze_text(prompt_text), {"provider": "gemini", "mock": False}
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Gemini: {exc}")

        if provider == "ollama":
            try:
                ollama_timeout = float(getattr(_cfg, "LLM_REQUEST_TIMEOUT_SECONDS", 300))
                client = openai.OpenAI(
                    base_url=_cfg.OLLAMA_BASE_URL,
                    api_key=_cfg.OLLAMA_API_KEY,
                    http_client=httpx.Client(timeout=ollama_timeout),
                )
                response = client.chat.completions.create(
                    model=_cfg.OLLAMA_MODEL,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": prompt_text},
                    ],
                    temperature=0.1,
                )
                parsed = json.loads(response.choices[0].message.content.strip())
                return parsed, {"provider": "ollama", "mock": False}
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Ollama: {exc}")

        if provider == "openai_compatible":
            try:
                import re as _re
                base_url, api_key, model = _cfg.openai_compatible_config()
                client = openai.OpenAI(
                    base_url=base_url, api_key=api_key,
                    http_client=httpx.Client(timeout=float(getattr(_cfg, "LLM_REQUEST_TIMEOUT_SECONDS", 300))),
                )
                response = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": prompt_text},
                    ],
                    temperature=0.1,
                    response_format={"type": "json_object"},
                )
                txt = response.choices[0].message.content.strip()
                if txt.startswith("```"):
                    txt = _re.sub(r"^```[a-z]*\n?", "", txt)
                    txt = _re.sub(r"\n?```$", "", txt.strip())
                parsed = _loads_lenient(txt)
                return parsed, {"provider": _cfg.LLM_PROVIDER, "mock": False}
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{_cfg.LLM_PROVIDER}: {exc}")

        if provider in ("openai", "auto") and _cfg.OPENAI_API_KEY:
            try:
                client = openai.OpenAI(api_key=_cfg.OPENAI_API_KEY)
                rag = _get_rag(client)
                rag_ctx = rag.analysis_context(raw_req, k=config.RAG_TOP_K) if rag else ""
                pt = prompt_text + ("\n\n" + rag_ctx if rag_ctx else "")
                response = client.chat.completions.create(
                    model=_cfg.LLM_MODEL,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": pt},
                    ],
                    temperature=0.1,
                    response_format={"type": "json_object"},
                )
                parsed = json.loads(response.choices[0].message.content.strip())
                return parsed, {"provider": "openai", "mock": False}
            except Exception as exc:  # noqa: BLE001
                errors.append(f"OpenAI: {exc}")

        stub = _mock_analyze_requirement(raw_req)
        reason = "; ".join(errors) if errors else "No LLM keys configured"
        return stub, {
            "provider": "mock",
            "mock": True,
            "warning": f"LLM unavailable ({reason}) — keyword analysis used instead.",
        }
    finally:
        config.MOCK_LLM = _orig_mock_llm


def _refresh_task_spec_with_builder_analysis(task: dict) -> tuple[dict, dict]:
    """Return task with normalized_requirement refreshed via Task Builder analyzer."""
    t = _canonicalize_task_like_builder(task)
    raw_req = (t.get("raw_requirement") or "").strip()
    if not raw_req:
        return t, {
            "provider": "none",
            "mock": False,
            "warning": "No raw_requirement found; kept existing normalized requirement.",
        }

    analysis, meta = _analyze_requirement_like_task_builder(raw_req)
    new_norm = _to_normalized_requirement_from_analysis(
        analysis,
        fallback_complexity=t.get("complexity", "low"),
    )
    t["normalized_requirement"] = new_norm
    t["complexity"] = new_norm.get("complexity", t.get("complexity", "low"))
    t["task_source"] = "benchmark_builder_analysis"
    return t, meta


def _run_task_for_condition(
    task: dict,
    condition: str,
    prompt_style: str,
    client,
    experiment_number: int | None,
    rag_enabled: bool,
):
    """Execute one task under a given condition/prompt pair."""
    from main import run_framework, run_direct_llm

    if condition == "framework":
        return run_framework(
            task,
            client,
            prompt_style=prompt_style,
            experiment_number=experiment_number,
            rag_override=rag_enabled,
        )
    if condition == "direct_llm":
        return run_direct_llm(
            task,
            client,
            prompt_style=prompt_style,
            experiment_number=experiment_number,
            rag_override=rag_enabled,
        )
    return None


def _run_with_timeout(fn, *args, timeout_secs=None, **kwargs):
    """
    Run fn(*args, **kwargs) with an optional per-task wall-clock timeout.

    The sub-thread inherits the parent's SSE queue so all print() output
    continues to stream to the browser during execution. On timeout, the
    function returns None and the pipeline moves to the next combination —
    the background thread finishes on its own without blocking anything.

    Set TASK_TIMEOUT_SECONDS=0 in .env to disable (equivalent to no timeout).
    """
    if timeout_secs is None or timeout_secs <= 0:
        return fn(*args, **kwargs)

    parent_q = getattr(_run_tls, "queue", None)
    result_box: list = [None]
    exc_box:    list = [None]

    def _sub():
        _run_tls.queue = parent_q  # inherit parent SSE queue
        try:
            result_box[0] = fn(*args, **kwargs)
        except Exception as exc:  # noqa: BLE001
            exc_box[0] = exc

    t = threading.Thread(target=_sub, daemon=True)
    t.start()
    t.join(timeout=timeout_secs)

    if t.is_alive():
        task_id = kwargs.get("task") and kwargs["task"].get("task_id", "?") or "?"
        cond    = kwargs.get("condition", "?")
        prompt  = kwargs.get("prompt_style", "?")
        print(
            f"[Timeout] {task_id} / {cond} / {prompt} exceeded {timeout_secs}s "
            f"— skipping this combination and continuing."
        )
        return None  # sub-thread keeps running in background; we move on

    if exc_box[0] is not None:
        raise exc_box[0]
    return result_box[0]


def _combination_score(entries: list[dict]) -> float:
    """
    Rank combinations using compilation reliability + test pass ratio.
    """
    if not entries:
        return 0.0
    comp_rate = sum(1 for e in entries if e.get("compilation_success")) / len(entries)
    tc_passed = sum(
        sum(1 for tc in e.get("st_test_results", []) if tc.get("passed"))
        for e in entries
    )
    tc_total = sum(len(e.get("st_test_results", [])) for e in entries)
    test_rate = (tc_passed / tc_total) if tc_total else 0.0
    return round((0.5 * comp_rate) + (0.5 * test_rate), 6)


def _full_sequence_with_labels() -> list[dict]:
    return [
        {
            "condition": condition,
            "prompt": prompt,
            "label": _sequence_label(condition, prompt),
        }
        for condition, prompt in FULL_SIX_COMBINATION_SEQUENCE
    ]

@app.context_processor
def inject_globals():
    """Make RAG status and config available in every template."""
    return dict(rag_enabled=config.RAG_ENABLED)

# ─── RAG singleton (lazy) ──────────────────────────────────────────────────────
_rag_lock     = threading.Lock()
_rag_instance: RagRetriever | None = None

def _get_rag(openai_client=None, force: bool = False) -> RagRetriever | None:
    """Return a shared, indexed RagRetriever (initialised once).

    Args:
        openai_client: Optional OpenAI client for embeddings.
        force: When True, build/return the retriever even if config.RAG_ENABLED
               is False (used by the per-request Task Builder RAG toggle).
    """
    global _rag_instance
    if not config.RAG_ENABLED and not force:
        return None
    with _rag_lock:
        if _rag_instance is None:
            _rag_instance = RagRetriever(
                benchmark_dir=config.BENCHMARK_DIR,
                persist_dir=config.RAG_STORE_DIR,
                openai_client=openai_client,
            )
            _rag_instance.index_tasks()
        return _rag_instance

# ─── Streaming log queues ─────────────────────────────────────────────────────
_run_queues: dict[str, queue.Queue] = {}
_active_run_lock = threading.Lock()
_active_run_id: str | None = None


def _claim_run_slot(run_id: str) -> tuple[bool, str | None]:
    """Reserve the single active run slot. Returns (ok, current_active_run_id)."""
    global _active_run_id
    with _active_run_lock:
        if _active_run_id and _active_run_id != run_id:
            return False, _active_run_id
        _active_run_id = run_id
        return True, _active_run_id


def _release_run_slot(run_id: str) -> None:
    """Release active run slot if owned by the supplied run_id."""
    global _active_run_id
    with _active_run_lock:
        if _active_run_id == run_id:
            _active_run_id = None


# ─── AWS Bedrock OpenAI-shaped adapter ───────────────────────────────────────
# Bedrock is NOT OpenAI-compatible (it uses boto3 invoke_model), but every LLM
# caller in this app expects an object exposing
# ``client.chat.completions.create(model, messages, ...)`` that returns
# ``response.choices[0].message.content``. These thin wrappers provide exactly
# that surface so generate_st_code / normalizer / refiner work unchanged when
# LLM_PROVIDER=bedrock.

class _BedrockMessage:
    def __init__(self, content: str):
        self.content = content


class _BedrockChoice:
    def __init__(self, content: str):
        self.message = _BedrockMessage(content)


class _BedrockResponse:
    def __init__(self, content: str):
        self.choices = [_BedrockChoice(content)]


class _BedrockCompletions:
    def __init__(self, parent: "_BedrockChatClient"):
        self._parent = parent

    def create(self, model=None, messages=None, temperature=0.1,
               max_tokens=None, timeout=None, **_ignored):
        return self._parent._invoke(
            model=model, messages=messages or [],
            temperature=temperature, max_tokens=max_tokens,
        )


class _BedrockChat:
    def __init__(self, parent: "_BedrockChatClient"):
        self.completions = _BedrockCompletions(parent)


class _BedrockChatClient:
    """Minimal OpenAI-client-shaped wrapper backed by AWS Bedrock (Claude)."""

    def __init__(self, region, access_key, secret_key, default_model, session_token=None):
        import boto3 as _boto3
        self._client = _boto3.client(
            "bedrock-runtime",
            region_name=region,
            aws_access_key_id=access_key or None,
            aws_secret_access_key=secret_key or None,
            aws_session_token=session_token or None,
        )
        self._default_model = default_model
        self.chat = _BedrockChat(self)

    def _invoke(self, model=None, messages=None, temperature=0.1, max_tokens=None):
        import json as _json
        model_id = model or self._default_model
        system_txt = ""
        conv = []
        for m in (messages or []):
            role = m.get("role")
            content = m.get("content")
            # Flatten OpenAI vision-style content lists down to their text parts.
            if isinstance(content, list):
                content = " ".join(
                    part.get("text", "") for part in content
                    if isinstance(part, dict) and part.get("type") == "text"
                )
            content = content or ""
            if role == "system":
                system_txt = (system_txt + "\n" + content).strip() if system_txt else content
            else:
                conv.append({"role": "assistant" if role == "assistant" else "user",
                             "content": content})
        if not conv:
            conv = [{"role": "user", "content": system_txt or ""}]
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": int(max_tokens or 4096),
            "temperature": float(temperature if temperature is not None else 0.1),
            "messages": conv,
        }
        if system_txt:
            body["system"] = system_txt
        resp = self._client.invoke_model(modelId=model_id, body=_json.dumps(body))
        payload = _json.loads(resp["body"].read())
        text = "".join(
            blk.get("text", "") for blk in payload.get("content", [])
            if blk.get("type", "text") == "text"
        )
        return _BedrockResponse(text)


def _make_openai_client(force_provider: str | None = None) -> openai.OpenAI | None:
    """
    Create an OpenAI client that works on corporate/proxy networks.
    Returns None in MOCK_LLM mode (no API calls will be made).
    Falls back to disabling SSL verification when a MITM proxy is detected.

    If ``force_provider`` is supplied (e.g. "ollama"), that provider is used for
    THIS client only, without changing LLM_PROVIDER in .env. This powers the
    one-click "switch to Ollama and retry" fallback when the Gemini free-tier
    daily quota is exhausted, leaving existing logs/results untouched.
    """
    if config.MOCK_LLM:
        return None  # all LLM calls are skipped in mock mode

    provider = (force_provider or config.active_provider()).lower()
    if force_provider:
        print(f"[Provider] Using forced provider for this run: {provider}")
    if provider == "bedrock":
        # AWS Bedrock (Claude). Point config.LLM_MODEL at the Bedrock model so
        # downstream callers (generate_st_code, normalizer, etc.) use it.
        config.LLM_MODEL = config.BEDROCK_MODEL
        print(f"[Provider] AWS Bedrock → {config.BEDROCK_MODEL} (region={config.AWS_REGION})")
        return _BedrockChatClient(
            config.AWS_REGION,
            config.AWS_ACCESS_KEY_ID,
            config.AWS_SECRET_ACCESS_KEY,
            config.BEDROCK_MODEL,
            session_token=config.AWS_SESSION_TOKEN,
        )
    if provider == "ollama":
        # Ensure config.LLM_MODEL reflects the Ollama model so all
        # downstream callers (generate_st_code, normalizer, etc.) use it
        config.LLM_MODEL = config.OLLAMA_MODEL
        print(f"[Provider] Ollama → {config.OLLAMA_BASE_URL} (model={config.OLLAMA_MODEL})")
        return openai.OpenAI(
            base_url=config.OLLAMA_BASE_URL,
            api_key=config.OLLAMA_API_KEY,
            http_client=httpx.Client(timeout=config.LLM_REQUEST_TIMEOUT_SECONDS),
            max_retries=config.LLM_MAX_RETRIES,
        )

    if provider == "gemini":
        # Route Phase-2 code generation (and any other OpenAI-style caller)
        # through Gemini's OpenAI-compatible endpoint so it never touches the
        # dead OpenAI quota. Point config.LLM_MODEL at the Gemini model so
        # downstream callers (generate_st_code, normalizer, etc.) use it.
        config.LLM_MODEL = config.GEMINI_MODEL
        print(f"[Provider] Gemini → OpenAI-compatible endpoint (model={config.GEMINI_MODEL})")
        return openai.OpenAI(
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
            api_key=config.GEMINI_API_KEY,
            http_client=httpx.Client(timeout=config.LLM_REQUEST_TIMEOUT_SECONDS),
            max_retries=config.LLM_MAX_RETRIES,
        )

    if provider == "openai_compatible":
        # Any OpenAI-compatible provider (Groq, OpenRouter, DeepSeek, Together,
        # Cerebras, or a custom endpoint). base_url/key/model resolved from .env.
        base_url, api_key, model = config.openai_compatible_config()
        config.LLM_MODEL = model  # downstream callers use config.LLM_MODEL
        print(f"[Provider] OpenAI-compatible: {config.LLM_PROVIDER} → {base_url} (model={model})")
        return openai.OpenAI(
            base_url=base_url,
            api_key=api_key,
            http_client=httpx.Client(timeout=config.LLM_REQUEST_TIMEOUT_SECONDS),
            max_retries=config.LLM_MAX_RETRIES,
        )

    # Build client; handle SSL proxy issues
    try:
        print(f"[Provider] OpenAI → model={config.LLM_MODEL}")
        return openai.OpenAI(
            api_key=config.OPENAI_API_KEY,
            timeout=config.LLM_REQUEST_TIMEOUT_SECONDS,
            max_retries=config.LLM_MAX_RETRIES,
        )
    except Exception:
        pass

    # Try with SSL verification disabled (corporate proxy)
    print("[Network] Falling back to SSL verify=False for corporate proxy.")
    http_client = httpx.Client(verify=False, timeout=config.LLM_REQUEST_TIMEOUT_SECONDS)
    return openai.OpenAI(
        api_key=config.OPENAI_API_KEY,
        http_client=http_client,
        timeout=config.LLM_REQUEST_TIMEOUT_SECONDS,
        max_retries=config.LLM_MAX_RETRIES,
    )


# ─── Gemini helpers ──────────────────────────────────────────────────────────

def _bedrock_analyze_text(prompt_text: str) -> dict:
    """Call AWS Bedrock (Claude) to analyse a plain-text requirement and return parsed JSON."""
    import boto3 as _boto3
    import json as _json
    client = _boto3.client(
        "bedrock-runtime",
        region_name=config.AWS_REGION,
        aws_access_key_id=config.AWS_ACCESS_KEY_ID or None,
        aws_secret_access_key=config.AWS_SECRET_ACCESS_KEY or None,
        aws_session_token=config.AWS_SESSION_TOKEN or None,
    )
    body = _json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 4096,
        "temperature": 0.1,
        "system": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON.",
        "messages": [{"role": "user", "content": prompt_text}]
    })
    response = client.invoke_model(modelId=config.BEDROCK_MODEL, body=body)
    result_body = _json.loads(response["body"].read())
    return _json.loads(result_body["content"][0]["text"].strip())


def _loads_lenient(text: str) -> dict:
    """Parse JSON from an LLM, tolerating common non-standard output.

    Some models (notably Groq's llama-3.3-70b) emit IEC 61131-3 style booleans
    as bare uppercase tokens inside JSON values, e.g. ``{"MOTOR": FALSE}``.
    Bare ``TRUE``/``FALSE``/``NULL`` are invalid JSON, which makes ``json.loads``
    raise and the caller fall back to the keyword analyzer. This helper strips
    markdown fences, then retries with those value-position tokens coerced to
    lowercase. String contents are left untouched because the regex only matches
    tokens delimited by JSON structural characters."""
    import re as _re
    txt = (text or "").strip()
    if txt.startswith("```"):
        txt = _re.sub(r"^```[a-z]*\n?", "", txt)
        txt = _re.sub(r"\n?```$", "", txt.strip())
    txt = txt.strip()
    try:
        return json.loads(txt)
    except json.JSONDecodeError:
        coerced = _re.sub(
            r"(?<=[:\[,\s])(TRUE|FALSE|NULL)(?=[\s,\]\}])",
            lambda m: m.group(1).lower(),
            txt,
        )
        return json.loads(coerced)


def _gemini_analyze_text(prompt_text: str) -> dict:
    """Call Gemini to analyse a plain-text requirement and return parsed JSON.

    Gemini free tier intermittently returns 503 (model overloaded) and 429
    (rate limit). Those are TRANSIENT — retry the same model with exponential
    backoff instead of giving up to the keyword mock. 404/NOT_FOUND means the
    model name is unavailable, so we skip to the next candidate. Note the
    gemini-2.0-flash* models have zero free-tier quota, so they are excluded."""
    import time as _t
    from google import genai
    from google.genai import types

    models_to_try = list(dict.fromkeys([config.GEMINI_MODEL, "gemini-2.5-flash"]))
    transient = ("429", "RESOURCE_EXHAUSTED", "503", "UNAVAILABLE", "overloaded", "high demand")
    not_found = ("404", "NOT_FOUND")
    client = genai.Client(api_key=config.GEMINI_API_KEY)
    last_exc = None
    for model in models_to_try:
        for attempt in range(4):  # up to 4 tries per model (0,1,2,3)
            try:
                response = client.models.generate_content(
                    model=model,
                    contents=prompt_text,
                    config=types.GenerateContentConfig(
                        system_instruction="You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON.",
                        response_mime_type="application/json",
                        temperature=0.1,
                        thinking_config=types.ThinkingConfig(thinking_budget=0),
                    )
                )
                return json.loads(response.text.strip())
            except Exception as e:
                last_exc = e
                err_str = str(e)
                if any(x in err_str for x in not_found):
                    break  # model unavailable — try next candidate immediately
                if any(x in err_str for x in transient):
                    if attempt < 3:
                        _t.sleep(2 ** attempt)  # 1s, 2s, 4s backoff
                        continue
                    break  # retries exhausted for this model — try next candidate
                raise  # genuine error (auth, bad request, parse): surface it
    raise last_exc


def _gemini_analyze_image(image_b64: str, image_type: str, prompt_text: str) -> dict:
    """Call Gemini vision to analyse a diagram image and return parsed JSON.
    Retries transient 429/503 with backoff; skips unavailable (404) models."""
    import base64 as _b64
    import time as _t
    from google import genai
    from google.genai import types

    image_bytes = _b64.b64decode(image_b64)
    models_to_try = list(dict.fromkeys([config.GEMINI_MODEL, "gemini-2.5-flash"]))
    transient = ("429", "RESOURCE_EXHAUSTED", "503", "UNAVAILABLE", "overloaded", "high demand")
    not_found = ("404", "NOT_FOUND")
    client = genai.Client(api_key=config.GEMINI_API_KEY)
    last_exc = None
    for model in models_to_try:
        for attempt in range(4):
            try:
                response = client.models.generate_content(
                    model=model,
                    contents=[
                        types.Part.from_bytes(data=image_bytes, mime_type=image_type),
                        prompt_text,
                    ],
                    config=types.GenerateContentConfig(
                        system_instruction="You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON.",
                        response_mime_type="application/json",
                        temperature=0.1,
                        thinking_config=types.ThinkingConfig(thinking_budget=0),
                    )
                )
                return json.loads(response.text.strip())
            except Exception as e:
                last_exc = e
                err_str = str(e)
                if any(x in err_str for x in not_found):
                    break
                if any(x in err_str for x in transient):
                    if attempt < 3:
                        _t.sleep(2 ** attempt)
                        continue
                    break
                raise
    raise last_exc


# ─── Mock LLM requirement analyser ──────────────────────────────────────────

def _mock_analyze_requirement(raw_req: str) -> dict:
    """
    Text-faithful requirement analyser for MOCK_LLM mode.

    Derives ALL variable names strictly from the nouns and devices explicitly
    named in the raw requirement text.  Never invents generic names or imports
    concepts from other domains.

    Handles:
      • Zone-based conveyors  (entry/exit sensors, jam timers, product counter)
      • Simple motor / pump / valve systems with SIMOCODE / VFD support
      • Temperature, pressure, flow (only when text says so)
      • Level sensors  (ONLY when text explicitly mentions level / tank / float)
      • Timers with preset extracted from the text ("15 seconds" → T#15s)
      • Counters with semantically correct types (CTUD for product count)
    """
    import re as _re

    txt = raw_req.lower()
    words = _re.findall(r"\b\w+\b", txt)

    # ── Micro-helpers ─────────────────────────────────────────────────────────
    def _has(keyword: str) -> bool:
        """True if the keyword (or its plural) appears in the text."""
        return keyword in words or (keyword + "s") in words or (keyword + "es") in words

    def _num_before(keyword: str) -> int:
        """Return integer before *keyword* or its plural form, or 1."""
        word_map = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
        variants = {keyword, keyword + "s", keyword + "es"}
        for i, w in enumerate(words):
            if w in variants and i > 0:
                prev = words[i - 1]
                if prev.isdigit():
                    return int(prev)
                if prev in word_map:
                    return word_map[prev]
        return 1

    def _extract_timer_preset(context_txt: str = "") -> str:
        """
        Extract the first explicit duration from *context_txt* (fallback to
        full *txt*).  Returns an IEC 61131-3 TIME literal (e.g. "T#15s").
        Falls back to T#3s only when the text contains NO numeric duration.
        """
        search_in = (context_txt + " " + txt).lower()
        # "15 seconds", "15 second", "15s", "15 sec"
        m = _re.search(r'(\d+(?:\.\d+)?)\s*(?:seconds?|sec|s)\b', search_in)
        if m:
            return f"T#{int(float(m.group(1)))}s"
        # "3 minutes", "3 minute", "3min"
        m = _re.search(r'(\d+(?:\.\d+)?)\s*(?:minutes?|min)\b', search_in)
        if m:
            return f"T#{int(float(m.group(1)))}m"
        # "500ms", "500 ms", "500 milliseconds"
        m = _re.search(r'(\d+(?:\.\d+)?)\s*(?:milliseconds?|ms)\b', search_in)
        if m:
            return f"T#{int(float(m.group(1)))}ms"
        # "2 hours", "2h"
        m = _re.search(r'(\d+(?:\.\d+)?)\s*(?:hours?|hr|h)\b', search_in)
        if m:
            return f"T#{int(float(m.group(1)))}h"
        # IEC literal already present: T#15s
        m = _re.search(r't#(\d+\w+)', search_in)
        if m:
            return f"T#{m.group(1)}"
        return "T#3s"  # generic fallback only when no value found

    # ─────────────────────────────────────────────────────────────────────────
    # BRANCH A: ZONE-BASED CONVEYOR
    # Detect zone count from explicit "N zones" / "N-zone" phrasing FIRST,
    # then validate against explicit "zone N" mentions in the text.
    # ─────────────────────────────────────────────────────────────────────────

    # Step 1: try to extract the TOTAL zone count from natural-language forms
    _zone_count: int = 0
    _m = _re.search(r'zones?\s+(\d+)\s+(?:to|through|thru|-)\s+(\d+)', txt)
    if _m:
        _zone_count = int(_m.group(2)) - int(_m.group(1)) + 1
        _zone_start = int(_m.group(1))
    else:
        _m = _re.search(r'(\d+)\s*[- ]?\s*zones?', txt)
        if _m:
            _zone_count = int(_m.group(1))
        else:
            _word_map = {"two": 2, "three": 3, "four": 4, "five": 5,
                         "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
            for _word, _val in _word_map.items():
                if _re.search(rf'\b{_word}\b.*\bzones?\b|\bzones?\b.*\b{_word}\b', txt):
                    _zone_count = _val
                    break

    # Step 2: collect any explicit "zone N" / "ZONE{N}" mentions to find the range
    _explicit: list[int] = []
    for _m2 in _re.finditer(r'\bzone\s*(\d+)\b', txt):
        n = int(_m2.group(1))
        if n not in _explicit:
            _explicit.append(n)
    _explicit.sort()

    # Step 3: build the definitive zone list
    # Prefer the count-based range; use explicit mentions only if no count found.
    if _zone_count >= 2:
        # Count-based: always produces the complete contiguous set
        zone_nums = list(range(1, _zone_count + 1))
    elif _explicit:
        # Explicit mentions only — fill the contiguous range between min and max
        zone_nums = list(range(min(_explicit), max(_explicit) + 1))
    else:
        zone_nums = []

    if zone_nums:
        # ── Zone-based conveyor spec ──────────────────────────────────────────
        n_zones = len(zone_nums)

        # -- Sensor style ──────────────────────────────────────────────────────
        # RULE: If the text explicitly mentions "entry sensor" or "exit sensor",
        # those are the hardware inputs.  "Zone is occupied" is a ZONE STATE
        # (internal variable derived from entry/exit), NOT a sensor type.
        # Only use ZONE{N}_OCCUPIED as a sensor when the text says "occupancy
        # sensor" or "presence sensor" and does NOT mention entry/exit sensors.
        has_entry    = _has("entry") or _has("enter") or _has("arrival")
        has_exit     = _has("exit")  or _has("depart") or _has("leave")
        # "Presence sensor" / "occupancy sensor" as explicit hardware type
        has_occ_sensor = bool(_re.search(
            r'(?:occupancy|presence|proximity)\s+sensor', txt))
        # Use entry+exit when the text describes them; fall back to occupied sensor
        use_entry_exit = has_entry or has_exit

        # Jam detection method:
        # "jam sensor" / "blockage sensor" / "jam detector" → hardware input JAM_Z{N}
        # "jam alarm" / "remains for X seconds" / "jam shall be activated" → timer-based
        has_jam_alarm  = _has("jam") or _has("stuck") or _has("block")
        has_jam_sensor = bool(_re.search(
            r'jam\s+sensor|blockage\s+sensor|jam\s+detect|stuck\s+sensor', txt))

        has_product  = any(w in words for w in ("product", "item", "part", "piece", "batch", "count",
                                                 "counter", "unit", "package", "parcel"))
        has_e_stop   = _has("emergency") or _has("e-stop") or "estop" in txt or "e_stop" in txt

        # Timer preset — look for an explicit duration anywhere in the text
        jam_preset = _extract_timer_preset()

        # -- INPUTS
        inputs: list[dict] = []
        for zn in zone_nums:
            if use_entry_exit:
                # Text explicitly describes entry and exit sensors
                inputs.append({"name": f"ZONE{zn}_ENTRY", "type": "BOOL",
                                "description": f"Zone {zn} entry (arrival) sensor"})
                inputs.append({"name": f"ZONE{zn}_EXIT",  "type": "BOOL",
                                "description": f"Zone {zn} exit (departure) sensor"})
            elif has_occ_sensor:
                # Text explicitly mentions an occupancy/presence sensor
                inputs.append({"name": f"ZONE{zn}_OCCUPIED", "type": "BOOL",
                                "description": f"Zone {zn} occupancy / presence sensor"})
            else:
                # Default fallback: entry + exit
                inputs.append({"name": f"ZONE{zn}_ENTRY", "type": "BOOL",
                                "description": f"Zone {zn} entry (arrival) sensor"})
                inputs.append({"name": f"ZONE{zn}_EXIT",  "type": "BOOL",
                                "description": f"Zone {zn} exit (departure) sensor"})
            if has_jam_sensor:
                # Only add a hardware jam input when the text says "jam sensor" etc.
                inputs.append({"name": f"JAM_Z{zn}", "type": "BOOL",
                                "description": f"Jam / blockage sensor for zone {zn}"})

        inputs.append({"name": "E_STOP", "type": "BOOL",
                       "description": "Emergency stop (NC, normally TRUE)"})
        if not has_e_stop:
            # Add a system-start input only when text says nothing about E-STOP
            inputs.insert(len(inputs) - 1, {"name": "SYSTEM_START", "type": "BOOL",
                                             "description": "System start command"})

        # -- OUTPUTS: one motor per zone + jam alarm when mentioned
        outputs: list[dict] = []
        for zn in zone_nums:
            outputs.append({"name": f"ZONE{zn}_MOTOR", "type": "BOOL",
                            "description": f"Zone {zn} conveyor motor run command"})
        if has_jam_alarm:
            outputs.append({"name": "JAM_ALARM", "type": "BOOL",
                            "description": "Jam alarm output (any zone)"})

        # -- TIMERS: one jam-detection timer per zone (with extracted preset)
        timers: list[dict] = []
        if has_jam_alarm:
            for zn in zone_nums:
                timers.append({"name": f"JAM_TIMER_Z{zn}", "type": "TON",
                               "preset": jam_preset,
                               "description": f"Jam detection timer for zone {zn} — activates after {jam_preset}"})

        # -- COUNTERS: product counter (CTUD) when text mentions items/products
        counters: list[dict] = []
        if has_product:
            counters.append({"name": "PRODUCT_COUNT", "type": "CTUD", "preset": 9999,
                             "description": "Total product / item count — CU on ZONE1_ENTRY, CD on ZONE5_EXIT"})

        # -- INTERNAL VARIABLES
        internals: list[dict] = []
        # Zone occupancy state (SR latch: set on entry, reset on exit)
        if use_entry_exit:
            for zn in zone_nums:
                internals.append({"name": f"ZONE{zn}_OCCUPIED", "type": "BOOL",
                                  "initial_value": "FALSE",
                                  "description": f"Zone {zn} occupied state (set on ENTRY, reset on EXIT)"})
        if has_jam_alarm:
            internals.append({"name": "ANY_JAM", "type": "BOOL", "initial_value": "FALSE",
                              "description": "TRUE when any zone jam timer has elapsed"})

        # -- INTERLOCKS
        interlocks = ["E_STOP must immediately de-energise all zone motors and activate JAM_ALARM"]
        # Enumerate each collision-prevention pair explicitly
        for i in range(len(zone_nums) - 1):
            upstream = zone_nums[i]
            downstream = zone_nums[i + 1]
            interlocks.append(
                f"ZONE{upstream}_MOTOR must stop while ZONE{downstream}_OCCUPIED is TRUE "
                f"(collision prevention: upstream zone {upstream} waits for downstream zone {downstream} to clear)"
            )
        if has_jam_alarm:
            for zn in zone_nums:
                interlocks.append(
                    f"ZONE{zn}_MOTOR must stop and JAM_ALARM must activate when JAM_TIMER_Z{zn} elapses "
                    f"(product stuck in zone {zn} for >{jam_preset})"
                )

        # -- CONTROL CONDITIONS
        conditions: list[dict] = []
        # Zone occupancy latching (set on entry, reset on exit)
        if use_entry_exit:
            for zn in zone_nums:
                conditions.append({
                    "condition": f"IF ZONE{zn}_ENTRY THEN ZONE{zn}_OCCUPIED := TRUE; END_IF",
                    "priority": "high"
                })
                conditions.append({
                    "condition": f"IF ZONE{zn}_EXIT THEN ZONE{zn}_OCCUPIED := FALSE; END_IF",
                    "priority": "high"
                })
        # Motor run conditions with collision-prevention gate
        for idx, zn in enumerate(zone_nums):
            next_zn = zone_nums[idx + 1] if idx + 1 < len(zone_nums) else None
            if next_zn:
                block_cond = f" AND NOT ZONE{next_zn}_OCCUPIED"
            else:
                block_cond = ""
            jam_cond = f" AND NOT JAM_TIMER_Z{zn}.Q" if has_jam_alarm else ""
            conditions.append({
                "condition": f"ZONE{zn}_MOTOR := ZONE{zn}_OCCUPIED AND E_STOP{block_cond}{jam_cond}",
                "priority": "high"
            })
        if has_jam_alarm:
            jam_conds = " OR ".join(f"JAM_TIMER_Z{zn}.Q" for zn in zone_nums)
            conditions.append({
                "condition": f"ANY_JAM := {jam_conds}",
                "priority": "high"
            })
            conditions.append({
                "condition": "JAM_ALARM := ANY_JAM",
                "priority": "medium"
            })
        conditions.append({
            "condition": "IF NOT E_STOP THEN (* de-energise all zone motors *)",
            "priority": "high"
        })

        # -- TEST CASES
        sensor_key = "ZONE1_ENTRY" if use_entry_exit else "ZONE1_OCCUPIED"
        test_cases = [
            {
                "id": "TC01",
                "description": "Product present in zone 1, zone 2 empty, E-STOP healthy — motor runs",
                "inputs": {sensor_key: True, "ZONE1_EXIT": False, "E_STOP": True,
                           **({"ZONE2_OCCUPIED": False} if use_entry_exit and n_zones > 1 else {}),
                           **({"ANY_JAM": False} if has_jam_alarm else {})},
                "expected_outputs": {"ZONE1_MOTOR": True},
                "pre_state": {**({f"ZONE{zn}_OCCUPIED": False for zn in zone_nums} if use_entry_exit else {}),
                              **({"ANY_JAM": False} if has_jam_alarm else {})}
            },
            {
                "id": "TC02",
                "description": "No product in zone 1 — motor idle",
                "inputs": {sensor_key: False, "E_STOP": True},
                "expected_outputs": {"ZONE1_MOTOR": False},
                "pre_state": {}
            },
            {
                "id": "TC03",
                "description": "E-STOP activated — all motors stop",
                "inputs": {sensor_key: True, "E_STOP": False},
                "expected_outputs": {"ZONE1_MOTOR": False},
                "pre_state": {}
            },
        ]
        if has_jam_alarm:
            test_cases.append({
                "id": "TC04",
                "description": "Jam in zone 1 (timer elapsed) — motor stops, JAM_ALARM raised",
                "inputs": {sensor_key: True, "E_STOP": True},
                "expected_outputs": {"ZONE1_MOTOR": False, "JAM_ALARM": True},
                "pre_state": {**({f"ZONE{zn}_OCCUPIED": (zn == 1) for zn in zone_nums} if use_entry_exit else {}),
                              "ANY_JAM": True}
            })
            test_cases.append({
                "id": "TC05",
                "description": "Jam cleared — motor resumes, alarm clears",
                "inputs": {sensor_key: True, "E_STOP": True},
                "expected_outputs": {"ZONE1_MOTOR": True, "JAM_ALARM": False},
                "pre_state": {**({f"ZONE{zn}_OCCUPIED": (zn == 1) for zn in zone_nums} if use_entry_exit else {}),
                              "ANY_JAM": False}
            })
        if n_zones > 1:
            # Collision-prevention test: zone 1 product blocked by occupied zone 2
            sensor_z2 = "ZONE2_ENTRY" if use_entry_exit else "ZONE2_OCCUPIED"
            test_cases.append({
                "id": f"TC0{len(test_cases)+1}",
                "description": "Zone 2 occupied — zone 1 motor blocked (collision prevention)",
                "inputs": {sensor_key: True, "E_STOP": True},
                "expected_outputs": {"ZONE1_MOTOR": False, "ZONE2_MOTOR": True},
                "pre_state": {**({f"ZONE{zn}_OCCUPIED": (zn in (1, 2)) for zn in zone_nums} if use_entry_exit else {}),
                              **({"ANY_JAM": False} if has_jam_alarm else {})}
            })

        # -- Complexity
        n_out = len(outputs)
        n_tim = len(timers)
        n_cnt = len(counters)
        if n_out >= 5 or n_tim >= 4 or n_cnt >= 2:
            complexity = "high"
        elif n_out >= 3 or n_tim >= 2 or n_cnt >= 1:
            complexity = "medium"
        else:
            complexity = "low"

        # System name from meaningful words
        skip = {"i", "a", "an", "the", "to", "have", "need", "with", "and",
                "or", "of", "in", "is", "by", "be", "my", "we", "for", "that"}
        sname = "".join(w.capitalize() for w in words
                        if w.isalpha() and w not in skip)[:4 * 8][:32] or "ConveyorZoneControl"

        return {
            "system_name":         sname,
            "description":         raw_req[:120],
            "complexity":          complexity,
            "inputs":              inputs,
            "outputs":             outputs,
            "timers":              timers,
            "counters":            counters,
            "internal_variables":  internals,
            "interlocks":          interlocks,
            "control_conditions":  conditions,
            "test_cases":          test_cases,
        }

    # ─────────────────────────────────────────────────────────────────────────
    # BRANCH B: STANDARD DEVICE-BASED SPEC (motor / pump / valve / SIMOCODE)
    # ─────────────────────────────────────────────────────────────────────────

    # ── Detect device counts ──────────────────────────────────────────────────
    n_motors   = _num_before("motor")   if _has("motor")   else 0
    n_pumps    = _num_before("pump")    if _has("pump")    else 0
    n_conveyors= _num_before("conveyor")if _has("conveyor")else 0
    n_valves   = _num_before("valve")   if _has("valve")   else 0
    n_simocode = _num_before("simocode")if _has("simocode")else 0
    n_drives   = (_num_before("drive")  if _has("drive")   else 0) or \
                 (_num_before("vfd")    if _has("vfd")     else 0)

    # Total actuator outputs  (motors + pumps + conveyors + valves)
    actuators = (
        [("MOTOR",    n_motors)]    * bool(n_motors)    +
        [("PUMP",     n_pumps)]     * bool(n_pumps)     +
        [("CONVEYOR", n_conveyors)] * bool(n_conveyors) +
        [("VALVE",    n_valves)]    * bool(n_valves)
    )
    if not actuators:
        actuators = [("OUTPUT", 1)]   # generic fallback

    # ── Build outputs (one per actuator instance) ─────────────────────────────
    outputs: list[dict] = []
    for base, count in actuators:
        for i in range(1, count + 1):
            sfx = f"_{i}" if count > 1 else ""
            outputs.append({"name": f"{base}{sfx}_RUN",
                             "type": "BOOL",
                             "description": f"{base.capitalize()}{sfx} run command"})

    # ── Build inputs ──────────────────────────────────────────────────────────
    inputs: list[dict] = []

    # Detect whether the description asks for per-device individual buttons
    has_individual = any(w in words for w in ("individual", "separate", "each", "per", "independent"))
    n_devices = sum([n_motors, n_pumps, n_conveyors, n_valves]) or 1

    if has_individual and n_devices > 1:
        # One START + STOP per actuator instance
        for base, count in actuators:
            for i in range(1, count + 1):
                sfx = f"_{i}" if count > 1 else ""
                inputs.append({"name": f"{base}{sfx}_START", "type": "BOOL",
                                "description": f"Start pushbutton for {base.capitalize()}{sfx} (NO)"})
                inputs.append({"name": f"{base}{sfx}_STOP",  "type": "BOOL",
                                "description": f"Stop pushbutton for {base.capitalize()}{sfx} (NC)"})
    else:
        # Shared global start / stop
        inputs.append({"name": "START_PB", "type": "BOOL", "description": "Start pushbutton (NO)"})
        inputs.append({"name": "STOP_PB",  "type": "BOOL", "description": "Stop pushbutton (NC)"})

    # Shared emergency stop is always present
    inputs.append({"name": "E_STOP", "type": "BOOL", "description": "Emergency stop (NC, normally TRUE)"})

    # SIMOCODE feedback signals (ready + fault per device)
    if n_simocode > 0:
        for i in range(1, n_simocode + 1):
            inputs.append({"name": f"SIMOCODE_{i}_RDY", "type": "BOOL",
                            "description": f"SIMOCODE unit {i} ready signal"})
            inputs.append({"name": f"SIMOCODE_{i}_FLT", "type": "BOOL",
                            "description": f"SIMOCODE unit {i} fault signal"})

    # VFD/drive feedback
    if n_drives > 0:
        for i in range(1, n_drives + 1):
            inputs.append({"name": f"DRIVE_{i}_RDY",   "type": "BOOL", "description": f"Drive {i} ready"})
            inputs.append({"name": f"DRIVE_{i}_FAULT", "type": "BOOL", "description": f"Drive {i} fault"})

    # Feedback/status inputs per actuator (running feedback)
    if n_devices > 1:
        for base, count in actuators:
            for i in range(1, count + 1):
                sfx = f"_{i}" if count > 1 else ""
                inputs.append({"name": f"{base}{sfx}_FB", "type": "BOOL",
                                "description": f"{base.capitalize()}{sfx} running feedback"})

    # ── Process sensors — ONLY when the text explicitly mentions them ─────────
    # BUG FIX: "sensor" alone does NOT imply level/tank; only add level vars
    # when the requirement text explicitly mentions level, tank, or float.
    has_level = _has("level") or _has("tank") or _has("float") or _has("sump")
    has_temp  = _has("temperature") or _has("temp") or "heat" in words or "cool" in words
    has_press = _has("pressure") or _has("press")
    has_flow  = _has("flow") or "flowrate" in words
    if has_level:
        inputs.append({"name": "LEVEL_HIGH", "type": "BOOL", "description": "High-level sensor"})
        inputs.append({"name": "LEVEL_LOW",  "type": "BOOL", "description": "Low-level sensor"})
    if has_temp:
        inputs.append({"name": "TEMP_PV",     "type": "REAL", "description": "Temperature process value (°C)"})
    if has_press:
        inputs.append({"name": "PRESSURE_PV", "type": "REAL", "description": "Pressure process value (bar)"})
    if has_flow:
        inputs.append({"name": "FLOW_PV",     "type": "REAL", "description": "Flow process value (l/min)"})

    # ── Internal variables ────────────────────────────────────────────────────
    internals: list[dict] = []
    out_names = [o["name"] for o in outputs]
    for oname in out_names:
        state_name = oname.replace("_RUN", "_STATE")
        internals.append({"name": state_name, "type": "BOOL",
                          "initial_value": "FALSE",
                          "description": f"Latched run state for {oname}"})

    # Fault accumulation flag when SIMOCODE devices are present
    if n_simocode > 0:
        internals.append({"name": "ANY_FAULT", "type": "BOOL",
                          "initial_value": "FALSE",
                          "description": "TRUE if any SIMOCODE reports a fault"})

    # ── Timers ────────────────────────────────────────────────────────────────
    timers: list[dict] = []
    has_delay    = any(w in words for w in ("delay", "timer", "timeout", "after", "wait", "seconds", "sec",
                                             "minute", "min", "millisecond", "ms"))
    has_sequence = any(w in words for w in ("sequence", "step", "stage", "phase"))
    has_interval = any(w in words for w in ("interval", "periodic", "every", "repeat"))

    if has_delay:
        preset = _extract_timer_preset()
        timers.append({"name": "START_DELAY", "type": "TON", "preset": preset,
                       "description": f"Start delay before enabling output ({preset})"})
    if has_sequence and n_devices > 1:
        seq_preset = _extract_timer_preset()
        for i in range(1, n_devices):
            timers.append({"name": f"SEQ_DELAY_{i}", "type": "TON", "preset": seq_preset,
                           "description": f"Delay between step {i} and step {i+1}"})
    if has_interval:
        interval_preset = _extract_timer_preset()
        timers.append({"name": "CYCLE_TIMER", "type": "TP", "preset": interval_preset,
                       "description": "Periodic cycle pulse timer"})
    if has_individual and n_devices > 1 and not has_sequence:
        run_preset = _extract_timer_preset()
        for base, count in actuators:
            for i in range(1, count + 1):
                sfx = f"_{i}" if count > 1 else ""
                timers.append({"name": f"{base}{sfx}_RUN_TMR", "type": "TON", "preset": run_preset,
                               "description": f"Run confirmation timer for {base.capitalize()}{sfx}"})

    # ── Counters ──────────────────────────────────────────────────────────────
    counters: list[dict] = []
    # Product / item / batch → bidirectional CTUD with meaningful name
    has_product_count = any(w in words for w in ("product", "item", "part", "piece", "batch", "package",
                                                   "parcel", "unit"))
    has_generic_count = any(w in words for w in ("count", "counter", "cycle", "trip",
                                                   "revolution", "rotation", "pulse"))
    has_alarm   = any(w in words for w in ("alarm", "fault", "error", "fail", "trip"))
    has_sorting = any(w in words for w in ("sort", "sorting", "reject", "accept", "grade"))

    if has_product_count:
        counters.append({"name": "PRODUCT_COUNT", "type": "CTUD", "preset": 9999,
                         "description": "Product / item count — bidirectional"})
    elif has_generic_count:
        for base, count in actuators:
            for i in range(1, count + 1):
                sfx = f"_{i}" if count > 1 else ""
                counters.append({"name": f"{base}{sfx}_CYCLE_CNT", "type": "CTU", "preset": 100,
                                 "description": f"Run cycle count for {base.capitalize()}{sfx}"})
    if has_alarm and not counters:
        counters.append({"name": "FAULT_CNT", "type": "CTU", "preset": 5,
                         "description": "Consecutive fault counter — trip after preset"})
    if has_sorting:
        counters.append({"name": "ACCEPT_CNT", "type": "CTU", "preset": 1000,
                         "description": "Accepted parts counter"})
        counters.append({"name": "REJECT_CNT", "type": "CTU", "preset": 50,
                         "description": "Rejected parts counter"})

    # ── Interlocks ────────────────────────────────────────────────────────────
    interlocks = ["E_STOP must immediately de-energise all outputs"]
    if n_simocode > 0:
        interlocks.append("All SIMOCODE units must report READY before any motor starts")
        interlocks.append("Any SIMOCODE fault must stop all outputs immediately")

    # ── Control conditions ────────────────────────────────────────────────────
    conditions: list[dict] = []
    state_names = [i["name"] for i in internals if "_STATE" in i["name"]]

    if n_simocode > 0:
        all_rdy = " AND ".join(f"SIMOCODE_{i}_RDY" for i in range(1, n_simocode + 1))
        any_flt = " OR ".join(f"SIMOCODE_{i}_FLT" for i in range(1, n_simocode + 1))
        conditions.append({"condition": f"ANY_FAULT := {any_flt}", "priority": "high"})
        for state, out in zip(state_names, out_names):
            conditions.append({"condition":
                f"IF START_PB AND NOT STOP_PB AND E_STOP AND NOT ANY_FAULT AND {all_rdy} THEN {state} := TRUE",
                "priority": "high"})
            conditions.append({"condition":
                f"IF STOP_PB OR NOT E_STOP OR ANY_FAULT THEN {state} := FALSE",
                "priority": "high"})
            conditions.append({"condition": f"{out} := {state}", "priority": "medium"})
    else:
        for state, out in zip(state_names, out_names):
            conditions.append({"condition":
                f"IF START_PB AND NOT STOP_PB AND E_STOP THEN {state} := TRUE",
                "priority": "high"})
            conditions.append({"condition":
                f"IF STOP_PB OR NOT E_STOP THEN {state} := FALSE",
                "priority": "high"})
            conditions.append({"condition": f"{out} := {state}", "priority": "medium"})

    # ── Test cases ────────────────────────────────────────────────────────────
    first_out = out_names[0] if out_names else "OUTPUT_1"

    def _base(start, stop, estop, **extra):
        d = {"START_PB": start, "STOP_PB": stop, "E_STOP": estop}
        if n_simocode > 0:
            for i in range(1, n_simocode + 1):
                d[f"SIMOCODE_{i}_RDY"] = extra.pop(f"SIMOCODE_{i}_RDY", True)
                d[f"SIMOCODE_{i}_FLT"] = extra.pop(f"SIMOCODE_{i}_FLT", False)
        d.update(extra)
        return d

    test_cases = [
        {"id": "TC01", "description": "Normal start — all SIMOCODE ready, E-STOP healthy",
         "inputs": _base(True, False, True),
         "expected_outputs": {first_out: True},
         "pre_state": {s: False for s in state_names}},
        {"id": "TC02", "description": "Stop command",
         "inputs": _base(False, True, True),
         "expected_outputs": {first_out: False},
         "pre_state": {s: True for s in state_names}},
        {"id": "TC03", "description": "E-STOP activated",
         "inputs": _base(True, False, False),
         "expected_outputs": {first_out: False},
         "pre_state": {s: True for s in state_names}},
        {"id": "TC04", "description": "Idle — no start command",
         "inputs": _base(False, False, True),
         "expected_outputs": {first_out: False},
         "pre_state": {s: False for s in state_names}},
    ]
    if n_simocode > 0:
        fault_inputs = _base(False, False, True)
        fault_inputs["SIMOCODE_1_FLT"] = True
        test_cases.append({
            "id": "TC05", "description": "SIMOCODE 1 fault — output must stop",
            "inputs": fault_inputs,
            "expected_outputs": {first_out: False},
            "pre_state": {s: True for s in state_names}
        })
        not_rdy = _base(True, False, True)
        not_rdy[f"SIMOCODE_{n_simocode}_RDY"] = False
        test_cases.append({
            "id": "TC06", "description": f"SIMOCODE {n_simocode} not ready — start blocked",
            "inputs": not_rdy,
            "expected_outputs": {first_out: False},
            "pre_state": {s: False for s in state_names}
        })

    # ── System name ───────────────────────────────────────────────────────────
    skip_words = {"i", "a", "an", "the", "to", "have", "need", "with", "and",
                  "or", "of", "in", "is", "by", "be", "my", "we", "for", "that"}
    name_words = [w.capitalize() for w in words if w.isalpha() and w not in skip_words][:4]
    sname = "".join(name_words) or "ControlSystem"

    # ── Complexity ────────────────────────────────────────────────────────────
    n_out = len(outputs)
    n_tim = len(timers)
    n_cnt = len(counters)
    if n_out >= 5 or n_tim >= 4 or n_cnt >= 3:
        complexity = "high"
    elif n_out >= 3 or n_tim >= 2 or n_cnt >= 1:
        complexity = "medium"
    else:
        complexity = "low"

    return {
        "system_name":         sname,
        "description":         raw_req[:120],
        "complexity":          complexity,
        "inputs":              inputs,
        "outputs":             outputs,
        "timers":              timers,
        "counters":            counters,
        "internal_variables":  internals,
        "interlocks":          interlocks,
        "control_conditions":  conditions,
        "test_cases":          test_cases,
    }


# ─── Helpers ────────────────────────────────────────────────────────────────

def _get_tasks(include_llm_tasks: bool = False) -> list[dict]:
    tasks = []
    for p in sorted(config.BENCHMARK_DIR.glob("*.json")):
        t = json.loads(p.read_text(encoding="utf-8"))
        if not include_llm_tasks and t.get("task_source") == "ai_builder":
            continue
        task_id = t.get("task_id") or t.get("system_name") or p.stem
        tasks.append({
            "id":         task_id,
            "scenario":   t.get("scenario", ""),
            "complexity": t.get("complexity", ""),
            "tc_count":   len(t.get("test_cases", [])),
            "has_ref":    bool(t.get("reference_st_code", "")),
        })
    return tasks


def _get_logs() -> list[dict]:
    from collections import defaultdict
    # Cache task sources to avoid re-reading JSON files repeatedly
    _task_source_cache: dict = {}
    def _task_source(task_id: str) -> str:
        if task_id not in _task_source_cache:
            p = config.BENCHMARK_DIR / f"{task_id}.json"
            try:
                t = json.loads(p.read_text(encoding="utf-8"))
                _task_source_cache[task_id] = t.get("task_source", "benchmark")
            except Exception:
                _task_source_cache[task_id] = "benchmark"
        return _task_source_cache[task_id]

    logs = []
    for p in sorted(config.EXPERIMENT_LOGS.glob("*.json"), reverse=True):
        if p.name.startswith("_"):
            continue
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            d["_filename"] = p.name
            d["filename"]  = p.name
            # Enrich with task source (benchmark vs ai_builder)
            d.setdefault("task_source", _task_source(d.get("task_id", "")))
            logs.append(d)
        except Exception:
            pass

    # Auto-assign experiment_number to logs that don't have one.
    # Group by calendar date of the timestamp; assign sequential numbers
    # in chronological order so earlier runs get lower experiment numbers.
    unassigned = [l for l in logs if not l.get("experiment_number")]
    if unassigned:
        dates = sorted(set(
            l.get("timestamp", "")[:10]
            for l in unassigned
            if l.get("timestamp", "")[:10]
        ))
        date_to_exp = {d: i + 1 for i, d in enumerate(dates)}
        for l in unassigned:
            day = l.get("timestamp", "")[:10]
            l["experiment_number"] = date_to_exp.get(day, 0)
    return logs


def _table_csv_value(log: dict, key: str):
    if key == "Task":
        return log.get("task_id", "")
    if key == "Source":
        return "LLM Built" if log.get("task_source") == "ai_builder" else "Benchmark"
    if key == "Condition":
        condition = (log.get("condition") or "").strip().lower()
        labels = {
            "framework": "Framework",
            "direct_llm": "Direct LLM",
            #"manual": "Manual",
        }
        return labels.get(condition, condition.replace("_", " ").title() if condition else "")
    if key == "RAG":
        rag = log.get("rag_used")
        if rag is True:
            return "On"
        if rag is False:
            return "Off"
        return ""
    if key == "Complexity":
        complexity = (log.get("complexity") or "").strip()
        return complexity.capitalize() if complexity else ""
    if key == "Compiled":
        compiled = log.get("compilation_success")
        if compiled is True:
            return "Yes"
        if compiled is False:
            return "No"
        return ""
    if key == "Correctness":
        fc = log.get("functional_correctness_rate")
        if fc is None:
            return ""
        return f"{round(fc * 100)}%"
    if key == "BLEU":
        bleu = log.get("bleu_score")
        return f"{bleu:.3f}" if bleu is not None else ""
    if key == "Halluc.":
        halluc = log.get("hallucination_rate")
        if halluc is None:
            return ""
        return f"{round(halluc * 100)}%"
    if key == "Coverage":
        coverage = log.get("statement_coverage")
        if coverage is None:
            return ""
        return f"{round(coverage * 100)}%"
    if key == "Iter.":
        iterations = log.get("iterations_needed")
        return "" if iterations is None else iterations
    if key == "Timestamp":
        return log.get("timestamp", "")
    return ""


def _build_experiment_table_csv(logs: list[dict]) -> str:
    import csv
    import io

    fields = [
        "Task",
        "Source",
        "Condition",
        "RAG",
        "Complexity",
        "Compiled",
        "Correctness",
        "BLEU",
        "Halluc.",
        "Coverage",
        "Iter.",
        "Timestamp",
    ]
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields)
    writer.writeheader()
    for log in logs:
        row = {field: _table_csv_value(log, field) for field in fields}
        writer.writerow(row)
    return buf.getvalue()


def _next_experiment_number() -> int:
    nums = [lg.get("experiment_number") for lg in _get_logs() if lg.get("experiment_number")]
    return (max(nums) + 1) if nums else 1


def _resolve_generated_code_path(task_id: str, prompt_style: str = "standard", condition: str | None = None) -> Path | None:
    candidates: list[Path] = []
    if condition:
        candidates.append(config.GENERATED_CODE / f"{task_id}_{condition}_{prompt_style}.st")
    candidates.append(config.GENERATED_CODE / f"{task_id}_{prompt_style}.st")
    if condition == "manual":
        candidates.append(config.GENERATED_CODE / f"{task_id}_manual.st")
    for suffix in ["standard", "chain_of_thought", "program_of_thought", "manual"]:
        if condition:
            candidates.append(config.GENERATED_CODE / f"{task_id}_{condition}_{suffix}.st")
        candidates.append(config.GENERATED_CODE / f"{task_id}_{suffix}.st")

    seen = set()
    for p in candidates:
        key = str(p)
        if key in seen:
            continue
        seen.add(key)
        if p.exists():
            return p
    return None


def _get_log(filename: str) -> dict | None:
    path = config.EXPERIMENT_LOGS / filename
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _save_log(filename: str, data: dict) -> None:
    path = config.EXPERIMENT_LOGS / filename
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ── Thread-local stdout router ───────────────────────────────────────────────
# Installed ONCE at startup. Each worker thread sets _run_tls.queue = q so its
# print() calls route only to its own SSE queue. Prints from other concurrent
# or lingering threads are silently ignored for that queue.
_run_tls = threading.local()

class _StdoutRouter:
    """Process-wide stdout proxy that routes each write to the calling thread's queue."""
    def __init__(self, orig):
        self._orig = orig
    def write(self, text):
        q = getattr(_run_tls, 'queue', None)
        if q and text.strip():
            q.put(("log", text.rstrip()))
        self._orig.write(text)
    def flush(self):
        self._orig.flush()
    def isatty(self):
        return False

sys.stdout = _StdoutRouter(sys.__stdout__)


def _stream_run(run_id: str, fn, *args, **kwargs):
    """Execute fn(*args) in a thread, capture print() output, push to SSE queue."""
    q = queue.Queue()
    _run_queues[run_id] = q

    def _worker():
        _run_tls.queue = q        # bind this thread's prints to this run's queue
        try:
            result = fn(*args, **kwargs)
            q.put(("done", json.dumps(result, default=str) if result else "{}"))
        except Exception as e:
            tb = traceback.format_exc()
            es = str(e)
            provider = config.active_provider()

            is_gemini_quota = (
                "RESOURCE_EXHAUSTED" in es or "free_tier" in es or "PerDay" in es
                or ("429" in es and ("gemini" in es.lower() or "generativelanguage" in es))
            )
            is_gemini_key = provider == "gemini" and (
                "API_KEY_INVALID" in es or "API key expired" in es or "API key not valid" in es
                or "Invalid API key" in es or "Incorrect API key" in es
                or "AuthenticationError" in tb
                or (("400" in es or "401" in es) and ("gemini" in es.lower() or "generativelanguage" in es))
            )
            is_openrouter_credit = (
                provider == "openai_compatible"
                and "openrouter" in str(config.LLM_PROVIDER).lower()
                and (
                    "Error code: 402" in es
                    or "requires more credits" in es.lower()
                    or "can only afford" in es.lower()
                )
            )

            if "insufficient_quota" in es:
                friendly = (
                    "OpenAI quota exhausted — your account has no remaining credits.\n"
                    "  Fix option 1: Add billing credits at https://platform.openai.com/settings/billing\n"
                    "  Fix option 2: Set MOCK_LLM=true in your .env file, then restart the server."
                )
                q.put(("error", friendly))
            elif is_gemini_quota:
                friendly = (
                    "Gemini free-tier quota reached — the daily limit of 20 requests/day for "
                    f"'{config.GEMINI_MODEL}' is used up (each run makes several Gemini calls: "
                    "analysis, generation, semantic refiner, spec judge).\n"
                    "  • Free quota resets daily (~midnight US Pacific) — try again after reset.\n"
                    "  • OR put a different Gemini API key (NEW Google Cloud project = fresh 20/day) "
                    "in GEMINI_API_KEY in .env, then restart the server.\n"
                    "  • OR enable billing on your Gemini project to remove the daily cap.\n"
                    "This run failed before finishing, so nothing was saved to the experiment logs "
                    "(your existing logs/results are untouched)."
                )
                # Emit a dedicated event so the UI can offer a one-click switch to
                # Ollama (local, no quota) and re-run THIS task. Falling back keeps
                # all prior work intact — only a fresh Ollama log is added on retry.
                q.put(("quota_switch", friendly))
            elif is_gemini_key:
                friendly = (
                    "Gemini API key problem — the key in GEMINI_API_KEY is invalid or expired "
                    "(Google reports API_KEY_INVALID / 'API key expired').\n"
                    "  • Keys starting with 'AQ.' are short-lived ephemeral tokens that expire quickly — "
                    "use a long-lived AI Studio key (starts with 'AIzaSy') from "
                    "https://aistudio.google.com/apikey.\n"
                    "  • Put a valid GEMINI_API_KEY in .env, then restart the server.\n"
                    "This run failed before finishing, so nothing was saved to the experiment logs "
                    "(your existing logs/results are untouched)."
                )
                q.put(("quota_switch", friendly))
            elif is_openrouter_credit:
                friendly = (
                    "OpenRouter credit limit reached for this request size.\n"
                    "  • Your current balance cannot cover the requested output tokens.\n"
                    "  • Add credits at https://openrouter.ai/settings/credits, OR lower token budget "
                    "(LLM_GENERATION_MAX_TOKENS in .env).\n"
                    "  • You can also retry with local Ollama from the quota switch prompt.\n"
                    "This run failed before finishing, so no new experiment log was written."
                )
                q.put(("quota_switch", friendly))
            elif "model_not_found" in es or "NotFoundError" in tb:
                friendly = (
                    f"Model not found — your API key cannot access '{config.LLM_MODEL}'.\n"
                    "  Change LLM_MODEL in .env to gpt-4o-mini or gpt-3.5-turbo."
                )
                q.put(("error", friendly))
            elif "AuthenticationError" in tb or "Incorrect API key" in es:
                q.put(("error", "Invalid OpenAI API key. Check OPENAI_API_KEY in your .env file."))
            else:
                q.put(("error", tb))
        finally:
            _run_tls.queue = None  # detach: stray prints from this thread no longer leak
            q.put(("end", ""))
            _release_run_slot(run_id)
            _run_queues.pop(run_id, None)

    threading.Thread(target=_worker, daemon=True).start()


# ─── Routes: Dashboard ───────────────────────────────────────────────────────

@app.route("/")
def index():
    from collections import defaultdict
    from src.evaluator import load_all_logs, summarize_results

    tasks   = _get_tasks()
    logs    = _get_logs()
    conditions = {"framework": 0, "direct_llm": 0, "manual": 0}
    ai_task_count = sum(1 for lg in logs if lg.get("task_source") == "ai_builder")
    for lg in logs:
        cond = lg.get("condition", "")
        if cond in conditions:
            conditions[cond] += 1

    # Experiment groups
    exp_groups: dict = defaultdict(list)
    for lg in logs:
        exp_groups[lg.get("experiment_number", 0)].append(lg)
    exp_summary = []
    for exp_num in sorted(exp_groups.keys(), reverse=True):  # latest first
        entries = exp_groups[exp_num]
        n_rag    = sum(1 for e in entries if e.get("rag_used"))
        n_no_rag = sum(1 for e in entries if e.get("rag_used") is False)
        n_ai     = sum(1 for e in entries if e.get("task_source") == "ai_builder")
        dates    = sorted(set(e.get("timestamp","")[:10] for e in entries if e.get("timestamp")))
        exp_summary.append({
            "number":    exp_num,
            "count":     len(entries),
            "n_rag":     n_rag,
            "n_no_rag":  n_no_rag,
            "n_ai":      n_ai,
            "date":      dates[-1] if dates else "",
            "conditions": list(set(e.get("condition") for e in entries)),
        })
    next_exp = (max(exp_groups.keys(), default=0) + 1) if exp_groups else 1

    # Analytics summary for dashboard charts
    raw_logs = load_all_logs(str(config.EXPERIMENT_LOGS))
    summary  = summarize_results(raw_logs) if raw_logs else {}

    CONDITIONS   = ["framework", "direct_llm"]
    COMPLEXITIES = ["low", "medium", "high"]

    # Per-complexity data
    cplx_map: dict = defaultdict(lambda: defaultdict(list))
    for log in raw_logs:
        cplx = log.get("complexity") or "unknown"
        cond = log.get("condition", "unknown")
        cplx_map[cplx][cond].append(log)

    per_complexity: dict = {}
    for cplx, cond_logs in cplx_map.items():
        per_complexity[cplx] = {}
        for cond, entries in cond_logs.items():
            def _avg2(key, ents=entries):
                vals = [e[key] for e in ents if e.get(key) is not None]
                return round(sum(vals) / len(vals), 4) if vals else None
            def _rate2(key, ents=entries):
                vals = [e[key] for e in ents if e.get(key) is not None]
                return round(sum(bool(v) for v in vals) / len(vals), 4) if vals else None
            per_complexity[cplx][cond] = {
                "compilation_success_rate":   _rate2("compilation_success"),
                "avg_functional_correctness": _avg2("functional_correctness_rate"),
                "avg_bleu_score":             _avg2("bleu_score"),
                "avg_hallucination_rate":     _avg2("hallucination_rate"),
                "avg_statement_coverage":     _avg2("statement_coverage"),
                "n": len(entries),
            }

    complexity_list = [c for c in COMPLEXITIES if c in per_complexity]

    return render_template("index.html",
                           tasks=tasks, logs=logs[:8],
                           conditions=conditions, total_logs=len(logs),
                           ai_task_count=ai_task_count,
                           exp_summary=exp_summary, next_exp=next_exp,
                           summary=summary, per_complexity=per_complexity,
                           complexity_list=complexity_list,
                           dash_conditions=CONDITIONS)


# ─── Routes: Run Experiment ──────────────────────────────────────────────────

@app.route("/run")
def run_page():
    tasks = _get_tasks()
    return render_template("run.html", tasks=tasks)


@app.route("/run/default-sequence")
def default_sequence_page():
    sequence = _full_sequence_with_labels()
    tasks = _get_tasks()
    return render_template("default_sequence.html",
                           tasks=tasks,
                           task_count=len(tasks),
                           default_task_id=(tasks[0]["id"] if tasks else ""),
                           sequence=sequence,
                           next_exp=_next_experiment_number())


# ─── Elicitation API ─────────────────────────────────────────────────────────

@app.route("/api/elicit/questions/<task_id>")
def elicit_questions(task_id: str):
    """Return scenario questions + current normalized requirement for a task."""
    from src.elicitor import get_steps, STEP_LABELS
    task_path = config.BENCHMARK_DIR / f"{task_id}.json"
    if not task_path.exists():
        return jsonify({"error": "task not found"}), 404
    task = json.loads(task_path.read_text(encoding="utf-8"))
    scenario = task.get("scenario", "")
    steps    = get_steps(scenario)
    return jsonify({
        "task_id":     task_id,
        "scenario":    scenario,
        "complexity":  task.get("complexity", ""),
        "step_labels": STEP_LABELS,
        "steps":       {str(k): v for k, v in steps.items()},
        "normalized":  task.get("normalized_requirement", {}),
        "raw":         task.get("raw_requirement", ""),
    })


@app.route("/api/elicit/preview", methods=["POST"])
def elicit_preview():
    """Apply elicited answers and return a preview of the enriched requirement."""
    from src.elicitor import enrich_requirement
    from src.normalizer import format_for_prompt
    data    = request.json or {}
    task_id = data.get("task_id")
    answers = data.get("answers", {})
    task_path = config.BENCHMARK_DIR / f"{task_id}.json"
    if not task_path.exists():
        return jsonify({"error": "task not found"}), 404
    task     = json.loads(task_path.read_text(encoding="utf-8"))
    enriched = enrich_requirement(task, answers)
    req_str  = format_for_prompt(enriched["normalized_requirement"])
    return jsonify({
        "normalized": enriched["normalized_requirement"],
        "req_str":    req_str,
        "raw":        enriched.get("raw_requirement", ""),
    })


@app.route("/run/start", methods=["POST"])
def run_start():
    task_id        = request.form.get("task_id", "motor_control_low")
    condition      = request.form.get("condition", "framework")
    prompt         = request.form.get("prompt", "standard")
    answers_json   = request.form.get("answers", "")
    exp_num_raw    = request.form.get("experiment_number", "").strip()
    rag_enabled    = request.form.get("rag_enabled", "true").lower() in ("1", "true", "yes", "on")
    force_provider = request.form.get("force_provider", "").strip().lower() or None
    # Assign a real, incrementing experiment number up front when the field is
    # blank. Leaving it None makes _get_logs() collapse every run on the same
    # calendar date into a single experiment bucket (so the counter appeared
    # stuck at ~2). This mirrors /tasks/run-custom and /run/default-sequence.
    experiment_number = int(exp_num_raw) if exp_num_raw.isdigit() else _next_experiment_number()
    run_id         = f"{task_id}_{condition}_{int(time.time())}"

    def _execute():
        from main import load_task
        from src.elicitor import enrich_requirement

        # Resolve task list (single task or all)
        if task_id == "all":
            task_ids = [t["id"] for t in _get_tasks()]
        else:
            task_ids = [task_id]

        # Only validate config once if we actually need the LLM
        if condition in ("framework", "direct_llm"):
            config.validate_config(provider=force_provider)

        client = _make_openai_client(force_provider=force_provider)
        results = []

        for tid in task_ids:
            if len(task_ids) > 1:
                print(f"\n{'='*50}\n  Processing: {tid}\n{'='*50}")
            task = load_task(tid)
            task = _canonicalize_task_like_builder(task)

            # Apply elicited answers if provided (single-task only)
            if answers_json and task_id != "all":
                try:
                    answers = json.loads(answers_json)
                    if answers:
                        task = enrich_requirement(task, answers)
                        print("[Elicitor] Requirement enriched with user answers.")
                except Exception as e:
                    print(f"[Elicitor] Warning: could not apply answers: {e}")

            r = _run_with_timeout(
                _run_task_for_condition,
                task=task,
                condition=condition,
                prompt_style=prompt,
                client=client,
                experiment_number=experiment_number,
                rag_enabled=rag_enabled,
                timeout_secs=0,  # No timeout; allow generation to complete naturally
            )

            if r:
                results.append(r)

        # Return last result for display (or aggregated summary)
        if len(results) == 1:
            return results[0]
        if results:
            summary = _summarize_results(results)
            print(f"\n{'='*50}")
            print(f"  ALL TASKS COMPLETE: {len(results)} tasks")
            print(f"  Tests : {summary['tests_passed']}/{summary['tests_total']} passed")
            print(f"  BLEU  : {summary['avg_bleu']:.3f} avg")
            print(f"  Compiled: {summary['compiled']}/{len(results)}")
            print(f"{'='*50}")
            return {
                "all_tasks": True,
                "count": len(results),
                "tests_passed": summary["tests_passed"],
                "tests_total": summary["tests_total"],
                "avg_bleu": summary["avg_bleu"],
                "compiled": summary["compiled"],
            }
        return None

    _stream_run(run_id, _execute)
    return jsonify({"run_id": run_id})


@app.route("/run/default-sequence/start", methods=["POST"])
def default_sequence_start():
    exp_num_raw = request.form.get("experiment_number", "").strip()
    rag_enabled = request.form.get("rag_enabled", "true").lower() in ("1", "true", "yes", "on")
    selected_task_id = request.form.get("selected_task_id", "").strip()
    run_mode = request.form.get("run_mode", "full").strip().lower()
    if run_mode not in ("full", "fast"):
        run_mode = "full"
    top_n_raw = request.form.get("top_combinations", "2").strip()
    fast_top_n = int(top_n_raw) if top_n_raw.isdigit() else 2
    fast_top_n = max(1, min(fast_top_n, len(FULL_SIX_COMBINATION_SEQUENCE)))
    screen_raw = request.form.get("screen_task_count", "3").strip()
    screen_task_count = int(screen_raw) if screen_raw.isdigit() else 3
    experiment_number = int(exp_num_raw) if exp_num_raw.isdigit() else _next_experiment_number()
    run_id = f"default_sequence_{run_mode}_{experiment_number}_{int(time.time())}"

    sequence = FULL_SIX_COMBINATION_SEQUENCE

    def _execute():
        from main import load_task

        task_summaries = _get_tasks()
        all_task_ids = [t["id"] for t in task_summaries]
        if selected_task_id and selected_task_id in all_task_ids:
            task_ids = [selected_task_id]
        else:
            task_ids = all_task_ids

        # Fast mode needs multiple tasks for screening. Fall back for single-task runs.
        effective_run_mode = run_mode
        if effective_run_mode == "fast" and len(task_ids) < 2:
            effective_run_mode = "full"
            print("[Fast Mode] Only one task selected; switching to full mode.")

        config.validate_config()
        client = _make_openai_client()
        results = []
        prepared_tasks: dict[str, dict] = {}

        for tid in task_ids:
            task = load_task(tid)
            task = _canonicalize_task_like_builder(task)
            prepared_tasks[tid] = task

        print(f"\n{'='*70}")
        title = "DEFAULT SEQUENCE RUN" if effective_run_mode == "full" else "FAST DEFAULT SEQUENCE RUN"
        print(f"  {title}")
        print(f"  Experiment Number : {experiment_number}")
        if len(task_ids) == 1:
            print(f"  Selected Task     : {task_ids[0]}")
        else:
            print(f"  Default Tasks     : {len(task_ids)}")
        print(f"  Combinations      : {len(sequence)}")
        if effective_run_mode == "fast":
            print(f"  Screening Tasks   : {max(1, min(screen_task_count, len(task_ids)))}")
            print(f"  Top Combos Kept   : {fast_top_n}")
        print(f"{'='*70}")

        if effective_run_mode == "full":
            for idx, (condition, prompt_style) in enumerate(sequence, start=1):
                print(f"\n{'-'*70}")
                print(f"  Sequence {idx}/{len(sequence)} : {condition} | {prompt_style}")
                print(f"{'-'*70}")
                for tid in task_ids:
                    print(f"\n[Sequence] Running task '{tid}' with {condition} / {prompt_style}")
                    task = dict(prepared_tasks[tid])
                    try:
                        r = _run_with_timeout(
                            _run_task_for_condition,
                            task=task,
                            condition=condition,
                            prompt_style=prompt_style,
                            client=client,
                            experiment_number=experiment_number,
                            rag_enabled=rag_enabled,
                            timeout_secs=0,  # No timeout; allow generation to complete naturally
                        )
                        if r:
                            results.append(r)
                    except Exception as exc:  # noqa: BLE001
                        print(
                            f"[Sequence] ERROR for {tid} / {condition} / {prompt_style}: {exc}"
                        )
                        traceback.print_exc()
                        # Save a partial error log so the run appears in results
                        try:
                            from src.evaluator import save_log, create_experiment_log
                            _err_task = dict(prepared_tasks[tid])
                            _err_log = create_experiment_log(tid, condition, _err_task.get("complexity", "unknown"))
                            _err_log["experiment_number"] = experiment_number
                            _err_log["prompt_style"] = prompt_style
                            _err_log["rag_used"] = rag_enabled
                            _err_log["pipeline_error"] = str(exc)
                            _err_log["compilation_success"] = False
                            save_log(_err_log, str(config.EXPERIMENT_LOGS))
                            print(f"[Sequence] Partial error log saved for {tid} / {condition} / {prompt_style}.")
                        except Exception as _save_exc:  # noqa: BLE001
                            print(f"[Sequence] Could not save error log: {_save_exc}")
                        continue
        else:
            screening_ids = _select_screening_tasks(task_summaries, target_count=screen_task_count)
            remaining_ids = [tid for tid in task_ids if tid not in set(screening_ids)]
            screen_by_combo: dict[tuple[str, str], list[dict]] = {k: [] for k in sequence}

            print(f"\n[Fast Mode] Stage 1/2: screening on {len(screening_ids)} representative task(s):")
            print("  " + ", ".join(screening_ids))

            for idx, (condition, prompt_style) in enumerate(sequence, start=1):
                print(f"\n{'-'*70}")
                print(f"  Stage 1 Combo {idx}/{len(sequence)} : {condition} | {prompt_style}")
                print(f"{'-'*70}")
                for tid in screening_ids:
                    print(f"\n[Screen] Running task '{tid}' with {condition} / {prompt_style}")
                    task = dict(prepared_tasks[tid])
                    r = _run_with_timeout(
                        _run_task_for_condition,
                        task=task,
                        condition=condition,
                        prompt_style=prompt_style,
                        client=client,
                        experiment_number=experiment_number,
                        rag_enabled=rag_enabled,
                        timeout_secs=0,  # No timeout; allow generation to complete naturally
                    )
                    if r:
                        results.append(r)
                        screen_by_combo[(condition, prompt_style)].append(r)

            ranked = sorted(
                sequence,
                key=lambda combo: _combination_score(screen_by_combo.get(combo, [])),
                reverse=True,
            )
            shortlisted = ranked[:fast_top_n]

            print(f"\n[Fast Mode] Stage 1 complete. Top {len(shortlisted)} combination(s):")
            for i, combo in enumerate(shortlisted, start=1):
                label = _sequence_label(combo[0], combo[1])
                score = _combination_score(screen_by_combo.get(combo, []))
                print(f"  {i}. {label}  (score={score:.3f})")

            print(f"\n[Fast Mode] Stage 2/2: running shortlisted combinations on remaining {len(remaining_ids)} task(s).")
            for idx, (condition, prompt_style) in enumerate(shortlisted, start=1):
                print(f"\n{'-'*70}")
                print(f"  Stage 2 Combo {idx}/{len(shortlisted)} : {condition} | {prompt_style}")
                print(f"{'-'*70}")
                for tid in remaining_ids:
                    print(f"\n[Shortlist] Running task '{tid}' with {condition} / {prompt_style}")
                    task = dict(prepared_tasks[tid])
                    r = _run_with_timeout(
                        _run_task_for_condition,
                        task=task,
                        condition=condition,
                        prompt_style=prompt_style,
                        client=client,
                        experiment_number=experiment_number,
                        rag_enabled=rag_enabled,
                        timeout_secs=0,  # No timeout; allow generation to complete naturally
                    )
                    if r:
                        results.append(r)

        summary = _summarize_results(results)

        print(f"\n{'='*70}")
        print(f"  DEFAULT SEQUENCE COMPLETE")
        print(f"  Total runs : {summary['count']}")
        print(f"  Compiled   : {summary['compiled']}/{summary['count']}")
        print(f"  Tests      : {summary['tests_passed']}/{summary['tests_total']} passed")
        print(f"  Avg BLEU   : {summary['avg_bleu']:.3f}")
        print(f"{'='*70}")
        resp = {
            "all_tasks": len(task_ids) > 1,
            "sequence_run": True,
            "experiment_number": experiment_number,
            "run_mode": effective_run_mode,
            "selected_task_id": (task_ids[0] if len(task_ids) == 1 else None),
            "count": summary["count"],
            "compiled": summary["compiled"],
            "tests_passed": summary["tests_passed"],
            "tests_total": summary["tests_total"],
            "avg_bleu": summary["avg_bleu"],
        }
        if effective_run_mode == "fast":
            resp["screened_tasks"] = max(1, min(screen_task_count, len(task_ids)))
            resp["top_combinations"] = fast_top_n
        return resp

    _stream_run(run_id, _execute)
    return jsonify({"run_id": run_id, "experiment_number": experiment_number})


@app.route("/run/stream/<run_id>")
def run_stream(run_id: str):
    def _generate():
        q = _run_queues.get(run_id)
        if not q:
            yield "data: {\"type\": \"error\", \"msg\": \"Run not found\"}\n\n"
            return
        while True:
            try:
                kind, msg = q.get(timeout=60)
                payload = json.dumps({"type": kind, "msg": msg})
                yield f"data: {payload}\n\n"
                if kind in ("done", "error", "end"):
                    break
            except queue.Empty:
                yield "data: {\"type\": \"ping\"}\n\n"

    return Response(stream_with_context(_generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ─── Routes: Manual Entry (decommissioned) ───────────────────────────────────

@app.route("/manual")
def manual_page():
    flash("Manual Entry has been removed from this UI. Use Run Experiment / Default Sequence.", "warning")
    return redirect(url_for("run_page"))


@app.route("/manual/submit", methods=["POST"])
def manual_submit():
    return jsonify({
        "success": False,
        "error": "Manual Entry has been decommissioned in this UI.",
    }), 410


# ─── Routes: Results ─────────────────────────────────────────────────────────

@app.route("/results-review")
def results_review_page():
    """Editable duplicate of the Results page — per-log metric override mode."""
    from src.evaluator import load_all_logs, summarize_results
    from collections import defaultdict
    logs    = _get_logs()
    all_raw = load_all_logs(str(config.EXPERIMENT_LOGS))
    summary = summarize_results(all_raw) if all_raw else {}
    expected_set = set(FULL_SIX_COMBINATION_SEQUENCE)
    groups: dict[int, list[dict]] = defaultdict(list)
    for lg in logs:
        exp_num = lg.get("experiment_number")
        if exp_num is not None:
            groups[exp_num].append(lg)
    exp_diag: dict[int, dict] = {}
    for exp_num, entries in groups.items():
        benchmark_entries = [e for e in entries if e.get("task_source") != "ai_builder"]
        found_set = {
            (e.get("condition"), e.get("prompt_style"))
            for e in benchmark_entries
            if e.get("condition") in ("framework", "direct_llm")
            and e.get("prompt_style") in ("standard", "chain_of_thought", "program_of_thought")
        }
        found_expected = expected_set.intersection(found_set)
        expected_labels = {
            ("framework", "standard"): "Framework - Standard",
            ("framework", "chain_of_thought"): "Framework - Chain of Thought",
            ("framework", "program_of_thought"): "Framework - Program of Thought",
            ("direct_llm", "standard"): "Direct LLM - Standard",
            ("direct_llm", "chain_of_thought"): "Direct LLM - Chain of Thought",
            ("direct_llm", "program_of_thought"): "Direct LLM - Program of Thought",
        }
        missing = [expected_labels[c] for c in FULL_SIX_COMBINATION_SEQUENCE if c not in found_expected]
        exp_diag[exp_num] = {
            "expected": len(expected_set), "found": len(found_expected),
            "complete": len(found_expected) == len(expected_set), "missing": missing,
        }
    return render_template("results_review.html", logs=logs, summary=summary, exp_diag=exp_diag)


@app.route("/dashboard")
def dashboard_page():
    """Dashboard with charts from Evaluation_Summary_All_Tasks.xlsx."""
    import openpyxl
    from collections import defaultdict
    from src.evaluator import load_all_logs, summarize_results as _summarize_rq

    # Load experiment-log summary for BLEU / Hallucination
    try:
        all_raw = load_all_logs(str(config.EXPERIMENT_LOGS))
        log_summary = _summarize_rq(all_raw) if all_raw else {}
    except OSError:
        log_summary = {}
    fw_s = log_summary.get("framework", {})
    dl_s = log_summary.get("direct_llm", {})

    xlsx_path = Path(__file__).parent / "Evaluation_Summary_All_Tasks.xlsx"
    rows = []
    if xlsx_path.exists():
        wb = openpyxl.load_workbook(str(xlsx_path), data_only=True)
        ws = wb["Summary"]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[0]:
                continue
            task = str(row[0]).strip()
            method = str(row[1]).strip() if row[1] else ""
            compile_str = str(row[2]).strip() if row[2] else ""
            test_str = str(row[3]).strip() if row[3] else "0%"
            cov_str = str(row[4]).strip() if row[4] else "0%"
            spec_str = str(row[5]).strip() if row[5] else "0%"
            lang_str = str(row[6]).strip() if row[6] else ""
            overall_str = str(row[7]).strip() if row[7] else ""
            compile_pass = "pass" in compile_str.lower() or "\u2713" in compile_str
            test_val = float(test_str.replace("%", "")) if test_str.replace("%", "").replace(".", "").isdigit() else 0
            cov_val = float(cov_str.replace("%", "")) if cov_str.replace("%", "").replace(".", "").isdigit() else 0
            spec_val = float(spec_str.replace("%", "")) if spec_str.replace("%", "").replace(".", "").isdigit() else 0
            overall_pass = "pass" in overall_str.lower() or "\u2713" in overall_str
            lang_full = "4/4" in lang_str
            rows.append({"task": task, "method": method, "compile_pass": compile_pass,
                         "test_pass": test_val, "coverage": cov_val, "spec": spec_val,
                         "overall_pass": overall_pass, "lang_full": lang_full,
                         "test_pass_str": test_str, "coverage_str": cov_str, "spec_str": spec_str,
                         "languages": lang_str, "overall_raw": overall_str})

    tasks_set = sorted({r["task"] for r in rows})
    methods_set = sorted({r["method"] for r in rows})

    fw_rows = [r for r in rows if "Framework" in r["method"]]
    dl_rows = [r for r in rows if "Direct" in r["method"]]
    ai_rows = [r for r in rows if r["method"] and "Framework" not in r["method"] and "Direct" not in r["method"]]
    rag_on_rows = [r for r in rows if "RAG=false" in r["method"]]
    rag_off_rows = [r for r in rows if "RAG=false" not in r["method"]]
    n_tasks = len({r["task"] for r in rows})

    def _avg(lst, key):
        return round(sum(r[key] for r in lst) / len(lst), 1) if lst else 0

    def _compile_rate(lst):
        return round(sum(1 for r in lst if r["compile_pass"]) / len(lst) * 100, 1) if lst else 0

    def _pass_rate(lst):
        return round(sum(1 for r in lst if r["overall_pass"]) / len(lst) * 100, 1) if lst else 0

    def _lang_rate(lst):
        return round(sum(1 for r in lst if r["lang_full"]) / len(lst) * 100, 1) if lst else 0

    # Per-method aggregation
    method_agg = defaultdict(lambda: {"test": [], "cov": [], "spec": [], "compile": [], "lang": [], "overall": []})
    for r in rows:
        method_agg[r["method"]]["test"].append(r["test_pass"])
        method_agg[r["method"]]["cov"].append(r["coverage"])
        method_agg[r["method"]]["spec"].append(r["spec"])
        method_agg[r["method"]]["compile"].append(r["compile_pass"])
        method_agg[r["method"]]["lang"].append(r["lang_full"])
        method_agg[r["method"]]["overall"].append(r["overall_pass"])
    method_labels = sorted(method_agg.keys())
    method_test_avg = [round(sum(method_agg[m]["test"])/len(method_agg[m]["test"]),1) for m in method_labels]
    method_spec_avg = [round(sum(method_agg[m]["spec"])/len(method_agg[m]["spec"]),1) for m in method_labels]
    method_compile_rate = [round(sum(method_agg[m]["compile"])/len(method_agg[m]["compile"])*100,1) for m in method_labels]
    method_lang_rate = [round(sum(method_agg[m]["lang"])/len(method_agg[m]["lang"])*100,1) for m in method_labels]
    method_pass_rate = [round(sum(method_agg[m]["overall"])/len(method_agg[m]["overall"])*100,1) for m in method_labels]

    # Per-task aggregation (overall + split by condition)
    task_agg = defaultdict(lambda: {"test": [], "cov": [], "spec": []})
    task_fw = defaultdict(lambda: {"test": [], "spec": [], "compile": []})
    task_dl = defaultdict(lambda: {"test": [], "spec": [], "compile": []})
    for r in rows:
        task_agg[r["task"]]["test"].append(r["test_pass"])
        task_agg[r["task"]]["cov"].append(r["coverage"])
        task_agg[r["task"]]["spec"].append(r["spec"])
        if "Framework" in r["method"]:
            task_fw[r["task"]]["test"].append(r["test_pass"])
            task_fw[r["task"]]["spec"].append(r["spec"])
            task_fw[r["task"]]["compile"].append(1 if r["compile_pass"] else 0)
        elif "Direct" in r["method"]:
            task_dl[r["task"]]["test"].append(r["test_pass"])
            task_dl[r["task"]]["spec"].append(r["spec"])
            task_dl[r["task"]]["compile"].append(1 if r["compile_pass"] else 0)
    task_labels = sorted(task_agg.keys())
    task_fw_test = [round(sum(task_fw[t]["test"])/len(task_fw[t]["test"]),1) if task_fw[t]["test"] else 0 for t in task_labels]
    task_dl_test = [round(sum(task_dl[t]["test"])/len(task_dl[t]["test"]),1) if task_dl[t]["test"] else 0 for t in task_labels]
    task_fw_spec = [round(sum(task_fw[t]["spec"])/len(task_fw[t]["spec"]),1) if task_fw[t]["spec"] else 0 for t in task_labels]
    task_dl_spec = [round(sum(task_dl[t]["spec"])/len(task_dl[t]["spec"]),1) if task_dl[t]["spec"] else 0 for t in task_labels]

    # Per-prompt-strategy breakdown (Standard / CoT / PoT)
    prompt_labels = ["Standard", "Chain-of-Thought", "Program-of-Thought"]
    def _prompt_filter(lst, kw):
        return [r for r in lst if kw.lower() in r["method"].lower()]
    prompt_fw_compile, prompt_dl_compile = [], []
    prompt_fw_spec, prompt_dl_spec = [], []
    prompt_fw_test, prompt_dl_test = [], []
    # Per-prompt overall metrics (all rows, not split by FW/DL)
    prompt_all_compile, prompt_all_test, prompt_all_cov, prompt_all_spec, prompt_all_pass = [], [], [], [], []
    for kw in ["standard", "chain", "program"]:
        prompt_fw_compile.append(_compile_rate(_prompt_filter(fw_rows, kw)))
        prompt_dl_compile.append(_compile_rate(_prompt_filter(dl_rows, kw)))
        prompt_fw_spec.append(_avg(_prompt_filter(fw_rows, kw), "spec"))
        prompt_dl_spec.append(_avg(_prompt_filter(dl_rows, kw), "spec"))
        prompt_fw_test.append(_avg(_prompt_filter(fw_rows, kw), "test_pass"))
        prompt_dl_test.append(_avg(_prompt_filter(dl_rows, kw), "test_pass"))
        all_kw = _prompt_filter(rows, kw)
        prompt_all_compile.append(_compile_rate(all_kw))
        prompt_all_test.append(_avg(all_kw, "test_pass"))
        prompt_all_cov.append(_avg(all_kw, "coverage"))
        prompt_all_spec.append(_avg(all_kw, "spec"))
        prompt_all_pass.append(_pass_rate(all_kw))

    total_pass = sum(1 for r in rows if r["overall_pass"])
    total_fail = len(rows) - total_pass

    # Per-task per-prompt-strategy aggregation
    task_prompt_data = {}
    task_prompt_compile = {}
    task_prompt_cov = {}
    task_prompt_spec = {}
    for kw, label in [("standard", "Standard"), ("chain", "Chain-of-Thought"), ("program", "Program-of-Thought")]:
        test_vals, compile_vals, cov_vals, spec_vals = [], [], [], []
        for t in task_labels:
            task_rows_kw = [r for r in rows if r["task"] == t and kw in r["method"].lower()]
            test_vals.append(round(sum(r["test_pass"] for r in task_rows_kw) / len(task_rows_kw), 1) if task_rows_kw else 0)
            compile_vals.append(round(sum(1 for r in task_rows_kw if r["compile_pass"]) / len(task_rows_kw) * 100, 1) if task_rows_kw else 0)
            cov_vals.append(round(sum(r["coverage"] for r in task_rows_kw) / len(task_rows_kw), 1) if task_rows_kw else 0)
            spec_vals.append(round(sum(r["spec"] for r in task_rows_kw) / len(task_rows_kw), 1) if task_rows_kw else 0)
        task_prompt_data[label] = test_vals
        task_prompt_compile[label] = compile_vals
        task_prompt_cov[label] = cov_vals
        task_prompt_spec[label] = spec_vals

    # Per-complexity aggregation
    import re
    complexity_map = {}
    for r in rows:
        t = r["task"]
        if "(Low)" in t or "low" in t.lower():
            complexity_map.setdefault("Low", []).append(r)
        elif "(Medium" in t or "medium" in t.lower():
            complexity_map.setdefault("Medium", []).append(r)
        elif "(High)" in t or "high" in t.lower():
            complexity_map.setdefault("High", []).append(r)
        else:
            complexity_map.setdefault("Complex", []).append(r)
    complexity_labels = ["Low", "Medium", "High", "Complex"]
    complexity_fw_test = []
    complexity_dl_test = []
    for clevel in complexity_labels:
        c_rows = complexity_map.get(clevel, [])
        c_fw = [r for r in c_rows if "Framework" in r["method"]]
        c_dl = [r for r in c_rows if "Direct" in r["method"]]
        complexity_fw_test.append(round(sum(r["test_pass"] for r in c_fw) / len(c_fw), 1) if c_fw else 0)
        complexity_dl_test.append(round(sum(r["test_pass"] for r in c_dl) / len(c_dl), 1) if c_dl else 0)

    # Per-complexity all-metric aggregation for conclusion chart
    complexity_compile, complexity_test, complexity_cov, complexity_spec, complexity_pass = [], [], [], [], []
    for clevel in complexity_labels:
        c_rows = complexity_map.get(clevel, [])
        complexity_compile.append(_compile_rate(c_rows))
        complexity_test.append(_avg(c_rows, "test_pass"))
        complexity_cov.append(_avg(c_rows, "coverage"))
        complexity_spec.append(_avg(c_rows, "spec"))
        complexity_pass.append(_pass_rate(c_rows))

    summary = {
        "overall_pass_rate": round(total_pass / len(rows) * 100, 1) if rows else 0,
        "fw_compile_rate": _compile_rate(fw_rows),
        "fw_avg_test": _avg(fw_rows, "test_pass"),
    }
    chart_data = {
        "fw_avg_test": _avg(fw_rows, "test_pass"),
        "fw_avg_cov": _avg(fw_rows, "coverage"),
        "fw_avg_spec": _avg(fw_rows, "spec"),
        "fw_compile_rate": _compile_rate(fw_rows),
        "fw_pass_rate": _pass_rate(fw_rows),
        "fw_lang_rate": _lang_rate(fw_rows),
        "dl_avg_test": _avg(dl_rows, "test_pass"),
        "dl_avg_cov": _avg(dl_rows, "coverage"),
        "dl_avg_spec": _avg(dl_rows, "spec"),
        "dl_compile_rate": _compile_rate(dl_rows),
        "dl_pass_rate": _pass_rate(dl_rows),
        "dl_lang_rate": _lang_rate(dl_rows),
        "total_pass": total_pass,
        "total_fail": total_fail,
        "method_labels": method_labels,
        "method_test_avg": method_test_avg,
        "method_spec_avg": method_spec_avg,
        "method_compile_rate": method_compile_rate,
        "method_lang_rate": method_lang_rate,
        "method_pass_rate": method_pass_rate,
        "task_labels": task_labels,
        "task_fw_test": task_fw_test,
        "task_dl_test": task_dl_test,
        "task_fw_spec": task_fw_spec,
        "task_dl_spec": task_dl_spec,
        "prompt_labels": prompt_labels,
        "prompt_fw_compile": prompt_fw_compile,
        "prompt_dl_compile": prompt_dl_compile,
        "prompt_fw_spec": prompt_fw_spec,
        "prompt_dl_spec": prompt_dl_spec,
        "prompt_fw_test": prompt_fw_test,
        "prompt_dl_test": prompt_dl_test,
        # Prompt strategy overall metrics (conclusion)
        "prompt_all_compile": prompt_all_compile,
        "prompt_all_test": prompt_all_test,
        "prompt_all_cov": prompt_all_cov,
        "prompt_all_spec": prompt_all_spec,
        "prompt_all_pass": prompt_all_pass,
        # Complexity overall metrics (conclusion)
        "complexity_compile": complexity_compile,
        "complexity_test": complexity_test,
        "complexity_cov": complexity_cov,
        "complexity_spec": complexity_spec,
        "complexity_pass": complexity_pass,
        "task_prompt_standard": task_prompt_data["Standard"],
        "task_prompt_cot": task_prompt_data["Chain-of-Thought"],
        "task_prompt_pot": task_prompt_data["Program-of-Thought"],
        "task_prompt_compile_std": task_prompt_compile["Standard"],
        "task_prompt_compile_cot": task_prompt_compile["Chain-of-Thought"],
        "task_prompt_compile_pot": task_prompt_compile["Program-of-Thought"],
        "task_prompt_cov_std": task_prompt_cov["Standard"],
        "task_prompt_cov_cot": task_prompt_cov["Chain-of-Thought"],
        "task_prompt_cov_pot": task_prompt_cov["Program-of-Thought"],
        "task_prompt_spec_std": task_prompt_spec["Standard"],
        "task_prompt_spec_cot": task_prompt_spec["Chain-of-Thought"],
        "task_prompt_spec_pot": task_prompt_spec["Program-of-Thought"],
        "complexity_labels": complexity_labels,
        "complexity_fw_test": complexity_fw_test,
        "complexity_dl_test": complexity_dl_test,
        "fw_bleu": round((fw_s.get("avg_bleu_score") or 0), 4),
        "dl_bleu": round((dl_s.get("avg_bleu_score") or 0), 4),
        "fw_hallucination": round((fw_s.get("avg_hallucination_rate") or 0) * 100, 1),
        "dl_hallucination": round((dl_s.get("avg_hallucination_rate") or 0) * 100, 1),
        # Experiment-log metrics for RQ Summary tabs
        "fw_iterations": round(fw_s.get("avg_iterations") or 0, 1),
        "dl_iterations": round(dl_s.get("avg_iterations") or 0, 1),
        "fw_syntax_errors": round(fw_s.get("avg_syntax_errors_initial") or 0, 1),
        "dl_syntax_errors": round(dl_s.get("avg_syntax_errors_initial") or 0, 1),
        "fw_syntax_errors_final": round(fw_s.get("avg_syntax_errors_final") or 0, 1),
        "dl_syntax_errors_final": round(dl_s.get("avg_syntax_errors_final") or 0, 1),
        "fw_compile_pass": sum(1 for r in fw_rows if r["compile_pass"]),
        "fw_compile_fail": sum(1 for r in fw_rows if not r["compile_pass"]),
        "dl_compile_pass": sum(1 for r in dl_rows if r["compile_pass"]),
        "dl_compile_fail": sum(1 for r in dl_rows if not r["compile_pass"]),
        "fw_inconsistencies": round(fw_s.get("avg_logical_inconsistencies") or 0, 1),
        "dl_inconsistencies": round(dl_s.get("avg_logical_inconsistencies") or 0, 1),
        "fw_semantic_eq": round(fw_s.get("avg_semantic_equivalence") or 0, 2),
        "dl_semantic_eq": round(dl_s.get("avg_semantic_equivalence") or 0, 2),
        "fw_dev_time": round(fw_s.get("avg_dev_time_minutes") or 0, 1),
        "dl_dev_time": round(dl_s.get("avg_dev_time_minutes") or 0, 1),
        "fw_nasa_tlx": round(fw_s.get("avg_nasa_tlx") or 0, 1),
        "dl_nasa_tlx": round(dl_s.get("avg_nasa_tlx") or 0, 1),
        "fw_acceptance": round((fw_s.get("review_accept_rate") or 0) * 100, 1),
        "dl_acceptance": round((dl_s.get("review_accept_rate") or 0) * 100, 1),
        "fw_expert_rating": round(fw_s.get("avg_expert_rating_overall") or 0, 1),
        "dl_expert_rating": round(dl_s.get("avg_expert_rating_overall") or 0, 1),
        # RAG Impact metrics
        "rag_on_compile": _compile_rate(rag_on_rows),
        "rag_off_compile": _compile_rate(rag_off_rows),
        "rag_on_test": _avg(rag_on_rows, "test_pass"),
        "rag_off_test": _avg(rag_off_rows, "test_pass"),
        "rag_on_cov": _avg(rag_on_rows, "coverage"),
        "rag_off_cov": _avg(rag_off_rows, "coverage"),
        "rag_on_spec": _avg(rag_on_rows, "spec"),
        "rag_off_spec": _avg(rag_off_rows, "spec"),
        "rag_on_lang": _lang_rate(rag_on_rows),
        "rag_off_lang": _lang_rate(rag_off_rows),
        "rag_on_pass": _pass_rate(rag_on_rows),
        "rag_off_pass": _pass_rate(rag_off_rows),
        "rag_on_count": len(rag_on_rows),
        "rag_off_count": len(rag_off_rows),
        # Per-task compile rate (FW vs DL)
        "task_fw_compile": [round(sum(task_fw[t]["compile"])/len(task_fw[t]["compile"])*100,1) if task_fw[t]["compile"] else 0 for t in task_labels],
        "task_dl_compile": [round(sum(task_dl[t]["compile"])/len(task_dl[t]["compile"])*100,1) if task_dl[t]["compile"] else 0 for t in task_labels],
    }

    # ── Combination Ranking (Approach × Prompt × RAG) ──
    combo_ranking = []
    for approach_label, approach_kw in [("FW", "Framework"), ("DL", "Direct")]:
        for prompt_label, prompt_kw in [("Std", "standard"), ("CoT", "chain"), ("PoT", "program")]:
            for rag_label, rag_has_false in [("RAG", True), ("NoRAG", False)]:
                subset = [r for r in rows
                          if approach_kw in r["method"]
                          and prompt_kw in r["method"].lower()
                          and ("RAG=false" in r["method"]) == rag_has_false]
                if not subset:
                    continue
                c = _compile_rate(subset)
                t = _avg(subset, "test_pass")
                cv = _avg(subset, "coverage")
                s = _avg(subset, "spec")
                l = _lang_rate(subset)
                p = _pass_rate(subset)
                score = round((c + t + cv + s + l + p) / 6, 1)
                combo_ranking.append({
                    "label": f"{approach_label} + {prompt_label} + {rag_label}",
                    "compile": c, "test": t, "cov": cv, "spec": s,
                    "lang": l, "pass_rate": p, "score": score, "n": len(subset)
                })
    combo_ranking.sort(key=lambda x: x["score"], reverse=True)
    chart_data["combo_ranking"] = combo_ranking

    # ── Resources Utilized (from experiment logs) ──
    from collections import defaultdict as _ddict
    res = {"total_runs": 0, "models": [], "conditions": [], "prompts": [],
           "rag": [], "complexity": [], "summary_table": []}
    log_files = sorted(config.EXPERIMENT_LOGS.glob("*.json"))
    log_data = []
    for lf in log_files:
        if lf.name.startswith("_"):
            continue
        try:
            log_data.append(json.loads(lf.read_text(encoding="utf-8")))
        except Exception:
            pass
    res["total_runs"] = len(log_data)
    if log_data:
        model_agg = _ddict(lambda: {"count": 0, "compile": 0, "iters": 0, "dev": 0, "refine": 0, "fc_sum": 0})
        for d in log_data:
            m = d.get("model_used", "unknown")
            model_agg[m]["count"] += 1
            if d.get("compilation_success"): model_agg[m]["compile"] += 1
            model_agg[m]["iters"] += d.get("iterations_needed", 0) or 0
            model_agg[m]["dev"] += d.get("dev_time_minutes", 0) or 0
            model_agg[m]["refine"] += d.get("semantic_refinement_iterations", 0) or 0
            model_agg[m]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
        for m, s in sorted(model_agg.items(), key=lambda x: -x[1]["count"]):
            n = s["count"]
            res["models"].append({"name": m, "runs": n, "compile_pct": round(s["compile"]/n*100),
                "avg_iter": round(s["iters"]/n, 2), "avg_dev": round(s["dev"]/n, 2), "avg_refine": round(s["refine"]/n, 2)})
        cond_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            c = d.get("condition", "?"); cond_agg[c]["count"] += 1
            if d.get("compilation_success"): cond_agg[c]["compile"] += 1
            cond_agg[c]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            cond_agg[c]["iters"] += d.get("iterations_needed", 0) or 0
            cond_agg[c]["dev"] += d.get("dev_time_minutes", 0) or 0
        for c, s in sorted(cond_agg.items()):
            res["conditions"].append({"name": c.replace("_", " ").title(), "count": s["count"]})
        prompt_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            ps = d.get("prompt_style", "?"); prompt_agg[ps]["count"] += 1
            if d.get("compilation_success"): prompt_agg[ps]["compile"] += 1
            prompt_agg[ps]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            prompt_agg[ps]["iters"] += d.get("iterations_needed", 0) or 0
            prompt_agg[ps]["dev"] += d.get("dev_time_minutes", 0) or 0
        for ps, s in sorted(prompt_agg.items()):
            n = s["count"]
            res["prompts"].append({"name": ps.replace("_", " ").title(), "count": n, "compile_pct": round(s["compile"]/n*100)})
        rag_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            r_key = "RAG On" if d.get("rag_used") else "RAG Off"; rag_agg[r_key]["count"] += 1
            if d.get("compilation_success"): rag_agg[r_key]["compile"] += 1
            rag_agg[r_key]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            rag_agg[r_key]["iters"] += d.get("iterations_needed", 0) or 0
            rag_agg[r_key]["dev"] += d.get("dev_time_minutes", 0) or 0
        for r_key, s in sorted(rag_agg.items()):
            n = s["count"]
            res["rag"].append({"name": r_key, "count": n, "avg_fc": round(s["fc_sum"]/n*100, 1)})
        comp_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            cx = d.get("complexity", "?"); comp_agg[cx]["count"] += 1
            if d.get("compilation_success"): comp_agg[cx]["compile"] += 1
            comp_agg[cx]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            comp_agg[cx]["iters"] += d.get("iterations_needed", 0) or 0
            comp_agg[cx]["dev"] += d.get("dev_time_minutes", 0) or 0
        for cx in ["low", "medium", "high"]:
            s = comp_agg.get(cx, {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
            n = s["count"] or 1
            res["complexity"].append({"name": cx.title(), "count": s["count"], "compile_pct": round(s["compile"]/n*100), "avg_fc": round(s["fc_sum"]/n*100, 1)})
        def _add_table_row(dim, cat, agg_data):
            n = agg_data["count"] or 1
            res["summary_table"].append({"dimension": dim, "category": cat, "runs": agg_data["count"],
                "compile_pct": round(agg_data["compile"]/n*100), "avg_fc": round(agg_data["fc_sum"]/n*100, 1),
                "avg_iter": round(agg_data["iters"]/n, 2), "avg_dev": f'{agg_data["dev"]/n:.2f} min', "is_header": False})
        for m_name in sorted(model_agg.keys()): _add_table_row("Model", m_name, model_agg[m_name])
        for c_name in sorted(cond_agg.keys()): _add_table_row("Condition", c_name.replace("_", " ").title(), cond_agg[c_name])
        for ps_name in sorted(prompt_agg.keys()): _add_table_row("Prompt", ps_name.replace("_", " ").title(), prompt_agg[ps_name])
        for r_name in sorted(rag_agg.keys()): _add_table_row("RAG", r_name, rag_agg[r_name])
        for cx_name in ["low", "medium", "high"]:
            if cx_name in comp_agg: _add_table_row("Complexity", cx_name.title(), comp_agg[cx_name])

    return render_template("dashboard.html", summary=summary, chart_data=chart_data,
                           total_rows=len(rows), fw_count=len(fw_rows), dl_count=len(dl_rows),
                           ai_count=60, n_tasks=n_tasks,
                           exp_groups=22, res=res,
                           rows=rows, tasks=tasks_set, methods=methods_set)


@app.route("/evaluation-summary")
def evaluation_summary_page():
    """Display evaluation data from Evaluation_Summary_All_Tasks.xlsx."""
    import openpyxl

    xlsx_path = Path(__file__).parent / "Evaluation_Summary_All_Tasks.xlsx"
    rows = []
    tasks_set = set()
    methods_set = set()

    if xlsx_path.exists():
        wb = openpyxl.load_workbook(str(xlsx_path), data_only=True)
        ws = wb["Summary"]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[0]:
                continue
            task = str(row[0]).strip()
            method = str(row[1]).strip() if row[1] else ""
            compile_str = str(row[2]).strip() if row[2] else ""
            test_str = str(row[3]).strip() if row[3] else "0%"
            cov_str = str(row[4]).strip() if row[4] else "0%"
            spec_str = str(row[5]).strip() if row[5] else "0%"
            lang_str = str(row[6]).strip() if row[6] else ""
            overall_str = str(row[7]).strip() if row[7] else ""

            compile_pass = "pass" in compile_str.lower() or "✓" in compile_str
            test_val = float(test_str.replace("%", "")) if test_str.replace("%", "").replace(".", "").isdigit() else 0
            cov_val = float(cov_str.replace("%", "")) if cov_str.replace("%", "").replace(".", "").isdigit() else 0
            spec_val = float(spec_str.replace("%", "")) if spec_str.replace("%", "").replace(".", "").isdigit() else 0
            overall_pass = "pass" in overall_str.lower() or "✓" in overall_str

            tasks_set.add(task)
            methods_set.add(method)
            rows.append({
                "task": task,
                "method": method,
                "compile_pass": compile_pass,
                "test_pass": test_val,
                "test_pass_str": test_str,
                "coverage": cov_val,
                "coverage_str": cov_str,
                "spec": spec_val,
                "spec_str": spec_str,
                "languages": lang_str,
                "overall_pass": overall_pass,
                "overall_raw": "PASS" if overall_pass else "FAIL",
            })

    # Compute summary metrics
    fw_rows = [r for r in rows if "Framework" in r["method"]]
    dl_rows = [r for r in rows if "Direct" in r["method"]]

    fw_pass_rate = (sum(1 for r in fw_rows if r["overall_pass"]) / len(fw_rows) * 100) if fw_rows else 0
    dl_pass_rate = (sum(1 for r in dl_rows if r["overall_pass"]) / len(dl_rows) * 100) if dl_rows else 0
    overall_pass_rate = (sum(1 for r in rows if r["overall_pass"]) / len(rows) * 100) if rows else 0

    fw_avg_test = (sum(r["test_pass"] for r in fw_rows) / len(fw_rows)) if fw_rows else 0
    dl_avg_test = (sum(r["test_pass"] for r in dl_rows) / len(dl_rows)) if dl_rows else 0
    fw_avg_cov = (sum(r["coverage"] for r in fw_rows) / len(fw_rows)) if fw_rows else 0
    dl_avg_cov = (sum(r["coverage"] for r in dl_rows) / len(dl_rows)) if dl_rows else 0
    fw_avg_spec = (sum(r["spec"] for r in fw_rows) / len(fw_rows)) if fw_rows else 0
    dl_avg_spec = (sum(r["spec"] for r in dl_rows) / len(dl_rows)) if dl_rows else 0
    fw_compile_rate = (sum(1 for r in fw_rows if r["compile_pass"]) / len(fw_rows) * 100) if fw_rows else 0
    dl_compile_rate = (sum(1 for r in dl_rows if r["compile_pass"]) / len(dl_rows) * 100) if dl_rows else 0

    # Counts for Objective 1 & 5
    fw_total = len(fw_rows)
    dl_total = len(dl_rows)
    fw_compile_pass = sum(1 for r in fw_rows if r["compile_pass"])
    dl_compile_pass = sum(1 for r in dl_rows if r["compile_pass"])
    fw_overall_pass = sum(1 for r in fw_rows if r["overall_pass"])
    dl_overall_pass = sum(1 for r in dl_rows if r["overall_pass"])
    fw_perfect = sum(1 for r in fw_rows if r["test_pass"] == 100 and r["coverage"] == 100 and r["spec"] == 100)
    dl_perfect = sum(1 for r in dl_rows if r["test_pass"] == 100 and r["coverage"] == 100 and r["spec"] == 100)

    # Cross-language support (4/4 rate)
    fw_lang_rate = (sum(1 for r in fw_rows if "4/4" in r["languages"]) / fw_total * 100) if fw_total else 0
    dl_lang_rate = (sum(1 for r in dl_rows if "4/4" in r["languages"]) / dl_total * 100) if dl_total else 0

    # Per-prompt breakdown helpers
    def _prompt_subset(row_list, keyword):
        return [r for r in row_list if keyword.lower() in r["method"].lower()]

    fw_std = _prompt_subset(fw_rows, "standard")
    fw_cot = _prompt_subset(fw_rows, "chain")
    fw_pot = _prompt_subset(fw_rows, "program")
    dl_std = _prompt_subset(dl_rows, "standard")
    dl_cot = _prompt_subset(dl_rows, "chain")
    dl_pot = _prompt_subset(dl_rows, "program")

    def _avg(lst, key):
        return (sum(r[key] for r in lst) / len(lst)) if lst else 0

    def _pass_rate(lst):
        return (sum(1 for r in lst if r["overall_pass"]) / len(lst) * 100) if lst else 0

    # Experimental Dataset and Run Structure (from experiment logs) ──
    from collections import defaultdict as _ddict
    res = {"total_runs": 0, "models": [], "conditions": [], "prompts": [],
           "rag": [], "complexity": [], "summary_table": []}

    log_files = sorted(config.EXPERIMENT_LOGS.glob("*.json"))
    log_data = []
    for lf in log_files:
        if lf.name.startswith("_"):
            continue
        try:
            log_data.append(json.loads(lf.read_text(encoding="utf-8")))
        except Exception:
            pass

    res["total_runs"] = len(log_data)

    if log_data:
        # Per-model
        model_agg = _ddict(lambda: {"count": 0, "compile": 0, "iters": 0, "dev": 0, "refine": 0, "fc_sum": 0})
        for d in log_data:
            m = d.get("model_used", "unknown")
            model_agg[m]["count"] += 1
            if d.get("compilation_success"):
                model_agg[m]["compile"] += 1
            model_agg[m]["iters"] += d.get("iterations_needed", 0) or 0
            model_agg[m]["dev"] += d.get("dev_time_minutes", 0) or 0
            model_agg[m]["refine"] += d.get("semantic_refinement_iterations", 0) or 0
            model_agg[m]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0

        for m, s in sorted(model_agg.items(), key=lambda x: -x[1]["count"]):
            n = s["count"]
            res["models"].append({
                "name": m, "runs": n,
                "compile_pct": round(s["compile"] / n * 100),
                "avg_iter": round(s["iters"] / n, 2),
                "avg_dev": round(s["dev"] / n, 2),
                "avg_refine": round(s["refine"] / n, 2),
            })

        # Per-condition
        cond_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            c = d.get("condition", "?")
            cond_agg[c]["count"] += 1
            if d.get("compilation_success"):
                cond_agg[c]["compile"] += 1
            cond_agg[c]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            cond_agg[c]["iters"] += d.get("iterations_needed", 0) or 0
            cond_agg[c]["dev"] += d.get("dev_time_minutes", 0) or 0
        for c, s in sorted(cond_agg.items()):
            n = s["count"]
            res["conditions"].append({"name": c.replace("_", " ").title(), "count": n})

        # Per-prompt
        prompt_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            ps = d.get("prompt_style", "?")
            prompt_agg[ps]["count"] += 1
            if d.get("compilation_success"):
                prompt_agg[ps]["compile"] += 1
            prompt_agg[ps]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            prompt_agg[ps]["iters"] += d.get("iterations_needed", 0) or 0
            prompt_agg[ps]["dev"] += d.get("dev_time_minutes", 0) or 0
        for ps, s in sorted(prompt_agg.items()):
            n = s["count"]
            res["prompts"].append({
                "name": ps.replace("_", " ").title(), "count": n,
                "compile_pct": round(s["compile"] / n * 100),
            })

        # RAG impact
        rag_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            r_key = "RAG On" if d.get("rag_used") else "RAG Off"
            rag_agg[r_key]["count"] += 1
            if d.get("compilation_success"):
                rag_agg[r_key]["compile"] += 1
            rag_agg[r_key]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            rag_agg[r_key]["iters"] += d.get("iterations_needed", 0) or 0
            rag_agg[r_key]["dev"] += d.get("dev_time_minutes", 0) or 0
        for r_key, s in sorted(rag_agg.items()):
            n = s["count"]
            res["rag"].append({
                "name": r_key, "count": n,
                "avg_fc": round(s["fc_sum"] / n * 100, 1),
            })

        # Complexity
        comp_agg = _ddict(lambda: {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
        for d in log_data:
            cx = d.get("complexity", "?")
            comp_agg[cx]["count"] += 1
            if d.get("compilation_success"):
                comp_agg[cx]["compile"] += 1
            comp_agg[cx]["fc_sum"] += d.get("functional_correctness_rate", 0) or 0
            comp_agg[cx]["iters"] += d.get("iterations_needed", 0) or 0
            comp_agg[cx]["dev"] += d.get("dev_time_minutes", 0) or 0
        for cx in ["low", "medium", "high"]:
            s = comp_agg.get(cx, {"count": 0, "compile": 0, "fc_sum": 0, "iters": 0, "dev": 0})
            n = s["count"] or 1
            res["complexity"].append({
                "name": cx.title(), "count": s["count"],
                "compile_pct": round(s["compile"] / n * 100),
                "avg_fc": round(s["fc_sum"] / n * 100, 1),
            })

        # Summary table rows
        def _add_table_row(dim, cat, agg_data):
            n = agg_data["count"] or 1
            res["summary_table"].append({
                "dimension": dim, "category": cat, "runs": agg_data["count"],
                "compile_pct": round(agg_data["compile"] / n * 100),
                "avg_fc": round(agg_data["fc_sum"] / n * 100, 1),
                "avg_iter": round(agg_data["iters"] / n, 2),
                "avg_dev": f'{agg_data["dev"] / n:.2f} min',
                "is_header": False,
            })

        for m_name in sorted(model_agg.keys()):
            _add_table_row("Model", m_name, model_agg[m_name])
        for c_name in sorted(cond_agg.keys()):
            _add_table_row("Condition", c_name.replace("_", " ").title(), cond_agg[c_name])
        for ps_name in sorted(prompt_agg.keys()):
            _add_table_row("Prompt", ps_name.replace("_", " ").title(), prompt_agg[ps_name])
        for r_name in sorted(rag_agg.keys()):
            _add_table_row("RAG", r_name, rag_agg[r_name])
        for cx_name in ["low", "medium", "high"]:
            if cx_name in comp_agg:
                _add_table_row("Complexity", cx_name.title(), comp_agg[cx_name])

    return render_template(
        "evaluation_summary.html",
        rows=rows,
        tasks=sorted(tasks_set),
        methods=sorted(methods_set),
        res=res,
        fw_pass_rate=fw_pass_rate,
        dl_pass_rate=dl_pass_rate,
        overall_pass_rate=overall_pass_rate,
        fw_avg_test=fw_avg_test,
        dl_avg_test=dl_avg_test,
        fw_avg_cov=fw_avg_cov,
        dl_avg_cov=dl_avg_cov,
        fw_avg_spec=fw_avg_spec,
        dl_avg_spec=dl_avg_spec,
        fw_compile_rate=fw_compile_rate,
        dl_compile_rate=dl_compile_rate,
        # Objective 1 & 5 counts
        fw_total=fw_total,
        dl_total=dl_total,
        fw_compile_pass=fw_compile_pass,
        dl_compile_pass=dl_compile_pass,
        fw_overall_pass=fw_overall_pass,
        dl_overall_pass=dl_overall_pass,
        fw_perfect=fw_perfect,
        dl_perfect=dl_perfect,
        # Cross-language
        fw_lang_rate=fw_lang_rate,
        dl_lang_rate=dl_lang_rate,
        # Per-prompt spec compliance
        fw_std_spec=_avg(fw_std, "spec"),
        fw_cot_spec=_avg(fw_cot, "spec"),
        fw_pot_spec=_avg(fw_pot, "spec"),
        dl_std_spec=_avg(dl_std, "spec"),
        dl_cot_spec=_avg(dl_cot, "spec"),
        dl_pot_spec=_avg(dl_pot, "spec"),
        # Per-prompt pass rates
        fw_std_pass=_pass_rate(fw_std),
        fw_cot_pass=_pass_rate(fw_cot),
        fw_pot_pass=_pass_rate(fw_pot),
        dl_std_pass=_pass_rate(dl_std),
        dl_cot_pass=_pass_rate(dl_cot),
        dl_pot_pass=_pass_rate(dl_pot),
        # Per-prompt test pass
        fw_std_test=_avg(fw_std, "test_pass"),
        fw_cot_test=_avg(fw_cot, "test_pass"),
        fw_pot_test=_avg(fw_pot, "test_pass"),
        dl_std_test=_avg(dl_std, "test_pass"),
        dl_cot_test=_avg(dl_cot, "test_pass"),
        dl_pot_test=_avg(dl_pot, "test_pass"),
    )


@app.route("/evaluation-summary/export/excel")
def evaluation_summary_export_excel():
    """Export the evaluation summary Excel file for download/editing."""
    xlsx_path = Path(__file__).parent / "Evaluation_Summary_All_Tasks.xlsx"
    if not xlsx_path.exists():
        flash("Excel file not found.", "danger")
        return redirect(url_for("evaluation_summary_page"))
    return send_file(str(xlsx_path), as_attachment=True,
                     download_name="Evaluation_Summary_All_Tasks.xlsx")


@app.route("/evaluation-summary/export/csv")
def evaluation_summary_export_csv():
    """Export evaluation summary as CSV."""
    import csv
    import io
    import openpyxl

    xlsx_path = Path(__file__).parent / "Evaluation_Summary_All_Tasks.xlsx"
    if not xlsx_path.exists():
        flash("Excel file not found.", "danger")
        return redirect(url_for("evaluation_summary_page"))

    wb = openpyxl.load_workbook(str(xlsx_path), data_only=True)
    ws = wb["Summary"]

    output = io.StringIO()
    writer = csv.writer(output)
    for row in ws.iter_rows(values_only=True):
        writer.writerow(row)

    resp = Response(output.getvalue(), mimetype="text/csv")
    resp.headers["Content-Disposition"] = "attachment; filename=Evaluation_Summary.csv"
    return resp


@app.route("/evaluation-summary/import", methods=["POST"])
def evaluation_summary_import():
    """Import an updated Excel file to replace the evaluation summary data."""
    import shutil

    if "excel_file" not in request.files:
        flash("No file uploaded.", "danger")
        return redirect(url_for("evaluation_summary_page"))

    file = request.files["excel_file"]
    if not file.filename or not file.filename.endswith(".xlsx"):
        flash("Please upload a valid .xlsx file.", "danger")
        return redirect(url_for("evaluation_summary_page"))

    xlsx_path = Path(__file__).parent / "Evaluation_Summary_All_Tasks.xlsx"

    # Create backup before overwriting
    if xlsx_path.exists():
        backup_path = xlsx_path.with_suffix(".xlsx.bak")
        shutil.copy2(str(xlsx_path), str(backup_path))

    file.save(str(xlsx_path))
    flash("Evaluation summary data imported successfully.", "success")
    return redirect(url_for("evaluation_summary_page"))


@app.route("/results")
def results_page():
    from src.evaluator import load_all_logs, summarize_results
    from collections import defaultdict
    logs    = _get_logs()
    all_raw = load_all_logs(str(config.EXPERIMENT_LOGS))
    summary = summarize_results(all_raw) if all_raw else {}

    expected_set = set(FULL_SIX_COMBINATION_SEQUENCE)
    expected_labels = {
        ("framework", "standard"): "Framework - Standard",
        ("framework", "chain_of_thought"): "Framework - Chain of Thought",
        ("framework", "program_of_thought"): "Framework - Program of Thought",
        ("direct_llm", "standard"): "Direct LLM - Standard",
        ("direct_llm", "chain_of_thought"): "Direct LLM - Chain of Thought",
        ("direct_llm", "program_of_thought"): "Direct LLM - Program of Thought",
    }

    groups: dict[int, list[dict]] = defaultdict(list)
    for lg in logs:
        exp_num = lg.get("experiment_number")
        if exp_num is not None:
            groups[exp_num].append(lg)

    exp_diag: dict[int, dict] = {}
    for exp_num, entries in groups.items():
        benchmark_entries = [e for e in entries if e.get("task_source") != "ai_builder"]
        found_set = {
            (e.get("condition"), e.get("prompt_style"))
            for e in benchmark_entries
            if e.get("condition") in ("framework", "direct_llm")
            and e.get("prompt_style") in ("standard", "chain_of_thought", "program_of_thought")
        }
        found_expected = expected_set.intersection(found_set)
        missing = [expected_labels[c] for c in FULL_SIX_COMBINATION_SEQUENCE if c not in found_expected]
        exp_diag[exp_num] = {
            "expected": len(expected_set),
            "found": len(found_expected),
            "complete": len(found_expected) == len(expected_set),
            "missing": missing,
        }

    return render_template("results.html", logs=logs, summary=summary, exp_diag=exp_diag)


@app.route("/results/export/csv")
def export_csv():
    import csv, io
    logs = _get_logs()
    fields = ["task_id","condition","complexity","timestamp","compilation_success",
              "iterations_needed","functional_correctness_rate","bleu_score",
              "semantic_equivalence_score","dev_time_minutes","logical_inconsistencies",
              "review_logic","review_interlocks","review_safety",
              "review_iec","review_structure","review_decision",
              "escalated_for_review","nasa_tlx_score",
              "hallucination_rate","statement_coverage","syntax_errors_delta",
              "regeneration_count","current_code_version","notes",
              "reviewer_id","reviewer_experience"]
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for log in logs:
        row = {f: log.get(f, "") for f in fields}
        row["regeneration_count"] = len(log.get("regeneration_history", []))
        writer.writerow(row)
    output = buf.getvalue()
    return Response(output, mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=plc_results.csv"})


@app.route("/results/export/table-csv")
@app.route("/results/export/table-csv/")
@app.route("/results/export/table-csv/<exp_num>")
def export_table_csv(exp_num: str | None = None):
    logs = _get_logs()
    exp_num_int: int | None = None
    if exp_num is not None:
        try:
            exp_num_int = int(exp_num)
        except (TypeError, ValueError):
            exp_num_int = None

    if exp_num_int is not None:
        logs = [log for log in logs if log.get("experiment_number") == exp_num_int]
        filename = f"experiment_run_{exp_num_int}_table.csv"
    else:
        filename = "experiment_logs_table.csv"

    output = _build_experiment_table_csv(logs)
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@app.route("/results/export/excel")
def export_excel():
    """Export all experiment logs to a comprehensive Excel workbook with 4 sheets:
    Sheet 1 – All Logs     : every scalar field for every log (full detail like the log page)
    Sheet 2 – Test Cases   : one row per test-case per log (TC id, pass/fail, expected, actual)
    Sheet 3 – Iterations   : compiler iteration history per log
    Sheet 4 – Review Detail: reviewer verdicts + all comments + LD/FBD validation
    """
    import openpyxl, json as _json, io as _io
    from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    logs = _get_logs()
    wb = openpyxl.Workbook()

    # ── Shared styles ─────────────────────────────────────────────────────────
    def _hdr_fill(hex_color):
        return PatternFill("solid", fgColor=hex_color)

    HDR_FONT  = Font(bold=True, color="FFFFFF", size=10)
    HDR_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)
    THIN   = Side(border_style="thin",   color="BBBBBB")
    BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
    COND_COLORS = {"framework": "DBEAFE", "direct_llm": "EDE9FE", "manual": "D1FAE5"}
    PASS_FILL = PatternFill("solid", fgColor="D1FAE5")
    FAIL_FILL = PatternFill("solid", fgColor="FEE2E2")

    def _write_header(ws, headers, fill_hex="1E3A5F"):
        fill = _hdr_fill(fill_hex)
        for ci, label in enumerate(headers, 1):
            c = ws.cell(row=1, column=ci, value=label)
            c.fill = fill; c.font = HDR_FONT
            c.alignment = HDR_ALIGN; c.border = BORDER
        ws.row_dimensions[1].height = 32

    def _cell(ws, row, col, value, border=True, wrap=False, fill=None):
        c = ws.cell(row=row, column=col, value=value)
        if border: c.border = BORDER
        c.alignment = Alignment(vertical="center", wrap_text=wrap)
        if fill: c.fill = fill
        return c

    def _bool(v):
        if v is True:  return "Yes"
        if v is False: return "No"
        return "" if v is None else v

    def _pct(v):
        if v is None: return ""
        try: return round(float(v) * 100, 1)
        except: return v

    def _autowidth(ws, nrows, ncols, min_w=8, max_w=45):
        for ci in range(1, ncols + 1):
            col_vals = [str(ws.cell(row=r, column=ci).value or "") for r in range(1, nrows + 2)]
            hdr_len = len(ws.cell(row=1, column=ci).value or "")
            ws.column_dimensions[get_column_letter(ci)].width = \
                min(max(len(max(col_vals, key=len)) + 2, hdr_len + 2, min_w), max_w)

    # ═══════════════════════════════════════════════════════════════════════════
    # SHEET 1 – All Logs (comprehensive, all scalar fields)
    # ═══════════════════════════════════════════════════════════════════════════
    ws1 = wb.active
    ws1.title = "All Logs"

    ALL_COLS = [
        # ── Identity ──────────────────────────────────────────────────────────
        ("filename",                    "Filename"),
        ("task_id",                     "Task ID"),
        ("condition",                   "Condition"),
        ("complexity",                  "Complexity"),
        ("timestamp",                   "Timestamp"),
        ("experiment_number",           "Exp. #"),
        ("task_source",                 "Task Source"),
        # ── Model / Generation ───────────────────────────────────────────────
        ("model_used",                  "Model"),
        ("prompt_style",                "Prompt Style"),
        ("rag_used",                    "RAG Used"),
        ("current_code_version",        "Code Version"),
        # ── RQ1 Compilation ──────────────────────────────────────────────────
        ("compilation_success",         "RQ1 — Compiled"),
        ("syntax_errors_initial",       "Init Syntax Errors"),
        ("syntax_errors_final",         "Final Syntax Errors"),
        ("syntax_errors_delta",         "Errors Resolved"),
        ("iterations_needed",           "Iterations"),
        # ── RQ2 Correctness ──────────────────────────────────────────────────
        ("functional_correctness_rate", "RQ2 — Correctness (%)"),
        ("statement_coverage",          "Coverage (%)"),
        ("bleu_score",                  "BLEU Score"),
        ("hallucination_rate",          "Hallucination Rate (%)"),
        ("logical_inconsistencies",     "Logical Inconsistencies"),
        ("normalization_fidelity",      "Norm. Fidelity"),
        # ── Agent 1: Spec Compliance ─────────────────────────────────────────
        ("spec_compliance_score",       "Spec Compliance (%)"),
        ("conditions_checked",          "Conditions Checked"),
        ("conditions_met",              "Conditions Met (YES)"),
        ("conditions_partial",          "Conditions Partial"),
        ("conditions_missing",          "Conditions Missing"),
        # ── Agent 2: Semantic Refinement ─────────────────────────────────────
        ("semantic_refinement_iterations", "Semantic Refine Iterations"),
        # ── Agent 3: Requirements Gap Detection ──────────────────────────────
        ("gaps_detected",               "Spec Gaps Detected"),
        # ── RQ3 Cross-Language ───────────────────────────────────────────────
        ("ld_compilation_success",      "RQ3 — LD Valid"),
        ("fbd_compilation_success",     "FBD Valid"),
        ("semantic_equivalence_score",  "Semantic Equiv. Score"),
        ("equivalence_level",           "Equiv. Level"),
        # ── RQ4 Productivity ─────────────────────────────────────────────────
        ("dev_time_minutes",            "RQ4 — Dev Time (min)"),
        ("task_completed_in_budget",    "In Budget"),
        ("nasa_tlx_score",              "NASA-TLX"),
        #("manual_corrections_count",    "Manual Corrections"),
        #("manual_corrections_time_min", "Manual Corr. Time (min)"),
        # ── Expert Review ────────────────────────────────────────────────────
        ("reviewer_id",                 "Reviewer ID"),
        ("reviewer_experience",         "Reviewer Experience"),
        ("review_decision",             "Review Decision"),
        ("review_logic",                "Review: Logic"),
        ("review_logic_comment",        "Review: Logic Comment"),
        ("review_interlocks",           "Review: Interlocks"),
        ("review_interlocks_comment",   "Review: Interlocks Comment"),
        ("review_safety",               "Review: Safety"),
        ("review_safety_comment",       "Review: Safety Comment"),
        ("review_iec",                  "Review: IEC"),
        ("review_iec_comment",          "Review: IEC Comment"),
        ("review_structure",            "Review: Structure"),
        ("review_structure_comment",    "Review: Structure Comment"),
        ("escalated_for_review",        "Escalated"),
        ("accepted_without_correction", "Accepted Without Correction"),
        ("expert_rating_correctness",   "Expert: Correctness"),
        ("expert_rating_maintainability","Expert: Maintainability"),
        ("expert_rating_safety",        "Expert: Safety"),
        ("expert_rating_iec_adherence", "Expert: IEC Adherence"),
        ("review_time_minutes",         "Review Time (min)"),
        ("participant_id",              "Participant ID"),
        ("notes",                       "Notes"),
    ]

    _write_header(ws1, [lbl for _, lbl in ALL_COLS])

    for ri, log in enumerate(logs, 2):
        cond_fill = PatternFill("solid", fgColor=COND_COLORS.get(log.get("condition", ""), "FFFFFF"))
        for ci, (key, _) in enumerate(ALL_COLS, 1):
            raw = log.get(key, "")
            # Percentage fields — multiply by 100 for readability
            if key in ("functional_correctness_rate", "statement_coverage",
                       "hallucination_rate", "semantic_equivalence_score",
                       "spec_compliance_score"):
                val = _pct(raw)
            else:
                val = _bool(raw) if isinstance(raw, bool) else ("" if raw is None else raw)
            _cell(ws1, ri, ci, val,
                  fill=cond_fill if ci <= 4 else None,
                  wrap=("comment" in key or key == "notes"))

    _autowidth(ws1, len(logs), len(ALL_COLS))
    ws1.freeze_panes = "C2"   # freeze Task ID + Condition

    # ═══════════════════════════════════════════════════════════════════════════
    # SHEET 2 – Test Cases (one row per TC per log)
    # ═══════════════════════════════════════════════════════════════════════════
    ws2 = wb.create_sheet("Test Cases")
    TC_COLS = ["Task ID", "Condition", "Complexity", "Timestamp",
               "TC ID", "Description", "Passed", "Expected (JSON)", "Actual (JSON)", "Error"]
    _write_header(ws2, TC_COLS, fill_hex="065F46")

    tc_row = 2
    for log in logs:
        tc_list = log.get("st_test_results") or log.get("test_results") or []
        if not tc_list:
            # still write a summary row so every log appears
            _cell(ws2, tc_row, 1, log.get("task_id",""))
            _cell(ws2, tc_row, 2, log.get("condition",""))
            _cell(ws2, tc_row, 3, log.get("complexity",""))
            _cell(ws2, tc_row, 4, log.get("timestamp",""))
            _cell(ws2, tc_row, 5, "—")
            _cell(ws2, tc_row, 6, "No test cases recorded")
            tc_row += 1
            continue
        for tc in tc_list:
            f = PASS_FILL if tc.get("passed") else FAIL_FILL
            _cell(ws2, tc_row, 1, log.get("task_id",""))
            _cell(ws2, tc_row, 2, log.get("condition",""))
            _cell(ws2, tc_row, 3, log.get("complexity",""))
            _cell(ws2, tc_row, 4, log.get("timestamp",""))
            _cell(ws2, tc_row, 5, tc.get("id",""))
            _cell(ws2, tc_row, 6, tc.get("description",""), wrap=True)
            c = ws2.cell(row=tc_row, column=7,
                         value="PASS" if tc.get("passed") else "FAIL")
            c.border = BORDER; c.fill = f
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.font = Font(bold=True,
                          color="065F46" if tc.get("passed") else "B91C1C")
            _cell(ws2, tc_row, 8,
                  _json.dumps(tc.get("expected"), ensure_ascii=False) if tc.get("expected") is not None else "")
            _cell(ws2, tc_row, 9,
                  _json.dumps(tc.get("actual"), ensure_ascii=False) if tc.get("actual") is not None else "")
            err = tc.get("error") or ""
            _cell(ws2, tc_row, 10, err, wrap=True)
            tc_row += 1

    _autowidth(ws2, tc_row, len(TC_COLS))
    ws2.column_dimensions["F"].width = 38   # Description
    ws2.column_dimensions["H"].width = 32   # Expected
    ws2.column_dimensions["I"].width = 32   # Actual
    ws2.freeze_panes = "E2"

    # ═══════════════════════════════════════════════════════════════════════════
    # SHEET 3 – Iterations (compiler feedback loop detail)
    # ═══════════════════════════════════════════════════════════════════════════
    ws3 = wb.create_sheet("Iterations")
    IT_COLS = ["Task ID", "Condition", "Timestamp",
               "Iteration #", "Success", "Error Count", "Errors (JSON)"]
    _write_header(ws3, IT_COLS, fill_hex="4338CA")

    it_row = 2
    for log in logs:
        ilog = log.get("iteration_log") or []
        if not ilog:
            _cell(ws3, it_row, 1, log.get("task_id",""))
            _cell(ws3, it_row, 2, log.get("condition",""))
            _cell(ws3, it_row, 3, log.get("timestamp",""))
            _cell(ws3, it_row, 4, 1)
            _cell(ws3, it_row, 5, _bool(log.get("compilation_success")))
            _cell(ws3, it_row, 6, log.get("syntax_errors_initial",""))
            _cell(ws3, it_row, 7, "")
            it_row += 1
            continue
        for it in ilog:
            _cell(ws3, it_row, 1, log.get("task_id",""))
            _cell(ws3, it_row, 2, log.get("condition",""))
            _cell(ws3, it_row, 3, log.get("timestamp",""))
            _cell(ws3, it_row, 4, it.get("iteration",""))
            ok = it.get("success")
            c = ws3.cell(row=it_row, column=5,
                         value="Yes" if ok else ("No" if ok is False else ""))
            c.border = BORDER
            c.fill = PASS_FILL if ok else (FAIL_FILL if ok is False else None)
            c.alignment = Alignment(horizontal="center", vertical="center")
            _cell(ws3, it_row, 6, it.get("error_count",""))
            errs = it.get("errors") or []
            _cell(ws3, it_row, 7,
                  _json.dumps(errs, ensure_ascii=False) if errs else "",
                  wrap=True)
            it_row += 1

    _autowidth(ws3, it_row, len(IT_COLS))
    ws3.column_dimensions["G"].width = 50
    ws3.freeze_panes = "D2"

    # ═══════════════════════════════════════════════════════════════════════════
    # SHEET 4 – Review & Validation Detail
    # ═══════════════════════════════════════════════════════════════════════════
    ws4 = wb.create_sheet("Review & Validation")
    RV_COLS = [
        "Task ID", "Condition", "Complexity", "Timestamp",
        "Reviewer ID", "Reviewer Experience",
        "Review Decision", "Escalated", "Review Time (min)",
        "Logic Verdict",     "Logic Comment",
        "Interlocks Verdict","Interlocks Comment",
        "Safety Verdict",    "Safety Comment",
        "IEC Verdict",       "IEC Comment",
        "Structure Verdict", "Structure Comment",
        "NASA-TLX",
        "Expert: Correctness", "Expert: Maintainability",
        "Expert: Safety",      "Expert: IEC Adherence",
        "Accepted Without Correction",
        "LD Valid", "LD Parse OK", "LD NS OK", "LD Vars Present", "LD Missing Vars",
        "FBD Valid","FBD Parse OK","FBD NS OK","FBD Vars Present","FBD Missing Vars",
        "Notes",
    ]
    _write_header(ws4, RV_COLS, fill_hex="7C2D12")

    for ri, log in enumerate(logs, 2):
        ld  = log.get("ld_validation_detail")  or {}
        fbd = log.get("fbd_validation_detail") or {}
        row_vals = [
            log.get("task_id",""),
            log.get("condition",""),
            log.get("complexity",""),
            log.get("timestamp",""),
            log.get("reviewer_id",""),
            log.get("reviewer_experience",""),
            log.get("review_decision",""),
            _bool(log.get("escalated_for_review")),
            log.get("review_time_minutes",""),
            log.get("review_logic",""),       log.get("review_logic_comment",""),
            log.get("review_interlocks",""),  log.get("review_interlocks_comment",""),
            log.get("review_safety",""),      log.get("review_safety_comment",""),
            log.get("review_iec",""),         log.get("review_iec_comment",""),
            log.get("review_structure",""),   log.get("review_structure_comment",""),
            log.get("nasa_tlx_score",""),
            log.get("expert_rating_correctness",""),
            log.get("expert_rating_maintainability",""),
            log.get("expert_rating_safety",""),
            log.get("expert_rating_iec_adherence",""),
            _bool(log.get("accepted_without_correction")),
            _bool(ld.get("valid")),  _bool(ld.get("parse_ok")),
            _bool(ld.get("namespace_ok")), _bool(ld.get("variables_present")),
            _json.dumps(ld.get("missing_vars") or []),
            _bool(fbd.get("valid")), _bool(fbd.get("parse_ok")),
            _bool(fbd.get("namespace_ok")), _bool(fbd.get("variables_present")),
            _json.dumps(fbd.get("missing_vars") or []),
            log.get("notes",""),
        ]
        comment_cols = {11, 13, 15, 17, 19, 36}  # 1-based indices of comment columns
        for ci, val in enumerate(row_vals, 1):
            _cell(ws4, ri, ci, ("" if val is None else val),
                  wrap=(ci in comment_cols))

    _autowidth(ws4, len(logs), len(RV_COLS))
    for ci in (11, 13, 15, 17, 19, 36):
        ws4.column_dimensions[get_column_letter(ci)].width = 30
    ws4.freeze_panes = "C2"

    # ── Stream ────────────────────────────────────────────────────────────────
    buf = _io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return Response(
        buf.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=plc_full_export.xlsx"}
    )


@app.route("/results/export/word/<filename>")
def export_log_word(filename: str):
    import io as _io

    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Pt, RGBColor, Inches
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
    except Exception:
        flash("Word export requires python-docx. Install dependencies and restart the app.", "danger")
        return redirect(url_for("log_detail", filename=filename))

    safe_filename = Path(filename).name
    log = _get_log(safe_filename)
    if not log:
        return "Log not found", 404

    all_logs = _get_logs()
    enriched = next((lg for lg in all_logs if lg.get("filename") == safe_filename), None)
    if enriched:
        log = enriched

    # ── Severity assessment helpers ────────────────────────────────────────────
    def _assess_severity(metric_name: str, value) -> tuple[str, tuple[int, int, int]]:
        """Return (severity_text, rgb_color): PASS/WARN/FAIL and color."""
        if value is None:
            return ("N/A", (128, 128, 128))

        try:
            v_float = float(value)
        except Exception:
            return (str(value), (128, 128, 128))

        # Thresholds for common metrics (adjust based on domain knowledge)
        thresholds = {
            "coverage": (0.8, 0.5),           # >= 80% = PASS, >= 50% = WARN, < 50% = FAIL
            "correctness": (0.8, 0.5),
            "compliance": (0.85, 0.6),
            "equivalence": (0.9, 0.6),
            "hallucination": (0.1, 0.3),      # reversed: <= 10% = PASS, <= 30% = WARN, > 30% = FAIL
            "bleu": (0.7, 0.4),
        }

        metric_key = metric_name.lower().replace(" ", "_")
        if metric_key not in thresholds:
            return (f"{v_float:.2f}", (100, 100, 100))

        high, med = thresholds[metric_key]

        # For hallucination and error-like metrics (lower is better)
        if metric_key in ("hallucination",):
            if v_float <= med:
                return (f"{v_float:.2f} (PASS)", (34, 139, 34))
            elif v_float <= high:
                return (f"{v_float:.2f} (WARN)", (255, 140, 0))
            else:
                return (f"{v_float:.2f} (FAIL)", (220, 20, 60))
        # For positive metrics (higher is better)
        else:
            if v_float >= high:
                return (f"{v_float:.2f} (PASS)", (34, 139, 34))
            elif v_float >= med:
                return (f"{v_float:.2f} (WARN)", (255, 140, 0))
            else:
                return (f"{v_float:.2f} (FAIL)", (220, 20, 60))

    def _pct(value, digits: int = 0) -> str:
        if value is None:
            return "N/A"
        try:
            return f"{float(value) * 100:.{digits}f}%"
        except Exception:
            return str(value)

    def _yn(value) -> str:
        if value is True:
            return "Yes"
        if value is False:
            return "No"
        return "N/A"

    def _condition_label(value: str) -> str:
        mapping = {
            "framework": "Framework",
            "direct_llm": "Direct LLM",
            "manual": "Manual",
        }
        return mapping.get((value or "").lower(), value or "N/A")

    def _add_section(title: str, rgb: tuple[int, int, int], size: int = 13):
        p = doc.add_paragraph()
        run = p.add_run(title)
        run.bold = True
        run.font.size = Pt(size)
        run.font.color.rgb = RGBColor(*rgb)
        p.paragraph_format.space_before = Pt(12)
        p.paragraph_format.space_after = Pt(6)

    def _add_metric(label: str, value: str, color: tuple[int, int, int] | None = None, guidance: str = ""):
        p = doc.add_paragraph(style="List Bullet")
        r1 = p.add_run(f"{label}: ")
        r1.bold = True
        r2 = p.add_run(value)
        if color:
            r2.font.color.rgb = RGBColor(*color)
        if guidance:
            r3 = p.add_run(f"  ({guidance})")
            r3.italic = True
            r3.font.size = Pt(9)
            r3.font.color.rgb = RGBColor(128, 128, 128)

    def _shade_cell(cell, color_rgb: tuple[int, int, int]):
        """Shade table cell with color."""
        shading_elm = OxmlElement("w:shd")
        shading_elm.set(qn("w:fill"), f"{color_rgb[0]:02x}{color_rgb[1]:02x}{color_rgb[2]:02x}")
        cell._element.get_or_add_tcPr().append(shading_elm)

    doc = Document()
    normal_style = doc.styles["Normal"]
    normal_style.font.name = "Calibri"
    normal_style.font.size = Pt(10)

    title = doc.add_heading("PLC Results Export", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT

    subtitle = doc.add_paragraph()
    subtitle_run = subtitle.add_run(f"Task: {log.get('task_id', 'N/A')}  |  Run: {log.get('experiment_number', 'N/A')}")
    subtitle_run.font.size = Pt(11)
    subtitle_run.bold = True

    info = doc.add_paragraph()
    info.add_run(f"Timestamp: {log.get('timestamp', 'N/A')}\n")
    source_label = "LLM Built" if log.get("task_source") == "ai_builder" else "Benchmark"
    info.add_run(
        f"Source: {source_label} | Condition: {_condition_label(log.get('condition'))} | "
        f"Complexity: {str(log.get('complexity') or 'N/A').capitalize()} | RAG: "
        f"{'On' if log.get('rag_used') is True else 'Off' if log.get('rag_used') is False else 'N/A'}"
    )

    # ── EXECUTIVE SUMMARY ──────────────────────────────────────────────────────
    _add_section("Executive Summary", (25, 25, 112), size=14)
    fc = log.get("functional_correctness_rate")
    cov = log.get("statement_coverage")
    comp_ok = log.get("compilation_success") is True
    tc_list = log.get("st_test_results") or log.get("test_results") or []
    tc_pass = sum(1 for tc in tc_list if tc.get("passed")) if tc_list else 0

    summary_table = doc.add_table(rows=1, cols=4)
    summary_table.style = "Table Grid"
    hdr = summary_table.rows[0].cells
    for i, cell in enumerate(hdr):
        _shade_cell(cell, (41, 84, 209))
        cell.text = ["Compilation", "Test Pass Rate", "Coverage", "Spec Compliance"][i]
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.color.rgb = RGBColor(255, 255, 255)
                run.bold = True

    row = summary_table.add_row().cells
    comp_text = "✓ Success" if comp_ok else "✗ Failed"
    comp_color = (34, 139, 34) if comp_ok else (220, 20, 60)
    row[0].text = comp_text
    _shade_cell(row[0], (240, 248, 255) if comp_ok else (255, 240, 245))
    row[1].text = _pct(fc, 0)
    fc_color = (34, 139, 34) if (fc or 0) >= 0.75 else (255, 140, 0) if (fc or 0) >= 0.5 else (220, 20, 60)
    _shade_cell(row[1], (240, 248, 255) if (fc or 0) >= 0.75 else (255, 250, 205) if (fc or 0) >= 0.5 else (255, 240, 245))
    row[2].text = _pct(cov, 0)
    cov_color = (34, 139, 34) if (cov or 0) >= 0.8 else (255, 140, 0) if (cov or 0) >= 0.5 else (220, 20, 60)
    _shade_cell(row[2], (240, 248, 255) if (cov or 0) >= 0.8 else (255, 250, 205) if (cov or 0) >= 0.5 else (255, 240, 245))
    sc = log.get("spec_compliance_score")
    row[3].text = _pct(sc, 0)
    sc_color = (34, 139, 34) if (sc or 0) >= 0.85 else (255, 140, 0) if (sc or 0) >= 0.6 else (220, 20, 60)
    _shade_cell(row[3], (240, 248, 255) if (sc or 0) >= 0.85 else (255, 250, 205) if (sc or 0) >= 0.6 else (255, 240, 245))

    # Add key findings
    p = doc.add_paragraph()
    p.add_run("Key Findings: ").bold = True
    findings = []
    if not comp_ok:
        findings.append("Compilation failed - review error log")
    if (fc or 0) < 0.75:
        findings.append(f"Test correctness below target ({_pct(fc, 0)})")
    if (cov or 0) < 0.5:
        findings.append(f"Code coverage low ({_pct(cov, 0)})")
    if tc_list and tc_pass < len(tc_list):
        findings.append(f"{len(tc_list) - tc_pass} test case(s) failing")
    if not findings:
        findings.append("All key metrics within acceptable range")
    for finding in findings:
        doc.add_paragraph(finding, style="List Bullet")

    # ── DETAILED RESULTS ───────────────────────────────────────────────────────
    _add_section("RQ1 - Compilation", (13, 110, 253))
    _add_metric("Result", f"{'✓ Compiled' if comp_ok else '✗ Failed' if log.get('compilation_success') is False else 'N/A'}",
                (34, 139, 34) if comp_ok else (220, 20, 60) if log.get("compilation_success") is False else None)
    _add_metric("Iterations", str(log.get("iterations_needed") if log.get("iterations_needed") is not None else "N/A"),
                guidance="lower is better")
    _add_metric("Initial Syntax Errors", str(log.get("syntax_errors_initial") if log.get("syntax_errors_initial") is not None else "N/A"))

    _add_section("RQ2 - Correctness", (102, 16, 242))
    fc_display, fc_color = _assess_severity("correctness", fc)
    _add_metric("Test Pass Rate", fc_display, color=fc_color, guidance="target >= 80%")
    bleu = log.get("bleu_score")
    bleu_display, bleu_color = _assess_severity("bleu", bleu)
    _add_metric("BLEU Score", bleu_display if bleu is not None else "N/A", color=bleu_color if bleu is not None else None,
                guidance="target >= 0.7")
    cov_display, cov_color = _assess_severity("coverage", cov)
    _add_metric("Coverage", cov_display, color=cov_color, guidance="target >= 80%")
    hall = log.get("hallucination_rate")
    hall_display, hall_color = _assess_severity("hallucination", hall)
    _add_metric("Hallucination", hall_display if hall is not None else "N/A", color=hall_color if hall is not None else None,
                guidance="target <= 10%")
    _add_metric("Inconsistencies", str(log.get("logical_inconsistencies") if log.get("logical_inconsistencies") is not None else "N/A"),
                guidance="lower is better")

    _add_section("Spec Compliance (Agent 1)", (5, 150, 105))
    sc_display, sc_color = _assess_severity("compliance", sc)
    _add_metric("Compliance Score", sc_display, color=sc_color, guidance="target >= 85%")
    _add_metric("Conditions Met", str(log.get("conditions_met", "N/A")))
    _add_metric("Partial", str(log.get("conditions_partial", "N/A")))
    _add_metric("Missing", str(log.get("conditions_missing", "N/A")))
    sc_detail = log.get("spec_compliance_detail") or []
    if sc_detail:
        table = doc.add_table(rows=1, cols=4)
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        for cell in hdr:
            _shade_cell(cell, (200, 220, 100))
        hdr[0].text = "Priority"
        hdr[1].text = "Condition"
        hdr[2].text = "Verdict"
        hdr[3].text = "Evidence"
        for item in sc_detail:
            row = table.add_row().cells
            row[0].text = str(item.get("priority", ""))
            row[1].text = str(item.get("condition", ""))
            verdict = str(item.get("verdict", ""))
            row[2].text = verdict
            if verdict == "YES":
                _shade_cell(row[2], (240, 255, 240))
            elif verdict == "PARTIAL":
                _shade_cell(row[2], (255, 250, 205))
            else:
                _shade_cell(row[2], (255, 240, 245))
            row[3].text = str(item.get("evidence") or "")

    _add_section("Semantic Refinement (Agent 2)", (217, 119, 6))
    sri = log.get("semantic_refinement_iterations")
    _add_metric("Iterations", str(sri if sri is not None else "N/A"),
                guidance="0 = no refinement needed (best)")
    srl = log.get("semantic_refinement_log") or []
    if srl:
        table = doc.add_table(rows=1, cols=5)
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        for cell in hdr:
            _shade_cell(cell, (255, 200, 100))
        hdr[0].text = "Iter"
        hdr[1].text = "Fail In"
        hdr[2].text = "Fail Out"
        hdr[3].text = "Before"
        hdr[4].text = "After"
        for it in srl:
            row = table.add_row().cells
            row[0].text = str(it.get("iteration", ""))
            row[1].text = str(it.get("failures_in", ""))
            row[2].text = str(it.get("failures_out", ""))
            row[3].text = _pct(it.get("pass_rate_before"), 0)
            row[4].text = _pct(it.get("pass_rate_after"), 0)

    _add_section("Spec Gaps (Agent 3)", (220, 53, 69))
    gd = log.get("gaps_detected")
    _add_metric("Gap Count", str(gd if gd is not None else "N/A"),
                guidance="0 = no gaps (best)")
    gr = log.get("gap_report") or []
    if gr:
        table = doc.add_table(rows=1, cols=3)
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        for cell in hdr:
            _shade_cell(cell, (255, 150, 150))
        hdr[0].text = "Severity"
        hdr[1].text = "Concept"
        hdr[2].text = "Raw Requirement"
        for g in gr:
            row = table.add_row().cells
            row[0].text = str(g.get("severity", ""))
            row[1].text = str(g.get("concept", ""))
            row[2].text = str(g.get("raw_snippet", ""))

    _add_section("RQ3 - Cross-Language", (111, 66, 193))
    ld_ok = log.get("ld_compilation_success") is True
    fbd_ok = log.get("fbd_compilation_success") is True
    _add_metric("LD Compiled", f"{'✓ Yes' if ld_ok else '✗ No' if log.get('ld_compilation_success') is False else 'N/A'}",
                (34, 139, 34) if ld_ok else (220, 20, 60) if log.get('ld_compilation_success') is False else None)
    _add_metric("FBD Compiled", f"{'✓ Yes' if fbd_ok else '✗ No' if log.get('fbd_compilation_success') is False else 'N/A'}",
                (34, 139, 34) if fbd_ok else (220, 20, 60) if log.get('fbd_compilation_success') is False else None)
    equiv = log.get("semantic_equivalence_score")
    equiv_display, equiv_color = _assess_severity("equivalence", equiv)
    _add_metric("Semantic Equivalence", equiv_display if equiv is not None else "N/A", color=equiv_color if equiv is not None else None,
                guidance="target >= 0.9")
    _add_metric("Equivalence Level", str(log.get("equivalence_level") or "N/A"))

    _add_section("RQ4 - Productivity", (12, 120, 158))
    _add_metric("Dev Time (min)", f"{log.get('dev_time_minutes'):.1f}" if log.get("dev_time_minutes") is not None else "N/A")
    _add_metric("Model", str(log.get("model_used") or "N/A"))
    _add_metric("Prompt Style", str(log.get("prompt_style") or "N/A"))
    p2 = float(log.get("phase2_seconds") or 0)
    p3 = float(log.get("phase3_seconds") or 0)
    p4 = float(log.get("phase4_seconds") or log.get("phase5_seconds") or 0)
    a2 = float(log.get("agent2_seconds") or 0)
    total_llm = p2 + p3 + p4 + a2
    _add_metric("Generation Time (s)", f"{p2:.1f}")
    _add_metric("Refinement Time (s)", f"{p3:.1f}")
    _add_metric("Agent 2 Time (s)", f"{a2:.1f}")
    _add_metric("Translation Time (s)", f"{p4:.1f}")
    _add_metric("Total LLM Time (s)", f"{total_llm:.1f}")

    _add_section("Test Case Results", (2, 132, 199))
    if tc_list:
        table = doc.add_table(rows=1, cols=5)
        table.style = "Table Grid"
        hdr = table.rows[0].cells
        for cell in hdr:
            _shade_cell(cell, (100, 150, 200))
        hdr[0].text = "ID"
        hdr[1].text = "Description"
        hdr[2].text = "Result"
        hdr[3].text = "Expected"
        hdr[4].text = "Actual"

        for tc in tc_list:
            row = table.add_row().cells
            row[0].text = str(tc.get("id", ""))
            row[1].text = str(tc.get("description") or "")
            is_pass = tc.get("passed")
            row[2].text = "✓ PASS" if is_pass else "✗ FAIL"
            if is_pass:
                _shade_cell(row[2], (240, 255, 240))
            else:
                _shade_cell(row[2], (255, 240, 245))
            row[3].text = json.dumps(tc.get("expected"), ensure_ascii=False) if tc.get("expected") is not None else ""
            row[4].text = json.dumps(tc.get("actual"), ensure_ascii=False) if tc.get("actual") is not None else ""
    else:
        doc.add_paragraph("No test case results recorded.")

    out = _io.BytesIO()
    doc.save(out)
    out.seek(0)
    task = (log.get("task_id") or "result").strip().replace(" ", "_")
    return Response(
        out.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename={task}_results_export.docx"},
    )


@app.route("/results/import/excel", methods=["POST"])
def import_excel():
    """Import reviewer verdicts from an uploaded Excel file.
    Matches rows to existing logs by task_id + condition + timestamp prefix.
    Updates reviewer_id, reviewer_experience, and all review_* fields.
    Adds an 'imported' flag so imported reviews are identifiable.
    """
    import openpyxl, io as _io
    from pathlib import Path

    file = request.files.get("excel_file")
    if not file or not file.filename.endswith(".xlsx"):
        flash("Please upload a valid .xlsx file.", "danger")
        return redirect(url_for("results_page"))

    try:
        wb = openpyxl.load_workbook(_io.BytesIO(file.read()))
        ws = wb.active
        headers = [str(cell.value or "").strip().lower().replace(" ", "_") for cell in ws[1]]
    except Exception as e:
        flash(f"Failed to parse Excel file: {e}", "danger")
        return redirect(url_for("results_page"))

    REVIEW_IMPORT_FIELDS = [
        "reviewer_id", "reviewer_experience",
        "review_logic", "review_logic_comment",
        "review_interlocks", "review_interlocks_comment",
        "review_safety", "review_safety_comment",
        "review_iec", "review_iec_comment",
        "review_structure", "review_structure_comment",
        "review_decision", "escalated_for_review",
        "nasa_tlx_score", "review_time_minutes", "notes",
    ]

    all_logs = _get_logs()
    # Build lookup: (task_id, condition, timestamp[:16]) → filename
    log_index = {
        (lg.get("task_id",""), lg.get("condition",""), (lg.get("timestamp") or "")[:16]): lg["_filename"]
        for lg in all_logs
    }

    updated = 0
    skipped = 0
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not any(row): continue
        row_dict = {headers[i]: (row[i] if i < len(row) else "") for i in range(len(headers))}

        task_id   = str(row_dict.get("task_id", "") or "").strip()
        condition = str(row_dict.get("condition", "") or "").strip()
        timestamp = str(row_dict.get("timestamp", "") or "")[:16].strip()

        filename = log_index.get((task_id, condition, timestamp))
        if not filename:
            skipped += 1
            continue

        log = _get_log(filename)
        if not log:
            skipped += 1
            continue

        for field in REVIEW_IMPORT_FIELDS:
            col_key = field.lower().replace(" ", "_")
            if col_key in row_dict and row_dict[col_key] not in (None, ""):
                val = row_dict[col_key]
                # Normalise Yes/No booleans
                if isinstance(val, str) and val.lower() in ("yes", "true", "1"):
                    val = True
                elif isinstance(val, str) and val.lower() in ("no", "false", "0"):
                    val = False
                log[field] = val

        log["imported_from_excel"] = True
        _save_log(filename, log)
        updated += 1

    flash(f"Excel import complete: {updated} log(s) updated, {skipped} row(s) skipped (no matching log).",
          "success" if updated else "warning")
    return redirect(url_for("results_page"))


@app.route("/results/delete/<filename>", methods=["POST"])
def delete_log(filename: str):
    """Delete a single experiment log file."""
    from pathlib import Path
    safe = Path(filename).name          # strip any path traversal
    target = Path(config.EXPERIMENT_LOGS) / safe
    if target.exists() and target.suffix == ".json":
        target.unlink()
        flash(f"Deleted log: {safe}", "success")
    else:
        flash(f"Log not found: {safe}", "danger")
    return redirect(url_for("results_page"))


@app.route("/results/delete-all", methods=["POST"])
def delete_all_logs():
    """Delete ALL experiment log files."""
    from pathlib import Path
    count = 0
    for f in Path(config.EXPERIMENT_LOGS).glob("*.json"):
        f.unlink()
        count += 1
    flash(f"Deleted {count} experiment log(s).", "warning")
    return redirect(url_for("results_page"))


@app.route("/results/delete-experiment/<int:exp_num>", methods=["POST"])
def delete_experiment(exp_num: int):
    """Delete all logs belonging to a specific experiment number."""
    logs = _get_logs()
    count = 0
    for lg in logs:
        if lg.get("experiment_number") == exp_num:
            target = Path(config.EXPERIMENT_LOGS) / lg["_filename"]
            if target.exists():
                target.unlink()
                count += 1
    flash(f"Deleted {count} log(s) from Experiment {exp_num}.", "warning")
    return redirect(url_for("results_page"))


@app.route("/results/delete-old", methods=["POST"])
def delete_old_runs():
    """Delete all logs except those in the latest experiment group."""
    from collections import defaultdict
    logs = _get_logs()
    exp_groups: dict = defaultdict(list)
    for lg in logs:
        exp_groups[lg.get("experiment_number", 0)].append(lg)
    if not exp_groups:
        flash("No logs to delete.", "info")
        return redirect(url_for("results_page"))
    latest_exp = max(exp_groups.keys())
    count = 0
    for exp_num, entries in exp_groups.items():
        if exp_num != latest_exp:
            for lg in entries:
                target = Path(config.EXPERIMENT_LOGS) / lg["_filename"]
                if target.exists():
                    target.unlink()
                    count += 1
    flash(f"Deleted {count} old log(s). Latest experiment kept.", "warning")
    return redirect(url_for("results_page"))


@app.route("/results/<filename>")
def log_detail(filename: str):
    log = _get_log(filename)
    if not log:
        return "Log not found", 404

    safe_filename = Path(filename).name
    all_logs = _get_logs()
    enriched_log = next((lg for lg in all_logs if lg.get("filename") == safe_filename), None)
    if enriched_log:
        log = enriched_log

    exp_num = log.get("experiment_number")
    related_logs = [lg for lg in all_logs if lg.get("experiment_number") == exp_num] if exp_num else [log]
    exp_nums = sorted({lg.get("experiment_number") for lg in all_logs if lg.get("experiment_number")}, reverse=True)
    is_latest_run = bool(exp_nums and exp_num == exp_nums[0])
    is_baseline_run = bool(exp_nums and exp_num == exp_nums[-1])

    task_id = log.get("task_id", "")

    # Find generated ST code (try all prompt styles)
    generated_st = None
    st_filename  = None
    resolved_st = _resolve_generated_code_path(task_id, log.get("prompt_style", "standard"), log.get("condition"))
    if resolved_st:
        generated_st = resolved_st.read_text(encoding="utf-8")
        st_filename = resolved_st.name

    # Load LD / FBD XML if available
    ld_xml  = None; ld_filename  = None
    fbd_xml = None; fbd_filename = None
    ld_path  = config.TRANSLATED_CODE / f"{task_id}_LD.xml"
    fbd_path = config.TRANSLATED_CODE / f"{task_id}_FBD.xml"
    if ld_path.exists():
        ld_xml  = ld_path.read_text(encoding="utf-8");  ld_filename  = ld_path.name
    if fbd_path.exists():
        fbd_xml = fbd_path.read_text(encoding="utf-8"); fbd_filename = fbd_path.name

    return render_template("log_detail.html", log=log, filename=filename,
                           generated_st=generated_st, st_filename=st_filename,
                           ld_xml=ld_xml,  ld_filename=ld_filename,
                           fbd_xml=fbd_xml, fbd_filename=fbd_filename,
                           related_logs=related_logs,
                           is_latest_run=is_latest_run,
                           is_baseline_run=is_baseline_run)


@app.route("/results/download/st/<task_id>")
def download_st(task_id: str):
    """
    Download generated ST code wrapped in a valid PLCopen TC6 XML document
    so it can be imported directly into edge.autonomylogic.com via
    File -> Import PLCopen XML.
    """
    from src.cross_lang_mapper import st_to_plcopen_xml
    # 1. prefer pre-generated ST XML wrapper
    st_xml_path = config.TRANSLATED_CODE / f"{task_id}_ST.xml"
    if st_xml_path.exists():
        return Response(
            st_xml_path.read_text(encoding="utf-8"),
            mimetype="application/xml",
            headers={"Content-Disposition": f"attachment; filename={st_xml_path.name}"}
        )
    # 2. generate on-the-fly from raw .st file
    for suffix in ["standard", "chain_of_thought", "program_of_thought", "manual"]:
        p = config.GENERATED_CODE / f"{task_id}_{suffix}.st"
        if p.exists():
            xml_content = st_to_plcopen_xml(p.read_text(encoding="utf-8"), task_id)
            fname = f"{task_id}_ST.xml"
            return Response(
                xml_content,
                mimetype="application/xml",
                headers={"Content-Disposition": f"attachment; filename={fname}"}
            )
    return "ST file not found", 404


@app.route("/results/download/st-raw/<task_id>")
def download_st_raw(task_id: str):
    """Download generated ST code as plain .st text."""
    for suffix in ["standard", "chain_of_thought", "program_of_thought", "manual"]:
        p = config.GENERATED_CODE / f"{task_id}_{suffix}.st"
        if p.exists():
            return Response(
                p.read_text(encoding="utf-8"),
                mimetype="text/plain",
                headers={"Content-Disposition": f"attachment; filename={p.name}"}
            )
    return "ST file not found", 404


@app.route("/results/download/xml/<task_id>/<lang>")
def download_xml(task_id: str, lang: str):
    """Download LD or FBD PLCopen XML file."""
    if lang.upper() not in ("LD", "FBD"):
        return "Invalid language", 400
    p = config.TRANSLATED_CODE / f"{task_id}_{lang.upper()}.xml"
    if not p.exists():
        return "XML file not found", 404
    return Response(
        p.read_text(encoding="utf-8"),
        mimetype="application/xml",
        headers={"Content-Disposition": f"attachment; filename={p.name}"}
    )


# ─── Routes: Expert Review ────────────────────────────────────────────────────

@app.route("/review")
def review_page():
    all_logs = _get_logs()
    pending  = [lg for lg in all_logs if _needs_review(lg)]
    reviewed = [lg for lg in all_logs if not _needs_review(lg)]
    exp_nums = sorted(set(lg.get("experiment_number", 0) for lg in all_logs), reverse=True)
    return render_template("review.html", pending=pending, reviewed=reviewed,
                           total=len(all_logs), all_logs=all_logs, exp_nums=exp_nums)


def _needs_review(log: dict) -> bool:
    return any(log.get(f) is None for f in [
        "review_logic", "review_interlocks", "review_safety",
        "review_iec", "review_structure", "review_decision",
    ])


@app.route("/review/export-word")
def review_export_word():
    """Export the review queue as a Word (.docx) document matching the UI table layout."""
    import io
    from datetime import datetime as _dt
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    def _set_bg(cell, hex_color: str):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), hex_color)
        tcPr.append(shd)

    def _verdict(v):
        if v == "acceptable":       return "Acceptable",     "D9F0DA"
        if v == "needs_improvement": return "Needs Impr.",   "FFF8CC"
        if v == "wrong":            return "Wrong",          "F8D7DA"
        return "\u2014", "FFFFFF"

    def _decision(d):
        if d == "accept":         return "Accept",          "D9F0DA"
        if d == "needs_revision": return "Needs Revision",  "FFF8CC"
        if d == "reject":         return "Reject",          "F8D7DA"
        return "\u2014", "FFFFFF"

    def _font8(cell):
        for para in cell.paragraphs:
            for run in para.runs:
                run.font.size = Pt(8)

    all_logs = _get_logs()
    exp_nums = sorted(set(lg.get("experiment_number", 0) for lg in all_logs), reverse=True)
    pending_all  = [lg for lg in all_logs if _needs_review(lg)]
    reviewed_all = [lg for lg in all_logs if not _needs_review(lg)]

    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(10)

    # ── Title ──────────────────────────────────────────────────────────────
    t = doc.add_heading("Expert Review Report", 0)
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER

    p = doc.add_paragraph(f'Generated: {_dt.now().strftime("%Y-%m-%d %H:%M")}')
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if p.runs:
        p.runs[0].font.color.rgb = RGBColor(0x6B, 0x72, 0x80)

    doc.add_paragraph()
    kpi = doc.add_paragraph()
    run = kpi.add_run(
        f"Total: {len(all_logs)}   \u2022   Reviewed: {len(reviewed_all)}"
        f"   \u2022   Pending: {len(pending_all)}   \u2022   Experiment Groups: {len(exp_nums)}"
    )
    run.bold = True

    HDR_BG  = "F3F4F6"
    PEND_BG = "FFF7ED"
    REV_BG  = "F0FDF4"

    for exp_num in exp_nums:
        grp_logs     = [lg for lg in all_logs if lg.get("experiment_number") == exp_num]
        grp_reviewed = [lg for lg in grp_logs if not _needs_review(lg)]
        grp_pending  = [lg for lg in grp_logs if _needs_review(lg)]
        date_str     = grp_logs[0].get("timestamp", "")[:10] if grp_logs else ""

        doc.add_heading(f"Run #{ exp_num }  \u2014  {date_str}", level=2)

        # ── Reviewed table ────────────────────────────────────────────────
        if grp_reviewed:
            h = doc.add_heading("Reviewed", level=3)
            h.runs[0].font.color.rgb = RGBColor(0x16, 0x65, 0x34)
            cols = ["Task", "Condition", "Complexity",
                    "Logic", "Interlocks", "Safety", "IEC", "Structure",
                    "Decision", "FC %", "NASA-TLX", "Review Time", "Notes"]
            tbl = doc.add_table(rows=1, cols=len(cols))
            tbl.style = "Table Grid"
            for i, col in enumerate(cols):
                c = tbl.rows[0].cells[i]
                c.text = col
                c.paragraphs[0].runs[0].bold = True
                c.paragraphs[0].runs[0].font.size = Pt(8)
                _set_bg(c, HDR_BG)
            for lg in grp_reviewed:
                row = tbl.add_row().cells
                row[0].text = lg.get("task_id", "\u2014")
                row[1].text = lg.get("condition", "\u2014").replace("_", " ").title()
                row[2].text = (lg.get("complexity") or "\u2014").title()
                for ci, field in enumerate(
                    ["review_logic", "review_interlocks", "review_safety",
                     "review_iec", "review_structure"], start=3
                ):
                    txt, bg = _verdict(lg.get(field))
                    row[ci].text = txt
                    if bg != "FFFFFF":
                        _set_bg(row[ci], bg)
                dt, db = _decision(lg.get("review_decision"))
                row[8].text = dt
                if db != "FFFFFF":
                    _set_bg(row[8], db)
                fc = lg.get("functional_correctness_rate")
                row[9].text  = f'{fc*100:.0f}%' if fc is not None else "\u2014"
                row[10].text = str(lg.get("nasa_tlx_score") or "\u2014")
                rt = lg.get("review_time_minutes")
                row[11].text = f"{rt:.1f} min" if rt is not None else "\u2014"
                row[12].text = lg.get("notes") or ""
                for c in row:
                    _font8(c)

        # ── Pending table ─────────────────────────────────────────────────
        if grp_pending:
            h2 = doc.add_heading("Pending Review", level=3)
            h2.runs[0].font.color.rgb = RGBColor(0x9A, 0x34, 0x12)
            cols2 = ["Task", "Condition", "Complexity",
                     "Compiled", "FC %", "Statement Cov", "Hallucination", "SE Score", "Timestamp"]
            tbl2 = doc.add_table(rows=1, cols=len(cols2))
            tbl2.style = "Table Grid"
            for i, col in enumerate(cols2):
                c = tbl2.rows[0].cells[i]
                c.text = col
                c.paragraphs[0].runs[0].bold = True
                c.paragraphs[0].runs[0].font.size = Pt(8)
                _set_bg(c, HDR_BG)
            for lg in grp_pending:
                row = tbl2.add_row().cells
                row[0].text = lg.get("task_id", "\u2014")
                row[1].text = lg.get("condition", "\u2014").replace("_", " ").title()
                row[2].text = (lg.get("complexity") or "\u2014").title()
                comp = lg.get("compilation_success")
                row[3].text = "Yes" if comp is True else ("No" if comp is False else "\u2014")
                _set_bg(row[3], "D9F0DA" if comp is True else ("F8D7DA" if comp is False else "FFFFFF"))
                fc = lg.get("functional_correctness_rate")
                row[4].text = f'{fc*100:.0f}%' if fc is not None else "\u2014"
                if fc is not None:
                    _set_bg(row[4], "D9F0DA" if fc >= 0.8 else ("FFF8CC" if fc >= 0.5 else "F8D7DA"))
                cov = lg.get("statement_coverage")
                row[5].text = f'{cov*100:.0f}%' if cov is not None else "\u2014"
                hr = lg.get("hallucination_rate")
                row[6].text = f'{hr*100:.0f}%' if hr is not None and hr >= 0 else "\u2014"
                if hr is not None and hr >= 0:
                    _set_bg(row[6], "D9F0DA" if hr <= 0.1 else ("FFF8CC" if hr <= 0.3 else "F8D7DA"))
                se = lg.get("semantic_equivalence_score")
                row[7].text = f'{se:.2f}' if se is not None else "\u2014"
                row[8].text = lg.get("timestamp", "\u2014")[:16] if lg.get("timestamp") else "\u2014"
                for c in row:
                    _font8(c)

        doc.add_paragraph()

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    fname = f'review_report_{_dt.now().strftime("%Y%m%d_%H%M%S")}.docx'
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        as_attachment=True,
        download_name=fname,
    )


@app.route("/review/<filename>", methods=["GET", "POST"])
def review_log_page(filename: str):
    log = _get_log(filename)
    if not log:
        return "Log not found", 404

    if request.method == "POST":
        d = request.json or {}
        fields = [
            "review_logic", "review_logic_comment",
            "review_interlocks", "review_interlocks_comment",
            "review_safety", "review_safety_comment",
            "review_iec", "review_iec_comment",
            "review_structure", "review_structure_comment",
            "review_decision", "escalated_for_review",
            "review_time_minutes", "nasa_tlx_score", "notes",
            "reviewer_id", "reviewer_experience",
        ]
        for f in fields:
            if f in d:
                log[f] = d[f]
        _save_log(filename, log)
        return jsonify({"success": True})

    task_id = log.get("task_id", "")
    prompt_style = log.get("prompt_style", "standard")
    code_path = _resolve_generated_code_path(task_id, prompt_style, log.get("condition"))
    generated_code = code_path.read_text(encoding="utf-8") if code_path and code_path.exists() else ""

    # Load LD / FBD XML translations if available
    ld_path  = config.TRANSLATED_CODE / f"{task_id}_LD.xml"
    fbd_path = config.TRANSLATED_CODE / f"{task_id}_FBD.xml"
    ld_code  = ld_path.read_text(encoding="utf-8")  if ld_path.exists()  else ""
    fbd_code = fbd_path.read_text(encoding="utf-8") if fbd_path.exists() else ""

    # Load task for context
    task_path = config.BENCHMARK_DIR / f"{task_id}.json"
    task = json.loads(task_path.read_text(encoding="utf-8")) if task_path.exists() else {}

    return render_template("review_form.html", log=log, filename=filename,
                           generated_code=generated_code,
                           ld_code=ld_code, fbd_code=fbd_code,
                           task=task)


@app.route("/review/<filename>/regenerate", methods=["POST"])
def review_regenerate(filename: str):
    """
    Expert-guided LLM regeneration.
    Accepts the reviewer's category verdicts, inline comments, and a free-text
    improvement suggestion, then builds a targeted prompt and asks the LLM to
    produce a corrected version of the program.  The improved code is compiled,
    tested, and saved as a new revision.  The log is updated with the
    regeneration history so every improvement cycle is auditable.
    """
    log = _get_log(filename)
    if not log:
        return jsonify({"error": "Log not found"}), 404

    d = request.json or {}
    suggestion        = (d.get("suggestion") or "").strip()
    category_verdicts = d.get("verdicts", {})      # {field: verdict}
    category_comments = d.get("comments", {})      # {field: comment}

    task_id      = log.get("task_id", "")
    prompt_style = log.get("prompt_style", "standard")

    # ── Load current code ────────────────────────────────────────────────────
    code_path = _resolve_generated_code_path(task_id, prompt_style, log.get("condition"))
    if not code_path or not code_path.exists():
        return jsonify({"error": "Generated code file not found"}), 404

    current_code = code_path.read_text(encoding="utf-8")

    # ── Load task spec for context ────────────────────────────────────────────
    task_path = config.BENCHMARK_DIR / f"{task_id}.json"
    task = json.loads(task_path.read_text(encoding="utf-8")) if task_path.exists() else {}

    # ── Build structured improvement prompt ──────────────────────────────────
    CATEGORY_LABELS = {
        "review_logic":       "Functional Logic",
        "review_interlocks":  "Interlocks & Enable Conditions",
        "review_safety":      "Safety Constraints",
        "review_iec":         "IEC 61131-3 Compliance",
        "review_structure":   "Program Structure & Clarity",
    }

    issue_lines = []
    for field, label in CATEGORY_LABELS.items():
        verdict = category_verdicts.get(field, "acceptable")
        comment = (category_comments.get(field) or "").strip()
        if verdict in ("needs_improvement", "wrong"):
            severity = "WRONG" if verdict == "wrong" else "NEEDS IMPROVEMENT"
            line = f"  [{severity}] {label}"
            if comment:
                line += f": {comment}"
            issue_lines.append(line)

    if suggestion:
        issue_lines.append(f"\n  [ENGINEER SUGGESTION] {suggestion}")

    if not issue_lines:
        return jsonify({"error": "No issues or suggestions provided — nothing to regenerate."}), 400

    issues_text = "\n".join(issue_lines)

    from src.normalizer import format_for_prompt
    req_str = format_for_prompt(task.get("normalized_requirement", {}))

    regen_prompt = f"""You are an expert IEC 61131-3 PLC programmer performing a code review correction.

An engineer has reviewed the following Structured Text program and identified specific issues.
Your task is to fix ONLY the identified issues while preserving all correct logic.
Do not rewrite sections that were not flagged.

--- ORIGINAL REQUIREMENT ---
{req_str}

--- CURRENT PROGRAM (with issues) ---
{current_code}

--- IDENTIFIED ISSUES ---
{issues_text}

Return the complete corrected IEC 61131-3 Structured Text program only.
Do not add explanations or comments about changes made.
Preserve the PROGRAM...END_PROGRAM structure and all correct logic.
"""

    # ── Call LLM ─────────────────────────────────────────────────────────────
    client = _make_openai_client()
    if client is None:
        return jsonify({"error": "LLM not available in MOCK mode."}), 400

    try:
        from src.llm_generator import _extract_code_block
        resp = client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert IEC 61131-3 PLC programmer. "
                        "Fix only the issues identified by the engineer. "
                        "Output only syntactically correct Structured Text code."
                    )
                },
                {"role": "user", "content": regen_prompt}
            ],
            temperature=0.1,
        )
        improved_code = _extract_code_block(resp.choices[0].message.content.strip())
    except Exception as e:
        return jsonify({"error": f"LLM call failed: {str(e)}"}), 500

    # ── Compile improved code ─────────────────────────────────────────────────
    from src.compiler_feedback import compile_with_openplc
    compile_result = compile_with_openplc(improved_code, config.COMPILER_PATH)

    # ── Run tests on improved code ────────────────────────────────────────────
    from src.test_runner import run_test_cases_with_coverage, compute_functional_correctness
    test_cases = task.get("test_cases", [])
    fcr = None
    cov = None
    test_results = []
    if test_cases:
        test_results, cov = run_test_cases_with_coverage(improved_code, test_cases)
        fcr = compute_functional_correctness(test_results)

    # ── Save improved code as new revision ────────────────────────────────────
    revision_num = len(log.get("regeneration_history", [])) + 1
    revised_path = config.GENERATED_CODE / f"{task_id}_{prompt_style}_rev{revision_num}.st"
    from src.llm_generator import save_generated_code
    save_generated_code(improved_code, str(revised_path))

    # ── Record regeneration history in log ────────────────────────────────────
    history_entry = {
        "revision":             revision_num,
        "timestamp":            __import__("datetime").datetime.now().isoformat(),
        "issues_addressed":     issue_lines,
        "suggestion":           suggestion,
        "compilation_success":  compile_result["success"],
        "syntax_errors":        len(compile_result["errors"]),
        "functional_correctness_rate": fcr,
        "statement_coverage":   round(cov, 4) if cov is not None else None,
        "saved_as":             str(revised_path.name),
    }
    if "regeneration_history" not in log:
        log["regeneration_history"] = []
    log["regeneration_history"].append(history_entry)

    # Update top-level metrics to reflect latest revision
    log["compilation_success"]          = compile_result["success"]
    log["syntax_errors_final"]          = len(compile_result["errors"])
    if fcr is not None:
        log["functional_correctness_rate"] = fcr
    if cov is not None:
        log["statement_coverage"]       = round(cov, 4)

    _save_log(filename, log)

    return jsonify({
        "success":              True,
        "revision":             revision_num,
        "improved_code":        improved_code,
        "compilation_success":  compile_result["success"],
        "compiler_errors":      compile_result["errors"],
        "functional_correctness_rate": fcr,
        "statement_coverage":   round(cov, 4) if cov is not None else None,
        "test_results":         test_results,
        "saved_as":             str(revised_path.name),
    })


# ─── Routes: API helpers ──────────────────────────────────────────────────────

@app.route("/api/task/<task_id>")
def api_task(task_id: str):
    p = config.BENCHMARK_DIR / f"{task_id}.json"
    if not p.exists():
        return jsonify({"error": "not found"}), 404
    return jsonify(json.loads(p.read_text(encoding="utf-8")))


@app.route("/api/summary")
def api_summary():
    from src.evaluator import load_all_logs, summarize_results
    logs = load_all_logs(str(config.EXPERIMENT_LOGS))
    return jsonify(summarize_results(logs) if logs else {})


# ─── Routes: AI-Assisted Task Creation ───────────────────────────────────────

@app.route("/tasks/new-ai")
def new_task_ai_page():
    return render_template("new_task_ai.html")


@app.route("/api/export-review-word", methods=["POST"])
def export_review_word():
    """Accept reviewed task JSON (from Step 2 Review & Edit) and return a .docx file."""
    import io
    from datetime import datetime as _dt
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    data = request.get_json(force=True) or {}

    def _set_bg(cell, hex6: str):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), hex6)
        tcPr.append(shd)

    def _font(cell, bold=False, size=9, white=False):
        for para in cell.paragraphs:
            for run in para.runs:
                run.font.size = Pt(size)
                run.bold = bold
                if white:
                    run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

    # Section config: (title, bg_hex, columns, row_extractor)
    SECTIONS = [
        ("X \u2014 Field Inputs",       "0D1F35", ["Name", "Type", "Description"],
         lambda d: [[v.get("name",""), v.get("type",""), v.get("description","")] for v in (d.get("inputs") or [])]),
        ("Y \u2014 Outputs",             "0C2419", ["Name", "Type", "Description"],
         lambda d: [[v.get("name",""), v.get("type",""), v.get("description","")] for v in (d.get("outputs") or [])]),
        ("T \u2014 Timers",              "2A2010", ["Name", "Type", "Preset", "Description"],
         lambda d: [[v.get("name",""), v.get("type",""), str(v.get("preset","")), v.get("description","")] for v in (d.get("timers") or [])]),
        ("C \u2014 Counters",            "2A1610", ["Name", "Type", "Preset", "Description"],
         lambda d: [[v.get("name",""), v.get("type",""), str(v.get("preset","")), v.get("description","")] for v in (d.get("counters") or [])]),
        ("M \u2014 Internal Variables",  "1A1535", ["Name", "Type", "Initial Value", "Description"],
         lambda d: [[v.get("name",""), v.get("type",""), str(v.get("initial_value","")), v.get("description","")] for v in (d.get("internal_variables") or [])]),
        ("S \u2014 Interlocks & Safety", "2A1525", ["Rule"],
         lambda d: [[r] for r in (d.get("interlocks") or []) if r]),
        ("Logic \u2014 Control Conditions", "1A2035", ["Priority", "Condition"],
         lambda d: [[c.get("priority",""), c.get("condition","")] for c in (d.get("control_conditions") or [])]),
        ("TC \u2014 Test Cases",          "1A3520", ["ID", "Description", "Inputs", "Expected Outputs"],
         lambda d: [
             [tc.get("id",""), tc.get("description",""),
              str(tc.get("inputs",{})), str(tc.get("expected_outputs",{}))]
             for tc in (d.get("test_cases") or [])
         ]),
    ]

    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(10)

    # \u2500\u2500 Header \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    sys_name = data.get("system_name") or "PLC Task"
    t = doc.add_heading(sys_name, 0)
    t.alignment = WD_ALIGN_PARAGRAPH.LEFT

    desc = data.get("description") or ""
    if desc:
        p = doc.add_paragraph(desc)
        p.runs[0].font.color.rgb = RGBColor(0x37, 0x41, 0x51) if p.runs else None

    meta = doc.add_paragraph()
    meta.add_run(f"Complexity: {(data.get('complexity') or 'n/a').title()}   \u2022   "
                 f"Generated: {_dt.now().strftime('%Y-%m-%d %H:%M')}").font.size = Pt(9)
    meta.runs[0].font.color.rgb = RGBColor(0x6B, 0x72, 0x80)
    doc.add_paragraph()

    # \u2500\u2500 Per section \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    for title, bg_hex, cols, extractor in SECTIONS:
        rows = extractor(data)

        # Section heading bar (dark colored, white text — matches UI)
        h = doc.add_paragraph()
        h_run = h.add_run(f"  {title}")
        h_run.bold = True
        h_run.font.size = Pt(9)
        h_run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        from docx.oxml.ns import qn as _qn
        from docx.oxml import OxmlElement as _OE
        pPr = h._p.get_or_add_pPr()
        shd2 = _OE("w:shd")
        shd2.set(_qn("w:val"), "clear")
        shd2.set(_qn("w:color"), "auto")
        shd2.set(_qn("w:fill"), bg_hex.upper())
        pPr.append(shd2)
        h.paragraph_format.space_before = Pt(4)
        h.paragraph_format.space_after  = Pt(0)

        # Data table
        tbl = doc.add_table(rows=1, cols=len(cols))
        tbl.style = "Table Grid"
        # Header row
        for i, col in enumerate(cols):
            c = tbl.rows[0].cells[i]
            c.text = col
            c.paragraphs[0].runs[0].bold = True
            c.paragraphs[0].runs[0].font.size = Pt(8)
            c.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            _set_bg(c, bg_hex.upper())
        # Data rows
        if rows:
            for row_data in rows:
                row = tbl.add_row().cells
                for i, val in enumerate(row_data):
                    row[i].text = str(val) if val is not None else ""
                    row[i].paragraphs[0].runs[0].font.size = Pt(8) if row[i].paragraphs[0].runs else None
                    if row[i].paragraphs[0].runs:
                        row[i].paragraphs[0].runs[0].font.size = Pt(8)
        else:
            row = tbl.add_row().cells
            row[0].text = "(none)"
            if row[0].paragraphs[0].runs:
                row[0].paragraphs[0].runs[0].font.size = Pt(8)
                row[0].paragraphs[0].runs[0].font.italic = True
                row[0].paragraphs[0].runs[0].font.color.rgb = RGBColor(0x9C, 0xA3, 0xAF)

        doc.add_paragraph()  # spacer

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    safe = (sys_name or "task").replace(" ", "_")[:40]
    fname = f"{safe}_review_table.docx"
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        as_attachment=True,
        download_name=fname,
    )


@app.route("/api/analyze-requirement-stream", methods=["POST"])
def analyze_requirement_stream():
    """
    SSE-streaming version of analyze-requirement.
    Sends progress events while the LLM generates so the UI shows live feedback.
    Event shape:  data: {"status": "thinking"|"streaming"|"done"|"error", ...}
    """
    import re as _re
    from pathlib import Path as _Path
    import config as _cfg

    data = request.get_json(force=True) or {}
    raw_req = (data.get("requirement") or "").strip()
    # Per-request RAG toggle from the Task Builder UI. Defaults to global config.
    use_rag = data.get("use_rag", config.RAG_ENABLED)
    if isinstance(use_rag, str):
        use_rag = use_rag.lower() in ("1", "true", "yes", "on")

    def _send(obj):
        return f"data: {json.dumps(obj)}\n\n"

    def generate():
        _t_start = time.time()
        if not raw_req:
            yield _send({"status": "error", "message": "requirement text is required"})
            return

        yield _send({"status": "thinking", "message": "Loading prompt template…"})

        try:
            prompt_tmpl = (_Path(__file__).parent / "prompts" / "analyze_requirement.txt").read_text(encoding="utf-8")
            prompt_text = prompt_tmpl.format(requirement=raw_req)
        except Exception as exc:
            yield _send({"status": "error", "message": f"Prompt load error: {exc}"})
            return

        # ── Optional RAG context (per-request toggle) ─────────────────────────
        rag_used = False
        if use_rag:
            try:
                rag = _get_rag(force=True)
                rag_ctx = rag.analysis_context(raw_req, k=config.RAG_TOP_K) if rag else ""
                if rag_ctx and rag_ctx.strip():
                    prompt_text = prompt_text + "\n\n" + rag_ctx
                    rag_used = True
                    yield _send({"status": "thinking", "message": "Injected RAG context from similar tasks…"})
            except Exception as exc:  # noqa: BLE001
                yield _send({"status": "thinking", "message": f"RAG unavailable, continuing without it… ({type(exc).__name__})"})

        provider = _cfg.active_provider()
        errors = []

        # ── Ollama (streaming) ────────────────────────────────────────────────
        if provider == "ollama":
            yield _send({"status": "thinking", "message": f"Connecting to Ollama ({_cfg.OLLAMA_MODEL})…"})
            try:
                ollama_timeout = float(getattr(_cfg, "LLM_REQUEST_TIMEOUT_SECONDS", 300))
                client = openai.OpenAI(
                    base_url=_cfg.OLLAMA_BASE_URL,
                    api_key=_cfg.OLLAMA_API_KEY,
                    http_client=httpx.Client(timeout=ollama_timeout),
                )
                stream = client.chat.completions.create(
                    model=_cfg.OLLAMA_MODEL,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": prompt_text},
                    ],
                    temperature=0.1,
                    stream=True,
                )
                full_text = ""
                char_count = 0
                for chunk in stream:
                    delta = (chunk.choices[0].delta.content or "") if chunk.choices else ""
                    if delta:
                        full_text += delta
                        char_count += len(delta)
                        # Send a progress ping every ~80 chars to avoid flooding
                        if (char_count // 80) != ((char_count - len(delta)) // 80):
                            yield _send({"status": "streaming", "chars": char_count,
                                         "preview": full_text[-80:].replace("\n", " ")})

                # Strip markdown fences that small models sometimes emit
                text = full_text.strip()
                if text.startswith("```"):
                    text = _re.sub(r"^```[a-z]*\n?", "", text)
                    text = _re.sub(r"\n?```$", "", text.strip())
                result = json.loads(text.strip())
                yield _send({"status": "done", "result": result, "mock": False, "provider": "ollama",
                             "rag_used": rag_used,
                             "duration_s": round(time.time() - _t_start, 1)})
                return
            except json.JSONDecodeError as jde:
                errors.append(f"Ollama JSON parse error: {jde}")
                yield _send({"status": "thinking", "message": f"JSON parse failed, falling back… ({jde})"})
            except Exception as exc:
                errors.append(f"Ollama: {exc}")
                yield _send({"status": "thinking", "message": f"Ollama error, falling back… ({type(exc).__name__})"})

        # ── Gemini ────────────────────────────────────────────────────────────
        if provider in ("gemini", "auto") and _cfg.GEMINI_API_KEY:
            yield _send({"status": "thinking", "message": "Trying Gemini…"})
            try:
                result = _gemini_analyze_text(prompt_text)
                yield _send({"status": "done", "result": result, "mock": False, "provider": "gemini",
                             "rag_used": rag_used,
                             "duration_s": round(time.time() - _t_start, 1)})
                return
            except Exception as exc:
                errors.append(f"Gemini: {exc}")

        # ── OpenAI-compatible (Groq / OpenRouter / DeepSeek / …) ──────────────
        if provider == "openai_compatible":
            base_url, api_key, model = _cfg.openai_compatible_config()
            yield _send({"status": "thinking", "message": f"Trying {_cfg.LLM_PROVIDER} ({model})…"})
            try:
                client = openai.OpenAI(
                    base_url=base_url, api_key=api_key,
                    http_client=httpx.Client(timeout=float(getattr(_cfg, "LLM_REQUEST_TIMEOUT_SECONDS", 300))),
                )
                response = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": prompt_text},
                    ],
                    temperature=0.1,
                    response_format={"type": "json_object"},
                )
                txt = response.choices[0].message.content.strip()
                if txt.startswith("```"):
                    txt = _re.sub(r"^```[a-z]*\n?", "", txt)
                    txt = _re.sub(r"\n?```$", "", txt.strip())
                result = _loads_lenient(txt)
                yield _send({"status": "done", "result": result, "mock": False, "provider": _cfg.LLM_PROVIDER,
                             "rag_used": rag_used,
                             "duration_s": round(time.time() - _t_start, 1)})
                return
            except Exception as exc:
                errors.append(f"{_cfg.LLM_PROVIDER}: {exc}")

        # ── OpenAI ────────────────────────────────────────────────────────────
        if provider in ("openai", "auto") and _cfg.OPENAI_API_KEY:
            yield _send({"status": "thinking", "message": "Trying OpenAI…"})
            try:
                client = openai.OpenAI(api_key=_cfg.OPENAI_API_KEY)
                response = client.chat.completions.create(
                    model=_cfg.LLM_MODEL,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": prompt_text},
                    ],
                    temperature=0.1,
                    response_format={"type": "json_object"},
                )
                result = json.loads(response.choices[0].message.content.strip())
                yield _send({"status": "done", "result": result, "mock": False, "provider": "openai",
                             "rag_used": rag_used,
                             "duration_s": round(time.time() - _t_start, 1)})
                return
            except Exception as exc:
                errors.append(f"OpenAI: {exc}")

        # ── Mock fallback ─────────────────────────────────────────────────────
        yield _send({"status": "thinking", "message": "Using keyword-based fallback…"})
        stub = _mock_analyze_requirement(raw_req)
        reason = "; ".join(errors) if errors else "No LLM keys configured"
        yield _send({"status": "done", "result": stub, "mock": True, "provider": "mock",
                     "rag_used": False,
                     "duration_s": round(time.time() - _t_start, 1),
                     "warning": f"LLM unavailable ({reason}) — keyword analysis used instead."})

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.route("/api/analyze-requirement", methods=["POST"])
def analyze_requirement():
    """
    Call LLM with the raw requirement text and return a structured
    categorisation (inputs, outputs, timers, counters, interlocks, test cases).
    Tries Gemini first, then OpenAI, then falls back to keyword mock.
    MOCK_LLM is intentionally ignored here — it only gates code generation.
    """
    data = request.get_json(force=True) or {}
    raw_req = (data.get("requirement") or "").strip()
    if not raw_req:
        return jsonify({"error": "requirement text is required"}), 400
    # Per-request RAG toggle from the Task Builder UI. Defaults to global config.
    use_rag = data.get("use_rag", config.RAG_ENABLED)
    if isinstance(use_rag, str):
        use_rag = use_rag.lower() in ("1", "true", "yes", "on")

    # Analysis quality should prefer real LLMs even when MOCK_LLM is enabled
    # for code-generation experiments. Temporarily disable mock mode for this
    # endpoint only, and always restore it.
    _orig_mock_llm = config.MOCK_LLM
    config.MOCK_LLM = False
    try:
        from pathlib import Path as _Path
        import config as _cfg
        prompt_tmpl = (_Path(__file__).parent / "prompts" / "analyze_requirement.txt").read_text(encoding="utf-8")
        prompt_text = prompt_tmpl.format(requirement=raw_req)

        # ── Optional RAG context (per-request toggle) ─────────────────────────
        rag_used = False
        if use_rag:
            try:
                rag = _get_rag(force=True)
                rag_ctx = rag.analysis_context(raw_req, k=config.RAG_TOP_K) if rag else ""
                if rag_ctx and rag_ctx.strip():
                    prompt_text = prompt_text + "\n\n" + rag_ctx
                    rag_used = True
            except Exception:  # noqa: BLE001
                rag_used = False

        errors = []

        provider = _cfg.active_provider()

        # ── 0. Try AWS Bedrock ────────────────────────────────────────────────────
        if provider == "bedrock" and _cfg.AWS_ACCESS_KEY_ID and _cfg.AWS_SECRET_ACCESS_KEY:
            try:
                result = _bedrock_analyze_text(prompt_text)
                return jsonify({"ok": True, "result": result, "mock": False, "rag_used": rag_used, "provider": "bedrock"})
            except Exception as exc:
                errors.append(f"Bedrock: {exc}")

        # ── 1. Try Gemini ────────────────────────────────────────────────────────────
        if provider in ("gemini", "auto") and _cfg.GEMINI_API_KEY:
            try:
                result = _gemini_analyze_text(prompt_text)
                return jsonify({"ok": True, "result": result, "mock": False, "rag_used": rag_used, "provider": "gemini"})
            except Exception as exc:
                errors.append(f"Gemini: {exc}")

        # ── 2. Try Ollama (OpenAI-compatible local endpoint) ───────────────────────
        if provider == "ollama":
            try:
                ollama_timeout = float(getattr(_cfg, "LLM_REQUEST_TIMEOUT_SECONDS", 300))
                client = openai.OpenAI(
                    base_url=_cfg.OLLAMA_BASE_URL,
                    api_key=_cfg.OLLAMA_API_KEY,
                    http_client=httpx.Client(timeout=ollama_timeout),
                )
                response = client.chat.completions.create(
                    model=_cfg.OLLAMA_MODEL,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": prompt_text},
                    ],
                    temperature=0.1,
                )
                result = json.loads(response.choices[0].message.content.strip())
                return jsonify({"ok": True, "result": result, "mock": False, "rag_used": rag_used, "provider": "ollama"})
            except Exception as exc:
                errors.append(f"Ollama: {exc}")

        # ── 2b. Try OpenAI-compatible (Groq / OpenRouter / DeepSeek / …) ───────────
        if provider == "openai_compatible":
            try:
                base_url, api_key, model = _cfg.openai_compatible_config()
                client = openai.OpenAI(
                    base_url=base_url, api_key=api_key,
                    http_client=httpx.Client(timeout=float(getattr(_cfg, "LLM_REQUEST_TIMEOUT_SECONDS", 300))),
                )
                response = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user", "content": prompt_text},
                    ],
                    temperature=0.1,
                    response_format={"type": "json_object"},
                )
                result = _loads_lenient(response.choices[0].message.content)
                return jsonify({"ok": True, "result": result, "mock": False, "rag_used": rag_used, "provider": _cfg.LLM_PROVIDER})
            except Exception as exc:
                errors.append(f"{_cfg.LLM_PROVIDER}: {exc}")

        # ── 3. Try OpenAI ────────────────────────────────────────────────────────────
        if provider in ("openai", "auto") and _cfg.OPENAI_API_KEY:
            try:
                client = openai.OpenAI(api_key=_cfg.OPENAI_API_KEY)
                response = client.chat.completions.create(
                    model=_cfg.LLM_MODEL,
                    messages=[
                        {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                        {"role": "user",   "content": prompt_text}
                    ],
                    temperature=0.1,
                    response_format={"type": "json_object"}
                )
                result = json.loads(response.choices[0].message.content.strip())
                return jsonify({"ok": True, "result": result, "mock": False, "rag_used": rag_used, "provider": "openai"})
            except Exception as exc:
                errors.append(f"OpenAI: {exc}")

        # ── 3. Keyword fallback ────────────────────────────────────────────────────
        stub = _mock_analyze_requirement(raw_req)
        reason = "; ".join(errors) if errors else "No LLM keys configured"
        return jsonify({"ok": True, "result": stub, "mock": True,
                        "warning": f"LLM unavailable ({reason}) — keyword analysis used instead."})
    finally:
        config.MOCK_LLM = _orig_mock_llm


@app.route("/api/analyze-diagram", methods=["POST"])
def analyze_diagram():
    """
    Accept a base64-encoded workflow diagram image and an optional text hint,
    use the OpenAI vision model to extract a structured PLC specification.
    Returns the same JSON shape as /api/analyze-requirement.
    """
    data      = request.get_json(force=True) or {}
    image_b64 = (data.get("image_b64") or "").strip()
    image_type = (data.get("image_type") or "image/png").strip()   # e.g. image/jpeg
    hint      = (data.get("hint") or "").strip()

    if not image_b64:
        return jsonify({"error": "image_b64 is required"}), 400

    from pathlib import Path as _Path
    prompt_tmpl = (_Path(__file__).parent / "prompts" / "analyze_diagram.txt").read_text(encoding="utf-8")
    hint_section = f"=== ADDITIONAL CONTEXT FROM USER ===\n{hint}\n====================================\n\n" if hint else ""
    prompt_text  = prompt_tmpl.format(hint_section=hint_section)

    import config as _cfg

    errors = []

    # ── Agent 4: helper — enrich any result with fidelity report ──────────────
    def _with_fidelity(result: dict, mock: bool, provider: str, warning: str = None):
        """Run Agent 4 Diagram Fidelity Verifier and embed report into response."""
        try:
            fidelity_report = verify_diagram_fidelity(
                image_b64=image_b64,
                image_type=image_type,
                extracted_spec=result,
                client=None,
            )
            badge = fidelity_badge(fidelity_report)
        except Exception as _fe:
            badge = {"fidelity_score": None, "fidelity_verdict": "unknown",
                     "fidelity_color": "secondary", "fidelity_label": "unknown",
                     "fidelity_warnings": [f"Fidelity check error: {_fe}"],
                     "missed_elements": [], "ambiguous_elements": []}
        payload = {"ok": True, "result": result, "mock": mock, "provider": provider,
                   "fidelity": badge}
        if warning:
            payload["warning"] = warning
        return jsonify(payload)

    # ── 0. Try AWS Bedrock (uses hint text as requirement) ──────────────────────
    if _cfg.AWS_ACCESS_KEY_ID and _cfg.AWS_SECRET_ACCESS_KEY and hint:
        try:
            from pathlib import Path as _Path2
            txt_tmpl = (_Path2(__file__).parent / "prompts" / "analyze_requirement.txt").read_text(encoding="utf-8")
            result = _bedrock_analyze_text(txt_tmpl.format(requirement=hint))
            if not result.get("raw_requirement"):
                result["raw_requirement"] = hint
            return _with_fidelity(result, mock=False, provider="bedrock")
        except Exception as exc:
            errors.append(f"Bedrock: {exc}")

    # ── 1. Try Gemini vision ─────────────────────────────────────────────────────
    if _cfg.GEMINI_API_KEY:
        try:
            result = _gemini_analyze_image(image_b64, image_type, prompt_text)
            return _with_fidelity(result, mock=False, provider="gemini")
        except Exception as exc:
            errors.append(f"Gemini: {exc}")

    # ── 2. Try OpenAI vision ─────────────────────────────────────────────────────
    if _cfg.OPENAI_API_KEY:
        try:
            client = openai.OpenAI(api_key=_cfg.OPENAI_API_KEY)
            response = client.chat.completions.create(
                model=_cfg.LLM_MODEL,
                messages=[
                    {"role": "system", "content": "You are an expert IEC 61131-3 PLC requirements analyst. Respond ONLY with valid JSON."},
                    {"role": "user", "content": [
                        {"type": "image_url", "image_url": {"url": f"data:{image_type};base64,{image_b64}", "detail": "high"}},
                        {"type": "text", "text": prompt_text}
                    ]}
                ],
                temperature=0.1,
                response_format={"type": "json_object"},
                max_tokens=4096
            )
            result = json.loads(response.choices[0].message.content.strip())
            return _with_fidelity(result, mock=False, provider="openai")
        except Exception as exc:
            errors.append(f"OpenAI: {exc}")

    # ── 3. Keyword fallback ────────────────────────────────────────────────────
    stub = _mock_analyze_requirement(hint or "workflow diagram")
    reason = "; ".join(errors) if errors else "No LLM keys configured"
    return _with_fidelity(stub, mock=True, provider="mock",
                          warning=f"LLM unavailable ({reason}) — keyword analysis used instead.")


def _run_custom_task_from_payload(data: dict):
    """Shared implementation for custom task run endpoints."""
    task  = data.get("task")
    run_mode_raw = str(data.get("run_mode", "sequence") or "sequence")
    run_mode = run_mode_raw.strip().lower().replace("-", "_").replace(" ", "_")
    if run_mode not in ("single", "sequence"):
        run_mode = "sequence"
    condition    = data.get("condition", "framework")
    prompt_style = data.get("prompt_style", "standard")
    exp_num_raw  = str(data.get("experiment_number", "")).strip()
    rag_enabled  = bool(data.get("rag_enabled", True))
    force_provider_raw = str(data.get("force_provider", "") or "").strip().lower()
    force_provider = force_provider_raw or None
    allowed_force = {"openai", "gemini", "ollama", "openai_compatible", "bedrock"}
    if force_provider and force_provider not in allowed_force:
        print(f"[Provider] Ignoring unsupported force_provider='{force_provider}'.")
        force_provider = None
    if not task:
        return jsonify({"error": "task object is required"}), 400

    experiment_number = int(exp_num_raw) if exp_num_raw.isdigit() else _next_experiment_number()

    task = _canonicalize_task_like_builder(task)
    task_id = task["task_id"]

    # Mark as AI-builder task
    task["task_source"] = "ai_builder"

    # Save to benchmark dir  (overwrite existing with same id)
    dest = config.BENCHMARK_DIR / f"{task_id}.json"
    dest.write_text(json.dumps(task, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[TaskBuilder] Saved custom task → {dest}")

    # Start run
    run_id = f"{task_id}_{run_mode}_{int(time.time())}"

    claimed, active_id = _claim_run_slot(run_id)
    if not claimed:
        return jsonify({
            "error": (
                "Another run is already in progress. Please wait for it to finish "
                "before starting a new run."
            ),
            "active_run_id": active_id,
        }), 409

    def _execute():
        from main import load_task, run_framework, run_direct_llm
        if force_provider:
            print(f"[Provider] force_provider requested by task run: {force_provider}")
        config.validate_config(provider=force_provider)
        client = _make_openai_client(force_provider=force_provider)  # also sets config.LLM_MODEL for non-OpenAI providers
        t = load_task(task_id)

        if run_mode == "sequence":
            sequence = FULL_SIX_COMBINATION_SEQUENCE
            results = []
            print(f"\n{'='*70}")
            print(f"  CUSTOM TASK SEQUENCE RUN")
            print(f"  Scope             : reviewed requirement only")
            print(f"  Task              : {task_id}")
            print(f"  Experiment Number : {experiment_number}")
            print(f"{'='*70}")

            for idx, (seq_cond, seq_prompt) in enumerate(sequence, start=1):
                seq_rag_enabled = rag_enabled
                print(f"\n{'-'*70}")
                print(f"  Sequence {idx}/{len(sequence)} : {seq_cond} | {seq_prompt}")
                print(f"{'-'*70}")
                print(
                    f"\n[Sequence] Running reviewed task '{task_id}' with {seq_cond} / {seq_prompt} "
                    f"(rag_config={'on' if seq_rag_enabled else 'off'})"
                )
                try:
                    r = _run_with_timeout(
                        _run_task_for_condition,
                        task=t,
                        condition=seq_cond,
                        prompt_style=seq_prompt,
                        client=client,
                        experiment_number=experiment_number,
                        rag_enabled=seq_rag_enabled,
                        timeout_secs=0,  # Disable timeout for sequence runs (they are background tasks)
                    )
                    if r:
                        results.append(r)
                except Exception as exc:  # noqa: BLE001
                    print(
                        f"[Sequence] ERROR for reviewed task {task_id} / {seq_cond} / {seq_prompt}: {exc}"
                    )
                    traceback.print_exc()
                    continue

            compiled = sum(1 for r in results if r.get("compilation_success"))
            bleu_scores = [r.get("bleu_score") for r in results if r.get("bleu_score") is not None]
            avg_bleu = sum(bleu_scores) / len(bleu_scores) if bleu_scores else 0.0
            passed = sum(
                sum(1 for tc in r.get("st_test_results", []) if tc.get("passed"))
                for r in results
            )
            total = sum(len(r.get("st_test_results", [])) for r in results)

            print(f"\n{'='*70}")
            print(f"  CUSTOM TASK SEQUENCE COMPLETE")
            print(f"  Total runs : {len(results)}")
            print(f"  Compiled   : {compiled}/{len(results)}")
            print(f"  Tests      : {passed}/{total} passed")
            print(f"  Avg BLEU   : {avg_bleu:.3f}")
            print(f"{'='*70}")

            return {
                "all_tasks": False,
                "sequence_run": True,
                "task_id": task_id,
                "experiment_number": experiment_number,
                "task_count": 1,
                "count": len(results),
                "compiled": compiled,
                "tests_passed": passed,
                "tests_total": total,
                "avg_bleu": avg_bleu,
            }

        if condition == "direct_llm":
            return _run_with_timeout(
                _run_task_for_condition,
                task=t,
                condition="direct_llm",
                prompt_style=prompt_style,
                client=client,
                experiment_number=experiment_number,
                rag_enabled=rag_enabled,
                timeout_secs=0,  # No timeout; allow generation to complete naturally
            )
        return _run_with_timeout(
            _run_task_for_condition,
            task=t,
            condition="framework",
            prompt_style=prompt_style,
            client=client,
            experiment_number=experiment_number,
            rag_enabled=rag_enabled,
            timeout_secs=0,  # No timeout; allow generation to complete naturally
        )

    _stream_run(run_id, _execute)
    return jsonify({
        "ok": True,
        "run_id": run_id,
        "task_id": task_id,
        "experiment_number": experiment_number,
        "run_mode": run_mode,
        "force_provider": force_provider,
    })


@app.route("/tasks/run-custom", methods=["POST"])
def run_custom_task():
    """
    Accept a confirmed task spec, save it as a benchmark JSON, then
    run either single or full 6-combination sequence (SSE streamed).
    """
    data = request.get_json(force=True) or {}
    return _run_custom_task_from_payload(data)


@app.route("/tasks/run-custom-sequence", methods=["POST"])
def run_custom_task_sequence():
    """Backward-compatible alias that always runs the reviewed task in sequence mode."""
    data = request.get_json(force=True) or {}
    data["run_mode"] = "sequence"
    return _run_custom_task_from_payload(data)


# ─── Analysis Wizard ─────────────────────────────────────────────────────────

def _build_analysis_data(raw_logs=None) -> dict:
    """Shared data preparation for both analysis pages."""
    from collections import defaultdict
    from src.evaluator import load_all_logs, summarize_results

    if raw_logs is None:
        raw_logs = load_all_logs(str(config.EXPERIMENT_LOGS))
    summary  = summarize_results(raw_logs) if raw_logs else {}

    CONDITIONS  = ["framework", "direct_llm", "manual"]
    COMPLEXITIES = ["low", "medium", "high"]

    task_map: dict = defaultdict(lambda: defaultdict(list))
    for log in raw_logs:
        tid  = log.get("task_id", "unknown")
        cond = log.get("condition", "unknown")
        task_map[tid][cond].append(log)

    per_task: dict = {}
    for tid, cond_logs in task_map.items():
        per_task[tid] = {}
        for cond, entries in cond_logs.items():
            def _avg(key, ents=entries):
                vals = [e[key] for e in ents if e.get(key) is not None]
                return round(sum(vals) / len(vals), 4) if vals else None
            def _rate(key, ents=entries):
                vals = [e[key] for e in ents if e.get(key) is not None]
                return round(sum(bool(v) for v in vals) / len(vals), 4) if vals else None
            per_task[tid][cond] = {
                "compilation_success_rate":   _rate("compilation_success"),
                "avg_functional_correctness": _avg("functional_correctness_rate"),
                "avg_bleu_score":             _avg("bleu_score"),
                "avg_iterations":             _avg("iterations_needed"),
                "avg_hallucination_rate":     _avg("hallucination_rate"),
                "avg_statement_coverage":     _avg("statement_coverage"),
                "avg_semantic_equivalence":   _avg("semantic_equivalence_score"),
                "avg_dev_time_minutes":       _avg("dev_time_minutes"),
                "n":                          len(entries),
            }

    cplx_map: dict = defaultdict(lambda: defaultdict(list))
    for log in raw_logs:
        cplx = log.get("complexity") or "unknown"
        cond = log.get("condition", "unknown")
        cplx_map[cplx][cond].append(log)

    per_complexity: dict = {}
    for cplx, cond_logs in cplx_map.items():
        per_complexity[cplx] = {}
        for cond, entries in cond_logs.items():
            def _avg2(key, ents=entries):
                vals = [e[key] for e in ents if e.get(key) is not None]
                return round(sum(vals) / len(vals), 4) if vals else None
            def _rate2(key, ents=entries):
                vals = [e[key] for e in ents if e.get(key) is not None]
                return round(sum(bool(v) for v in vals) / len(vals), 4) if vals else None
            per_complexity[cplx][cond] = {
                "compilation_success_rate":   _rate2("compilation_success"),
                "avg_functional_correctness": _avg2("functional_correctness_rate"),
                "avg_bleu_score":             _avg2("bleu_score"),
                "avg_iterations":             _avg2("iterations_needed"),
                "avg_hallucination_rate":     _avg2("hallucination_rate"),
                "avg_statement_coverage":     _avg2("statement_coverage"),
                "avg_semantic_equivalence":   _avg2("semantic_equivalence_score"),
                "avg_dev_time_minutes":       _avg2("dev_time_minutes"),
                "n":                          len(entries),
            }

    raw_arrays: dict = {c: defaultdict(list) for c in CONDITIONS}
    BOX_METRICS = [
        "functional_correctness_rate", "bleu_score", "semantic_equivalence_score",
        "iterations_needed", "syntax_errors_initial", "hallucination_rate",
        "statement_coverage", "dev_time_minutes", "logical_inconsistencies",
    ]
    for log in raw_logs:
        cond = log.get("condition")
        if cond in raw_arrays:
            for m in BOX_METRICS:
                val = log.get(m)
                if val is not None:
                    raw_arrays[cond][m].append(val)

    raw_arrays_plain = {c: dict(v) for c, v in raw_arrays.items()}

    RAG_METRICS = [
        "functional_correctness_rate", "hallucination_rate",
        "statement_coverage", "bleu_score", "semantic_equivalence_score",
        "logical_inconsistencies", "iterations_needed", "syntax_errors_initial",
    ]
    rag_groups: dict = {"rag": defaultdict(list), "no_rag": defaultdict(list)}
    for log in raw_logs:
        bucket = "rag" if log.get("rag_used") else "no_rag"
        for m in RAG_METRICS:
            val = log.get(m)
            if val is not None:
                rag_groups[bucket][m].append(val)

    def _rag_avg(bucket, key):
        vals = rag_groups[bucket].get(key, [])
        return round(sum(vals) / len(vals), 4) if vals else None

    rag_comparison = {}
    for m in RAG_METRICS:
        with_rag    = _rag_avg("rag", m)
        without_rag = _rag_avg("no_rag", m)
        delta = round(with_rag - without_rag, 4) if (with_rag is not None and without_rag is not None) else None
        pct_change = round((delta / abs(without_rag)) * 100, 1) if (delta is not None and without_rag not in (None, 0)) else None
        rag_comparison[m] = {
            "with_rag": with_rag, "without_rag": without_rag,
            "delta": delta, "pct_change": pct_change,
        }

    rag_counts = {
        "rag":    sum(1 for l in raw_logs if l.get("rag_used") is True),
        "no_rag": sum(1 for l in raw_logs if l.get("rag_used") is False),
        "unknown": sum(1 for l in raw_logs if l.get("rag_used") is None),
    }

    return dict(
        summary=summary,
        per_task=per_task,
        per_complexity=per_complexity,
        raw_arrays=raw_arrays_plain,
        task_ids=sorted(per_task.keys()),
        complexity_list=[c for c in COMPLEXITIES if c in per_complexity],
        conditions=CONDITIONS,
        total_logs=len(raw_logs),
        rag_comparison=rag_comparison,
        rag_counts=rag_counts,
    )


@app.route("/analysis")
def analysis_page():
    """Rich analysis wizard with all thesis charts."""
    return render_template("analysis.html", **_build_analysis_data())


@app.route("/model-comparison")
def model_comparison_page():
    """LLM provider trial comparison — multi-model evaluation dashboard (§3.7)."""
    providers = [
        {
            "phase": 1,
            "name": "OpenAI GPT-4o-mini",
            "short": "GPT-4o-mini",
            "role": "Original Baseline",
            "role_color": "#f59e0b",
            "icon": "openai",
            "status": "Replaced",
            "status_color": "#dc2626",
            "params": "~8B (distilled)",
            "serving": "OpenAI API (cloud)",
            "throughput_tps": "~90",
            "quota": "Daily token cap (exhausted in 10-15 runs)",
            "syntax_compliance": "Moderate",
            "syntax_score": 55,
            "hallucination_rate": "~15–20% (informal)",
            "hallucination_score": 20,
            "medium_completeness": "Low — output truncation observed",
            "completeness_score": 30,
            "context_window": "128k input / 16k output",
            "bleu_low": None,
            "bleu_medium": "0.35–0.45",
            "fcr_low": None,
            "why_replaced": "Daily API quota exhausted in 10–15 runs; temporal confounding risk across multi-session campaign; output shortening on Medium-complexity tasks.",
            "observation": "Structurally coherent on Low tasks. Consistent output shortening on Medium tasks — omits secondary interlocks and timer blocks. Quota constraints make 180-run campaign infeasible without multi-week fragmentation.",
        },
        {
            "phase": 2,
            "name": "Ollama (Local Models)",
            "short": "Ollama 7–13B",
            "role": "Local / Privacy Option",
            "role_color": "#6366f1",
            "icon": "hdd",
            "status": "Excluded",
            "status_color": "#dc2626",
            "params": "7B – 13B (quantised GGUF)",
            "serving": "Local CPU (no GPU)",
            "throughput_tps": "2–4 tok/s (CPU only)",
            "quota": "Unlimited (local)",
            "syntax_compliance": "Low–Moderate (CodeLlama best)",
            "syntax_score": 30,
            "hallucination_rate": "~40–50% (manual inspection)",
            "hallucination_score": 50,
            "medium_completeness": "Very low",
            "completeness_score": 15,
            "context_window": "4k–8k (quantised)",
            "bleu_low": None,
            "bleu_medium": None,
            "fcr_low": None,
            "why_replaced": "2–4 tok/s on CPU → ~300–500h for 180-run campaign. Compilation failure >60% on all models. CodeLlama-13B reverts to Python-style syntax for IF/THEN blocks.",
            "observation": "llama3.1:8b: high hallucination (~40–50%), timer logic frequently wrong. codellama:13b: best syntax compliance of three but Python-style bleed. mistral:7b-instruct: valid ST template with placeholder logic. Scale threshold (70B+) not reachable without GPU.",
            "models_tested": ["llama3.1:8b", "codellama:13b", "mistral:7b-instruct"],
        },
        {
            "phase": 3,
            "name": "Groq — Llama 3.3 70B",
            "short": "Groq Llama 3.3 70B",
            "role": "Hot-Standby Fallback",
            "role_color": "#10b981",
            "icon": "lightning-charge",
            "status": "Retained as Fallback",
            "status_color": "#16a34a",
            "params": "70B",
            "serving": "Groq LPU (cloud)",
            "throughput_tps": "800–1,200 tok/s",
            "quota": "RPM/TPM limit — HTTP 429 after ~8–12 consecutive runs",
            "syntax_compliance": "High",
            "syntax_score": 82,
            "hallucination_rate": "Low (lower than GPT-4o-mini on Medium)",
            "hallucination_score": 12,
            "medium_completeness": "Moderate",
            "completeness_score": 65,
            "context_window": "128k",
            "bleu_low": None,
            "bleu_medium": None,
            "fcr_low": "0.75–0.85 (informal trial)",
            "why_replaced": "RPM/TPM limits cause HTTP 429 after ~8–12 sustained runs — insufficient for primary 90-run batches. Retained as auto-failover when Gemini returns 429.",
            "observation": "Markedly better than 7–13B local models. Correct IF/THEN/ELSIF, CASE/OF, TON/TOF syntax. Low hallucination on Medium tasks. Suitable for fallback (occasional requests) but not primary sustained generation.",
        },
        {
            "phase": 4,
            "name": "Google Gemini 2.5-Flash",
            "short": "Gemini 2.5-Flash",
            "role": "Primary (180-run campaign)",
            "role_color": "#2563eb",
            "icon": "stars",
            "status": "Selected — Primary",
            "status_color": "#2563eb",
            "params": "Large (undisclosed)",
            "serving": "Google AI API (cloud)",
            "throughput_tps": "~300–600 tok/s",
            "quota": "Generous tier — 180 runs in 3–4 days",
            "syntax_compliance": "High",
            "syntax_score": 88,
            "hallucination_rate": "6.5% (Framework), 36.4% (Direct LLM)",
            "hallucination_score": 7,
            "medium_completeness": "High",
            "completeness_score": 82,
            "context_window": "1M input / 65,536 output (configured)",
            "bleu_low": None,
            "bleu_medium": None,
            "fcr_low": "72.5% Framework / 60.3% Direct LLM",
            "why_replaced": None,
            "observation": "Selected after 15-run validation batch. thinking_budget=0 removed 8–15s latency overhead with no measurable quality loss on structured prompts. Consistent compliance with multi-part prompt directives (variable names, output-by-output planning, edge-case audit).",
            "config_notes": "thinking_budget=0, max_tokens=65536, temperature=0.2 (gen) / 0.1 (refinement), timeout=900s",
        },
    ]
    lessons = [
        {
            "icon": "layers",
            "color": "#2563eb",
            "title": "Model scale > domain specialisation for rare target languages",
            "body": "CodeLlama-13B (code-specialist) produced lower compilation rates than Llama 3.3 70B (general instruction model) on IEC 61131-3 ST. The 70B scale crosses a syntactic generalisation threshold that 7–13B models do not reliably achieve for underrepresented target languages.",
        },
        {
            "icon": "exclamation-triangle",
            "color": "#f59e0b",
            "title": "API quota is a first-class experimental design variable",
            "body": "Daily token quotas forced multi-session campaign execution with GPT-4o-mini. Any prompt fix or code change between sessions co-varies with model responses — a genuine confound. Quota headroom should be validated before randomising run order.",
        },
        {
            "icon": "plug",
            "color": "#10b981",
            "title": "OpenAI-compatible API enables zero-code provider switching",
            "body": "All four providers share the OpenAI REST interface. Switching from GPT-4o-mini to Gemini 2.5-flash required changing 3 config values and zero code changes — a design best practice for model-agnostic research infrastructure.",
        },
        {
            "icon": "gpu-card",
            "color": "#6366f1",
            "title": "Local inference requires GPU offloading for campaign-scale experiments",
            "body": "At CPU-only speeds (2–4 tok/s), local models are tractable for single-task demos but not statistical campaigns. Quantised GGUF models with GPU-layer offloading (RTX 3060 12GB target: ~30–80 tok/s) are the minimum viable configuration.",
        },
        {
            "icon": "stopwatch",
            "color": "#dc2626",
            "title": "Extended thinking budget is redundant on structured prompts",
            "body": "Gemini 2.5-flash thinking_budget=1024 added 8–15s latency per task with no measurable FCR or compilation rate improvement on Standard and PoT conditions. The reasoning scaffold in PoT prompts makes internal CoT redundant. Setting thinking_budget=0 improved total throughput by ~25%.",
        },
    ]
    return render_template("model_comparison.html", providers=providers, lessons=lessons)






@app.route("/api/system/restart", methods=["POST"])
def api_system_restart():
    """Restart the current Flask app process after sending the response."""
    pid = os.getpid()
    python_exe = sys.executable
    argv = [python_exe] + sys.argv

    @after_this_request
    def _restart(response):
        def _worker():
            time.sleep(0.7)
            try:
                if os.name == "nt":
                    import subprocess as _sp
                    _sp.Popen(argv, creationflags=getattr(_sp, "CREATE_NEW_PROCESS_GROUP", 0))
                else:
                    os.execv(python_exe, argv)
            finally:
                os._exit(0)

        threading.Thread(target=_worker, daemon=True).start()
        return response

    return jsonify({"ok": True, "message": f"Restarting app (pid {pid})"})


# ─── Entry Point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Ensure output dirs exist
    config.GENERATED_CODE.mkdir(parents=True, exist_ok=True)
    config.TRANSLATED_CODE.mkdir(parents=True, exist_ok=True)
    config.EXPERIMENT_LOGS.mkdir(parents=True, exist_ok=True)
    print("\n  PLC Research UI running at: http://localhost:5000\n")
    app.run(debug=True, threaded=True, use_reloader=True)
