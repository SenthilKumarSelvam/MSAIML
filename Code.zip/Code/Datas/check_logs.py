import json, os, glob

logs_dir = "results/experiment_logs"
files = sorted(glob.glob(f"{logs_dir}/*.json"), key=os.path.getmtime, reverse=True)[:10]

print(f"{'Condition':<40} {'FC':>6} {'HR':>6} {'Cov':>6} {'LD':>6} {'SE':>6}")
print("-" * 80)
for f in files:
    d = json.load(open(f))
    name = f"{d.get('condition','?')}_{d.get('prompt_style','?')}"[:38]
    fc   = d.get('functional_correctness_rate')
    hr   = d.get('hallucination_rate')
    cov  = d.get('statement_coverage')
    ld   = d.get('ld_compilation_success')
    se   = d.get('semantic_equivalence_score')
    print(f"{name:<40} {str(fc):>6} {str(hr):>6} {str(cov):>6} {str(ld):>6} {str(se):>6}")
