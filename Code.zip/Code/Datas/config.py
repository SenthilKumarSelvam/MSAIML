"""
Configuration — load environment variables and set project-wide defaults.
Copy .env.example to .env and fill in your values before running.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env from project root and let project settings override ambient OS env vars.
load_dotenv(Path(__file__).resolve().parent / ".env", override=True)


# ─── OpenAI ──────────────────────────────────────────────────────────────────
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
LLM_MODEL:      str = os.getenv("LLM_MODEL", "gpt-4o-mini")
# Network resilience for LLM requests.
# Timeout for LLM API calls. Gemini can be slow (>5min for complex tasks), so set high.
LLM_REQUEST_TIMEOUT_SECONDS: float = float(os.getenv("LLM_REQUEST_TIMEOUT_SECONDS", "900"))
LLM_MAX_RETRIES:            int   = int(os.getenv("LLM_MAX_RETRIES", "4"))
# Upper/lower bounds for generation phase output size.
# Gemini 2.5-pro is a "thinking" model whose internal reasoning consumes output
# tokens.  3072 is far too low — the model spends it all on thinking and returns
# content=None.  65536 is Gemini 2.5-pro's max; cost is based on tokens actually
# generated, not this ceiling.
LLM_GENERATION_MAX_TOKENS:  int   = int(os.getenv("LLM_GENERATION_MAX_TOKENS", "65536"))
LLM_GENERATION_MIN_TOKENS:  int   = int(os.getenv("LLM_GENERATION_MIN_TOKENS", "512"))
# Set MOCK_LLM=true in .env to run the full pipeline without spending API credits.
# Generated code will be a deterministic stub derived from the task requirements.
MOCK_LLM:       bool = os.getenv("MOCK_LLM", "false").lower() in ("1", "true", "yes")

# ─── Ollama (local OpenAI-compatible endpoint) ──────────────────────────────
# Set LLM_PROVIDER=ollama to run locally.
# Default base URL follows Ollama's OpenAI-compatible endpoint.
# Example models: llama3.1:8b, mistral, qwen2.5:7b-instruct
OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
OLLAMA_API_KEY:  str = os.getenv("OLLAMA_API_KEY", "ollama")
OLLAMA_MODEL:    str = os.getenv("OLLAMA_MODEL", "llama3.1:8b")

# ─── Google Gemini (free-tier fallback) ──────────────────────────────────────
# Set LLM_PROVIDER=gemini and add GEMINI_API_KEY to use Gemini instead of OpenAI.
# Free key: https://aistudio.google.com/apikey
GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL:   str = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
# LLM_PROVIDER: "openai" | "gemini" | "ollama" | "auto"
# auto picks openai when key exists, else ollama when local endpoint configured,
# else gemini when key exists.
LLM_PROVIDER:   str = os.getenv("LLM_PROVIDER", "auto")

# ─── Generic OpenAI-compatible providers (Groq, OpenRouter, DeepSeek, …) ─────
# Any provider that speaks the OpenAI API can be used by setting LLM_PROVIDER to
# one of the names below (or "custom") and providing a key. Fast + free option:
#   Groq  →  https://console.groq.com/keys   (no credit card, very fast)
# .env example for Groq:
#   LLM_PROVIDER=groq
#   LLM_API_KEY=gsk_...                 (or reuse OPENAI_API_KEY)
#   LLM_MODEL=llama-3.3-70b-versatile   (optional; sensible default applied)
# For "custom" set LLM_BASE_URL to any OpenAI-compatible endpoint.
LLM_BASE_URL: str = os.getenv("LLM_BASE_URL", "")
LLM_API_KEY:  str = os.getenv("LLM_API_KEY", "")

# name → (default base_url, default model)
_OPENAI_COMPAT_DEFAULTS: dict[str, tuple[str, str]] = {
    "groq":       ("https://api.groq.com/openai/v1",   "llama-3.3-70b-versatile"),
    "openrouter": ("https://openrouter.ai/api/v1",     "meta-llama/llama-3.3-70b-instruct"),
    "deepseek":   ("https://api.deepseek.com",          "deepseek-chat"),
    "together":   ("https://api.together.xyz/v1",       "meta-llama/Llama-3.3-70B-Instruct-Turbo"),
    "cerebras":   ("https://api.cerebras.ai/v1",        "llama-3.3-70b"),
    "custom":     ("",                                   ""),
    "openai_compatible": ("",                            ""),
}

OPENAI_COMPATIBLE_PROVIDERS = set(_OPENAI_COMPAT_DEFAULTS.keys())


def openai_compatible_config() -> tuple[str, str, str]:
    """Resolve (base_url, api_key, model) for the active OpenAI-compatible provider.

    base_url: LLM_BASE_URL overrides the provider default.
    api_key:  LLM_API_KEY, falling back to OPENAI_API_KEY.
    model:    LLM_MODEL unless it is still the OpenAI default ('gpt-4o-mini'),
              in which case the provider's recommended model is used.
    """
    p = LLM_PROVIDER.lower()
    default_base, default_model = _OPENAI_COMPAT_DEFAULTS.get(p, ("", ""))
    base_url = LLM_BASE_URL or default_base
    api_key = LLM_API_KEY or OPENAI_API_KEY
    model = LLM_MODEL if (LLM_MODEL and LLM_MODEL != "gpt-4o-mini") else (default_model or LLM_MODEL)
    return base_url, api_key, model

def active_provider() -> str:
    """Return active provider: 'openai' | 'gemini' | 'ollama' | 'openai_compatible' | 'mock'."""
    if MOCK_LLM:
        return "mock"
    p = LLM_PROVIDER.lower()
    if p in OPENAI_COMPATIBLE_PROVIDERS:
        return "openai_compatible"
    if p == "bedrock":
        return "bedrock"
    if p == "gemini":
        return "gemini"
    if p == "openai":
        return "openai"
    if p == "ollama":
        return "ollama"
    # auto: prefer openai, then ollama, then gemini
    if OPENAI_API_KEY:
        return "openai"
    if OLLAMA_BASE_URL:
        return "ollama"
    if GEMINI_API_KEY:
        return "gemini"
    return "openai"

# ─── AWS Bedrock ────────────────────────────────────────────────────────────
# Set LLM_PROVIDER=bedrock and add AWS credentials to use Claude via Bedrock.
AWS_ACCESS_KEY_ID:     str = os.getenv("AWS_ACCESS_KEY_ID", "")
AWS_SECRET_ACCESS_KEY: str = os.getenv("AWS_SECRET_ACCESS_KEY", "")
# Required ONLY for temporary credentials (access keys starting with 'ASIA',
# e.g. AWS Academy / Educate / SSO). These expire every few hours.
AWS_SESSION_TOKEN:     str = os.getenv("AWS_SESSION_TOKEN", "")
AWS_REGION:            str = os.getenv("AWS_REGION", "us-east-1")
BEDROCK_MODEL:         str = os.getenv("BEDROCK_MODEL", "anthropic.claude-3-haiku-20240307-v1:0")

# ─── Compiler ────────────────────────────────────────────────────────────────
# Path to the matiec/OpenPLC compiler binary.
# On Windows, use the full path e.g. "C:/OpenPLC/matiec/iec2c.exe"
COMPILER_PATH: str = os.getenv("COMPILER_PATH", "matiec")

# ─── Framework Defaults ──────────────────────────────────────────────────────
MAX_REFINEMENT_ITERATIONS:  int = int(os.getenv("MAX_ITERATIONS",          "3"))  # 3 is sufficient for most compiler errors; was 5
MAX_SEMANTIC_ITERATIONS:    int = int(os.getenv("MAX_SEMANTIC_ITERATIONS", "5"))  # Agent 2 logic-fix loop; increased from 2→5 for better pass rates
# Per-task wall-clock timeout (seconds). If a single task+condition run exceeds
# this, it is skipped and the pipeline continues. 0 = no timeout.
# DISABLED globally (set to 0) to allow generation to complete naturally.
TASK_TIMEOUT_SECONDS: int = int(os.getenv("TASK_TIMEOUT_SECONDS", "0"))
PROMPT_STYLE: str = os.getenv("PROMPT_STYLE", "standard")  # standard | chain_of_thought | program_of_thought

# ─── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR         = Path(__file__).resolve().parent
BENCHMARK_DIR    = BASE_DIR / "data" / "benchmark_tasks"
RAW_REQ_DIR      = BASE_DIR / "data" / "raw_requirements"
NORM_REQ_DIR     = BASE_DIR / "data" / "normalized_requirements"
RESULTS_DIR      = BASE_DIR / "results"
EXPERIMENT_LOGS  = RESULTS_DIR / "experiment_logs"
GENERATED_CODE   = RESULTS_DIR / "generated_code"
TRANSLATED_CODE  = RESULTS_DIR / "translated_code"

# ─── RAG ─────────────────────────────────────────────────────────────────────
# Set RAG_ENABLED=false to disable retrieval-augmented generation.
RAG_ENABLED:  bool = os.getenv("RAG_ENABLED", "true").lower() in ("1", "true", "yes")
RAG_TOP_K:    int  = int(os.getenv("RAG_TOP_K", "2"))   # retrieved examples per query
RAG_STORE_DIR = BASE_DIR / "data" / "rag_store"


def validate_config(provider: str | None = None) -> None:
    """Raise an error if required configuration is missing.

    ``provider`` overrides the auto-detected provider for validation only
    (used by the one-run Ollama fallback when Gemini quota is exhausted).
    """
    if MOCK_LLM:
        return  # No API key needed in mock mode
    provider = (provider or active_provider()).lower()
    if provider == "ollama":
        if not OLLAMA_BASE_URL:
            raise EnvironmentError("OLLAMA_BASE_URL is not set. Add it to .env.")
        if not OLLAMA_MODEL:
            raise EnvironmentError("OLLAMA_MODEL is not set. Add it to .env.")
        return
    if provider == "bedrock":
        if not AWS_ACCESS_KEY_ID or not AWS_SECRET_ACCESS_KEY:
            raise EnvironmentError(
                "AWS credentials are not set for provider 'bedrock'. "
                "Add AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY to .env."
            )
        if not BEDROCK_MODEL:
            raise EnvironmentError("BEDROCK_MODEL is not set. Add it to .env.")
        return
    if provider == "gemini" and not GEMINI_API_KEY:
        raise EnvironmentError("GEMINI_API_KEY is not set. Add it to .env.")
    if provider == "openai_compatible":
        base_url, api_key, _model = openai_compatible_config()
        if not base_url:
            raise EnvironmentError(
                f"LLM_BASE_URL is not set for provider '{LLM_PROVIDER}'. "
                "Add LLM_BASE_URL (OpenAI-compatible endpoint) to .env."
            )
        if not api_key:
            raise EnvironmentError(
                f"No API key for provider '{LLM_PROVIDER}'. Set LLM_API_KEY in .env."
            )
        return
    if provider == "openai" and not OPENAI_API_KEY:
        raise EnvironmentError(
            "OPENAI_API_KEY is not set. Create a .env file from .env.example."
        )
