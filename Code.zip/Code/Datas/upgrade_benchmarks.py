"""
Upgrade benchmark task specs to "Task Builder" quality.

For each benchmark JSON, this re-analyzes the `raw_requirement` through the
SAME LLM analyzer the LLM Task Builder uses (prompts/analyze_requirement.txt
on the active provider) and refreshes `normalized_requirement`.

What it CHANGES:
  - normalized_requirement (system_name, description, inputs, outputs,
    internal_variables, control_conditions, safety_constraints, complexity)

What it PRESERVES (evaluation ground truth — never LLM-regenerated):
  - test_cases
  - reference_st_code
  - task_id, scenario

Backups of every modified file are written to a timestamped folder before
anything is overwritten.

Usage:
    python upgrade_benchmarks.py                  # upgrade all tasks
    python upgrade_benchmarks.py motor_control_low conveyor_medium
    python upgrade_benchmarks.py --dry-run        # show diffs, write nothing
"""

import json
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

import config
import httpx
import openai


PROMPT_PATH = config.BASE_DIR / "prompts" / "analyze_requirement.txt"


def _analyze_requirement(raw_req: str) -> dict:
    """Run the raw requirement through the active LLM analyzer; return parsed JSON."""
    prompt_tmpl = PROMPT_PATH.read_text(encoding="utf-8")
    prompt_text = prompt_tmpl.format(requirement=raw_req)
    provider = config.active_provider()
    system_msg = ("You are an expert IEC 61131-3 PLC requirements analyst. "
                  "Respond ONLY with valid JSON.")

    if provider == "ollama":
        client = openai.OpenAI(
            base_url=config.OLLAMA_BASE_URL,
            api_key=config.OLLAMA_API_KEY,
            http_client=httpx.Client(timeout=config.LLM_REQUEST_TIMEOUT_SECONDS),
        )
        resp = client.chat.completions.create(
            model=config.OLLAMA_MODEL,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt_text},
            ],
            temperature=0.1,
        )
        return json.loads(resp.choices[0].message.content.strip())

    if provider == "gemini":
        from google import genai
        gclient = genai.Client(api_key=config.GEMINI_API_KEY)
        resp = gclient.models.generate_content(
            model=config.GEMINI_MODEL,
            contents=f"{system_msg}\n\n{prompt_text}",
        )
        text = resp.text.strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.lstrip().lower().startswith("json"):
                text = text.lstrip()[4:]
        return json.loads(text.strip())

    # openai (default)
    client = openai.OpenAI(api_key=config.OPENAI_API_KEY)
    resp = client.chat.completions.create(
        model=config.LLM_MODEL,
        messages=[
            {"role": "system", "content": system_msg},
            {"role": "user", "content": prompt_text},
        ],
        temperature=0.1,
        response_format={"type": "json_object"},
    )
    return json.loads(resp.choices[0].message.content.strip())


def _to_normalized_requirement(analysis: dict, fallback_complexity: str) -> dict:
    """Map analyzer output schema into the benchmark normalized_requirement shape."""
    return {
        "system_name":        analysis.get("system_name", "System"),
        "description":        analysis.get("description", ""),
        "inputs":             analysis.get("inputs", []),
        "outputs":            analysis.get("outputs", []),
        "internal_variables": analysis.get("internal_variables", []),
        "control_conditions": analysis.get("control_conditions", []),
        "safety_constraints": analysis.get("interlocks", []),
        "complexity":         analysis.get("complexity", fallback_complexity),
    }


def upgrade_task(path: Path, backup_dir: Path, dry_run: bool) -> bool:
    """Re-analyze one task. Returns True if changed."""
    task = json.loads(path.read_text(encoding="utf-8"))
    raw_req = task.get("raw_requirement", "").strip()
    if not raw_req:
        print(f"  [skip] {path.stem}: no raw_requirement to analyze.")
        return False

    print(f"  [analyze] {path.stem} ...")
    try:
        analysis = _analyze_requirement(raw_req)
    except Exception as exc:  # noqa: BLE001
        print(f"  [error] {path.stem}: analysis failed ({exc}) — left unchanged.")
        return False

    new_norm = _to_normalized_requirement(
        analysis, task.get("complexity", "low")
    )

    old_norm = task.get("normalized_requirement", {})
    if new_norm == old_norm:
        print(f"  [unchanged] {path.stem}: analyzer produced identical spec.")
        return False

    # Preserve ground truth: test_cases, reference_st_code, task_id, scenario
    task["normalized_requirement"] = new_norm
    # keep top-level complexity in sync with refreshed spec
    task["complexity"] = new_norm.get("complexity", task.get("complexity", "low"))

    if dry_run:
        old_outs = [v.get("name") for v in old_norm.get("outputs", [])]
        new_outs = [v.get("name") for v in new_norm.get("outputs", [])]
        print(f"  [dry-run] {path.stem}: outputs {old_outs} -> {new_outs}")
        return True

    # Backup then write
    backup_dir.mkdir(parents=True, exist_ok=True)
    (backup_dir / path.name).write_text(
        path.read_text(encoding="utf-8"), encoding="utf-8"
    )
    path.write_text(
        json.dumps(task, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"  [upgraded] {path.stem}  (backup saved)")
    return True


def main(argv: list[str]) -> None:
    dry_run = "--dry-run" in argv
    names = [a for a in argv if not a.startswith("--")]

    if names:
        paths = [config.BENCHMARK_DIR / f"{n}.json" for n in names]
        paths = [p for p in paths if p.exists()]
    else:
        paths = sorted(config.BENCHMARK_DIR.glob("*.json"))

    if not paths:
        print("No benchmark task files found.")
        return

    provider = config.active_provider()
    backup_dir = config.BENCHMARK_DIR / f"_backup_{int(time.time())}"

    print(f"Upgrading {len(paths)} benchmark task(s) via provider: {provider}")
    if dry_run:
        print("DRY RUN — no files will be written.\n")

    changed = 0
    for p in paths:
        if upgrade_task(p, backup_dir, dry_run):
            changed += 1

    print(f"\nDone. {changed}/{len(paths)} task(s) "
          f"{'would change' if dry_run else 'upgraded'}.")
    if changed and not dry_run:
        print(f"Backups: {backup_dir}")


if __name__ == "__main__":
    main(sys.argv[1:])
