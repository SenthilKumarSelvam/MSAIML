import json, pathlib
from collections import defaultdict
logs = sorted(pathlib.Path('results/experiment_logs').glob('*.json'))
model_agg = defaultdict(lambda: {'count':0,'compile':0,'fc_sum':0,'iters':0,'dev':0,'refine':0,'hr_sum':0,'cov_sum':0})
for lf in logs:
    if lf.name.startswith('_'): continue
    try:
        d = json.loads(lf.read_text(encoding='utf-8'))
    except: continue
    m = d.get('model_used','unknown')
    model_agg[m]['count'] += 1
    if d.get('compilation_success'): model_agg[m]['compile'] += 1
    model_agg[m]['fc_sum'] += d.get('functional_correctness_rate',0) or 0
    model_agg[m]['iters'] += d.get('iterations_needed',0) or 0
    model_agg[m]['dev'] += d.get('dev_time_minutes',0) or 0
    model_agg[m]['refine'] += d.get('semantic_refinement_iterations',0) or 0
    model_agg[m]['hr_sum'] += d.get('hallucination_rate',0) or 0
    model_agg[m]['cov_sum'] += d.get('statement_coverage',0) or 0

for m, s in sorted(model_agg.items(), key=lambda x:-x[1]['count']):
    n = s['count']
    cpct = round(s['compile']/n*100, 1)
    fc = round(s['fc_sum']/n*100, 1)
    hr = round(s['hr_sum']/n*100, 1)
    cov = round(s['cov_sum']/n*100, 1)
    it = round(s['iters']/n, 2)
    dv = round(s['dev']/n, 2)
    ref = round(s['refine']/n, 2)
    print(f"{m}: runs={n} compile={cpct}% fc={fc}% hr={hr}% cov={cov}% iter={it} dev={dv}min refine={ref}")
