"""
RQ4 + RQ5 Support: Expert Review & Manual Metrics Entry Tool
Interactive CLI for engineers to review LLM-generated PLC code and
record trust/quality ratings, corrections, and efficiency metrics.

Usage:
    python review_tool.py                    # review all pending logs
    python review_tool.py --log <path.json>  # review a specific log
    python review_tool.py --list             # list pending logs
"""

import argparse
import json
import os
import random
import sys
import time
from pathlib import Path

import config


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _load_log(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _save_log(log: dict, path: Path) -> None:
    path.write_text(json.dumps(log, indent=2), encoding="utf-8")


def _ask_int(prompt: str, lo: int, hi: int, allow_skip: bool = False) -> int | None:
    while True:
        raw = input(f"  {prompt} [{lo}-{hi}]{' (Enter to skip)' if allow_skip else ''}: ").strip()
        if allow_skip and raw == "":
            return None
        try:
            val = int(raw)
            if lo <= val <= hi:
                return val
            print(f"  Please enter a number between {lo} and {hi}.")
        except ValueError:
            print("  Please enter a whole number.")


def _ask_float(prompt: str, lo: float = 0.0, allow_skip: bool = False) -> float | None:
    while True:
        raw = input(f"  {prompt} (Enter to skip): ").strip() if allow_skip \
              else input(f"  {prompt}: ").strip()
        if allow_skip and raw == "":
            return None
        try:
            val = float(raw)
            if val >= lo:
                return val
            print(f"  Please enter a value >= {lo}.")
        except ValueError:
            print("  Please enter a number.")


def _ask_yn(prompt: str) -> bool:
    while True:
        raw = input(f"  {prompt} (y/n): ").strip().lower()
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print("  Please enter y or n.")


def _separator(char: str = "─", width: int = 60) -> str:
    return char * width


def _find_generated_code(log: dict) -> str | None:
    """Try to locate the generated .st file for this log entry."""
    task_id      = log.get("task_id", "")
    prompt_style = "standard"   # fallback
    code_dir     = config.GENERATED_CODE
    # Try common patterns
    for suffix in ["standard", "chain_of_thought", "program_of_thought"]:
        candidate = code_dir / f"{task_id}_{suffix}.st"
        if candidate.exists():
            return candidate.read_text(encoding="utf-8")
    return None


# ─── Pending Log Discovery ────────────────────────────────────────────────────

def _is_pending(log: dict) -> bool:
    """A log needs review if any RQ5 field is still None."""
    rq5_fields = [
        "expert_rating_correctness",
        "expert_rating_maintainability",
        "expert_rating_safety",
        "expert_rating_iec_adherence",
        "accepted_without_correction",
        "review_time_minutes",
        "escalated_for_review",
    ]
    return any(log.get(f) is None for f in rq5_fields)


def list_pending_logs() -> list[Path]:
    log_dir = config.EXPERIMENT_LOGS
    pending = []
    for p in sorted(log_dir.glob("*.json")):
        try:
            log = _load_log(p)
            if _is_pending(log):
                pending.append(p)
        except Exception:
            pass
    return pending


# ─── Review Session ───────────────────────────────────────────────────────────

def review_log(log_path: Path) -> None:
    log = _load_log(log_path)
    task_id   = log.get("task_id", "?")
    condition = log.get("condition", "?")
    complexity = log.get("complexity", "?")

    print(f"\n{'='*60}")
    print(f"  Review: {task_id}  |  {condition}  |  {complexity}")
    print(f"  Log   : {log_path.name}")
    print(_separator())
    print(f"  Compiled     : {log.get('compilation_success')}")
    print(f"  Iterations   : {log.get('iterations_needed')}")
    print(f"  BLEU Score   : {log.get('bleu_score')}")
    print(f"  Dev Time     : {log.get('dev_time_minutes')} min")
    print(_separator())

    # Show generated code
    code = _find_generated_code(log)
    if code:
        print("\n--- Generated ST Code ---")
        print(code)
        print(_separator())
    else:
        print("  [Generated code file not found — check results/generated_code/]")

    # ── RQ5: Expert Ratings ───────────────────────────────────────────────────
    print("\n[RQ5] Expert Quality Ratings (1 = poor, 10 = excellent)\n")
    start_time = time.time()

    log["expert_rating_correctness"]      = _ask_int("Functional correctness", 1, 10)
    log["expert_rating_maintainability"]  = _ask_int("Code maintainability / readability", 1, 10)
    log["expert_rating_safety"]           = _ask_int("Safety compliance", 1, 10)
    log["expert_rating_iec_adherence"]    = _ask_int("IEC 61131-3 standards adherence", 1, 10)

    log["accepted_without_correction"]    = _ask_yn("\nWould you accept this code for deployment WITHOUT manual correction?")
    log["escalated_for_review"]           = _ask_yn("Would you escalate this for further review due to insufficient confidence?")

    elapsed = round((time.time() - start_time) / 60.0, 3)
    log["review_time_minutes"] = elapsed
    print(f"\n  Review time recorded: {elapsed} min")

    # ── RQ4: Manual Corrections & Efficiency ──────────────────────────────────
    print("\n[RQ4] Development Efficiency Metrics\n")
    corrections = _ask_int("How many manual corrections did you make to this program?", 0, 100)
    log["manual_corrections_count"] = corrections

    if corrections and corrections > 0:
        corr_time = _ask_float("Time spent on manual corrections (minutes)", lo=0.0, allow_skip=True)
        log["manual_corrections_time_min"] = corr_time

    budget = _ask_yn("\nWas this task completed within a 30-minute budget?")
    log["task_completed_in_budget"] = budget

    # NASA-TLX
    print("\n[RQ4] NASA Task Load Index (cognitive load)\n")
    print("  Rate your overall cognitive workload for this review task:")
    print("  Consider: mental demand, physical demand, time pressure,")
    print("  performance, effort, and frustration combined.")
    nasa = _ask_int("Overall NASA-TLX score", 0, 100, allow_skip=True)
    log["nasa_tlx_score"] = nasa

    # ── RQ2: Corrections for normalisation condition ───────────────────────────
    if condition == "framework":
        print("\n[RQ2] Requirement Normalisation Quality\n")
        func_rate = _ask_float(
            "Functional correctness rate (0.0–1.0) based on your manual test evaluation",
            lo=0.0, allow_skip=True
        )
        if func_rate is not None:
            func_rate = min(1.0, func_rate)
        log["functional_correctness_rate"] = func_rate

    # ── Notes ──────────────────────────────────────────────────────────────────
    note = input("\n  Any free-text notes for this review (Enter to skip): ").strip()
    if note:
        existing = log.get("notes", "")
        log["notes"] = (existing + " | " + note).strip(" | ") if existing else note

    # ── Save ───────────────────────────────────────────────────────────────────
    _save_log(log, log_path)
    print(f"\n  ✓ Review saved → {log_path.name}\n")


# ─── Batch Review Mode ────────────────────────────────────────────────────────

def run_batch_review(log_paths: list[Path]) -> None:
    total = len(log_paths)
    if total == 0:
        print("\nNo pending reviews found in results/experiment_logs/")
        print("Run main.py first to generate experiment logs.\n")
        return

    print(f"\nFound {total} log(s) pending expert review.")
    for i, p in enumerate(log_paths, 1):
        print(f"  {i}. {p.name}")

    print()
    proceed = input("Start reviewing? (y/n): ").strip().lower()
    if proceed != "y":
        print("Review cancelled.")
        return

    reviewed = 0
    for i, p in enumerate(log_paths, 1):
        print(f"\n[{i}/{total}]", end="")
        review_log(p)
        reviewed += 1

        if i < total:
            cont = input("Continue to next log? (y/n): ").strip().lower()
            if cont != "y":
                break

    print(f"\n✓ Reviewed {reviewed}/{total} logs.")


# ─── Blinded Review Mode (RQ5) ───────────────────────────────────────────────

def run_blinded_review(log_paths: list[Path]) -> None:
    """
    Blinded review session for RQ5 validity.
    Engineers see only the generated code and an anonymous ID —
    the condition (framework / direct_llm / manual) is hidden.
    A mapping file is saved separately and revealed at the end via --reveal.
    """
    if not log_paths:
        print("\nNo pending reviews found.")
        return

    # Shuffle to prevent order bias
    shuffled = log_paths[:]
    random.shuffle(shuffled)

    # Build anonymous mapping
    mapping = {}
    for i, p in enumerate(shuffled, 1):
        anon_id = f"REVIEW_{i:03d}"
        mapping[anon_id] = str(p)

    # Save mapping to a hidden file in experiment_logs dir
    mapping_path = config.EXPERIMENT_LOGS / "_blinded_mapping.json"
    mapping_path.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
    print(f"\n[Blinded] Mapping saved (do not open until all reviews are done): {mapping_path}")
    print(f"[Blinded] {len(shuffled)} anonymous program(s) to review.\n")

    proceed = input("Start blinded review? (y/n): ").strip().lower()
    if proceed != "y":
        print("Blinded review cancelled.")
        return

    reviewed = 0
    for anon_id, log_path_str in mapping.items():
        log_path = Path(log_path_str)
        log = _load_log(log_path)

        print(f"\n{'='*60}")
        print(f"  Program ID : {anon_id}  (condition and task are hidden)")
        print(_separator())

        # Show only the code — no task_id, condition, or complexity
        code = _find_generated_code(log)
        if code:
            print("\n--- Program Code ---")
            print(code)
            print(_separator())
        else:
            print("  [Code file not found — review based on available information]")

        # ── RQ5 ratings ───────────────────────────────────────────────────────
        print("\n[RQ5] Expert Quality Ratings (1 = poor, 10 = excellent)\n")
        start_time = time.time()

        log["expert_rating_correctness"]     = _ask_int("Functional correctness", 1, 10)
        log["expert_rating_maintainability"] = _ask_int("Code maintainability / readability", 1, 10)
        log["expert_rating_safety"]          = _ask_int("Safety compliance", 1, 10)
        log["expert_rating_iec_adherence"]   = _ask_int("IEC 61131-3 standards adherence", 1, 10)

        log["accepted_without_correction"] = _ask_yn("\nAccept for deployment WITHOUT manual correction?")
        log["escalated_for_review"]        = _ask_yn("Escalate for further review due to insufficient confidence?")

        elapsed = round((time.time() - start_time) / 60.0, 3)
        log["review_time_minutes"] = elapsed
        print(f"\n  Review time: {elapsed} min")

        note = input("  Free-text notes (Enter to skip): ").strip()
        if note:
            existing = log.get("notes", "")
            log["notes"] = (existing + " | BLINDED: " + note).strip(" | ")

        _save_log(log, log_path)
        reviewed += 1
        print(f"  ✓ {anon_id} saved.")

        if reviewed < len(mapping):
            cont = input("\nContinue to next program? (y/n): ").strip().lower()
            if cont != "y":
                break

    print(f"\n✓ Blinded review complete ({reviewed}/{len(mapping)}).")
    print(f"  Run  python review_tool.py --reveal  to see the condition mapping.\n")


def reveal_blinded_mapping() -> None:
    """Print the blinded review mapping (anon ID → condition + task)."""
    mapping_path = config.EXPERIMENT_LOGS / "_blinded_mapping.json"
    if not mapping_path.exists():
        print("No blinded mapping file found. Run a blinded review session first.")
        return
    mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
    print(f"\n{'='*60}")
    print("  Blinded Review Mapping")
    print(_separator())
    for anon_id, log_path_str in mapping.items():
        try:
            log = _load_log(Path(log_path_str))
            print(f"  {anon_id}  →  task={log['task_id']}  condition={log['condition']}")
        except Exception:
            print(f"  {anon_id}  →  {log_path_str} (could not load)")
    print()


# ─── Entry Point ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Expert Review & Manual Metrics Entry Tool"
    )
    parser.add_argument("--log",     type=str,  help="Path to a specific log JSON to review")
    parser.add_argument("--list",    action="store_true", help="List all pending review logs")
    parser.add_argument("--blinded", action="store_true", help="Run blinded review (hides task/condition)")
    parser.add_argument("--reveal",  action="store_true", help="Reveal the blinded condition mapping")
    args = parser.parse_args()

    if args.reveal:
        reveal_blinded_mapping()
        return

    if args.list:
        pending = list_pending_logs()
        if not pending:
            print("No pending reviews.")
        else:
            print(f"\n{len(pending)} log(s) pending review:")
            for p in pending:
                print(f"  • {p.name}")
        return

    if args.log:
        p = Path(args.log)
        if not p.exists():
            p = config.EXPERIMENT_LOGS / args.log
        if not p.exists():
            print(f"Log file not found: {args.log}")
            sys.exit(1)
        review_log(p)
        return

    pending = list_pending_logs()
    if args.blinded:
        run_blinded_review(pending)
    else:
        run_batch_review(pending)


if __name__ == "__main__":
    main()
