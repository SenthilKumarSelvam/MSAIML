﻿"""
Cross-Language Mapper: Structured Text (ST) -> Ladder Diagram (LD) / Function Block Diagram (FBD)
Rule-based translation of IEC 61131-3 ST programs into LD and FBD XML representations
fully compliant with PLCopen TC6 XML / IEC 61131-10 schema (importable by edge.autonomylogic.com,
OpenPLC Editor, CODESYS and Beremiz).
"""

import re
from datetime import datetime
from pathlib import Path

_NOW = "2026-01-01T00:00:00"  # deterministic timestamp for reproducibility


# --- ST Parser ---

_COMPARE_RE = re.compile(r'[<>]=?|<>')


def _extract_if_blocks(text):
    """
    Extract top-level IF/ELSIF/ELSE/END_IF blocks from *text* using depth
    counting so that nested IFs don't confuse the parser.

    Returns a list of dicts:
        {
          'start': int, 'end': int,
          'cond': str,           # the IF condition
          'then_body': str,
          'elsif_clauses': [(cond_str, body_str), ...],
          'else_body': str | None
        }
    """
    results = []
    i = 0
    while i < len(text):
        m = re.search(r'\bIF\b', text[i:], re.IGNORECASE)
        if not m:
            break
        if_abs   = i + m.start()
        after_if = i + m.end()

        then_m = re.search(r'\bTHEN\b', text[after_if:], re.IGNORECASE)
        if not then_m:
            i = after_if
            continue

        cond        = text[after_if: after_if + then_m.start()].strip()
        body_start  = after_if + then_m.end()

        # Walk forward counting IF/END_IF depth; collect ELSIF/ELSE positions at depth==1
        depth = 1
        j     = body_start
        clauses        = []          # list of {type, cond, body_start, body_end}
        cur_type       = 'then'
        cur_cond       = cond
        cur_body_start = body_start
        end_if_end     = None

        while j < len(text) and depth > 0:
            w = re.search(r'\b(END_IF|ELSIF|ELSE|IF)\b', text[j:], re.IGNORECASE)
            if not w:
                break
            word      = w.group(1).upper()
            abs_start = j + w.start()
            abs_end   = j + w.end()

            if word == 'IF':
                depth += 1
                j = abs_end
            elif word == 'END_IF':
                depth -= 1
                if depth == 0:
                    clauses.append({'type': cur_type, 'cond': cur_cond,
                                    'body': text[cur_body_start:abs_start].strip()})
                    end_if_end = abs_end
                    break
                j = abs_end
            elif word == 'ELSIF' and depth == 1:
                clauses.append({'type': cur_type, 'cond': cur_cond,
                                'body': text[cur_body_start:abs_start].strip()})
                after_elsif = abs_end
                then_m2 = re.search(r'\bTHEN\b', text[after_elsif:], re.IGNORECASE)
                if then_m2:
                    cur_cond       = text[after_elsif: after_elsif + then_m2.start()].strip()
                    cur_body_start = after_elsif + then_m2.end()
                    cur_type       = 'elsif'
                    j = cur_body_start
                else:
                    j = abs_end
            elif word == 'ELSE' and depth == 1:
                clauses.append({'type': cur_type, 'cond': cur_cond,
                                'body': text[cur_body_start:abs_start].strip()})
                cur_cond       = None
                cur_body_start = abs_end
                cur_type       = 'else'
                j = abs_end
            else:
                j = abs_end

        if end_if_end is None:
            i = body_start
            continue

        then_c   = next((c for c in clauses if c['type'] == 'then'), None)
        elsifs   = [(c['cond'], c['body']) for c in clauses if c['type'] == 'elsif']
        else_c   = next((c for c in clauses if c['type'] == 'else'), None)

        results.append({
            'start':         if_abs,
            'end':           end_if_end,
            'cond':          cond,
            'then_body':     then_c['body'] if then_c else '',
            'elsif_clauses': elsifs,
            'else_body':     else_c['body'] if else_c else None,
        })
        i = end_if_end

    return results


def _combine_conditions(stack):
    """AND-combine a list of condition strings into one condition string."""
    parts = []
    for c in stack:
        c = c.strip()
        if not c or c.upper() == 'TRUE':
            continue
        # wrap sub-expressions that contain OR or are already parenthesised
        if re.search(r'\bOR\b', c, re.IGNORECASE) or (c.startswith('NOT (') and c.endswith(')')):
            parts.append(f'({c})')
        else:
            parts.append(c)
    return ' AND '.join(parts) if parts else 'TRUE'


def _parse_assignments(st_code):
    assignments = []
    st_body = re.sub(r'VAR\b.*?END_VAR', '', st_code, flags=re.IGNORECASE | re.DOTALL)
    st_body = re.sub(r'PROGRAM\s+\w+', '', st_body, flags=re.IGNORECASE)
    st_body = re.sub(r'END_PROGRAM', '', st_body, flags=re.IGNORECASE)
    # Strip IEC 61131-3 block comments (* ... *) and C-style line comments
    # BEFORE parsing so that "IF" tokens inside comments are not matched.
    st_body = re.sub(r'\(\*.*?\*\)', ' ', st_body, flags=re.DOTALL)
    st_body = re.sub(r'//[^\n]*', ' ', st_body)
    _parse_block(st_body.strip(), [], assignments)
    return assignments


def _parse_block(block, condition_stack, out):
    """
    Recursively walk an ST block, collecting every boolean assignment together
    with the full AND-combined condition under which it executes.

    Handles arbitrarily nested IF / ELSIF / ELSE / END_IF structures correctly
    because _extract_if_blocks uses depth counting, not fragile regexes.
    """
    assign_re = re.compile(r'\b(\w+)\s*:=\s*(TRUE|FALSE)\s*;', re.IGNORECASE)

    ifs         = _extract_if_blocks(block)
    used_ranges = [(p['start'], p['end']) for p in ifs]

    for p in ifs:
        # ── THEN branch ──────────────────────────────────────────────────────
        _parse_block(p['then_body'], condition_stack + [p['cond']], out)

        # ── ELSIF branches ───────────────────────────────────────────────────
        # Each ELSIF implicitly requires all previous conditions to be false.
        # We AND-in the negation of the IF (and prior ELSIFs) for correctness.
        prev_neg = [f'NOT ({p["cond"]})']
        for elsif_cond, elsif_body in p['elsif_clauses']:
            _parse_block(elsif_body, condition_stack + prev_neg + [elsif_cond], out)
            prev_neg.append(f'NOT ({elsif_cond})')

        # ── ELSE branch ──────────────────────────────────────────────────────
        if p['else_body'] is not None:
            _parse_block(p['else_body'],
                         condition_stack + [f'NOT ({p["cond"]})'], out)

    # ── Top-level assignments (not inside any nested IF) ─────────────────────
    for m in assign_re.finditer(block):
        if any(s <= m.start() <= e for s, e in used_ranges):
            continue
        value  = m.group(2).strip().upper()
        output = m.group(1).strip()
        combined = _combine_conditions(condition_stack)
        out.append({
            'condition':   combined,
            'output':      output,
            'value':       value,
            'negate_coil': (value == 'FALSE'),
        })


# --- LD Generator ---

def _ld_condition_parts(cond):
    """
    Split an AND-combined condition into individual contact parts, stripping
    out any parts that contain comparison operators (>, <, >=, <=, <>) because
    those cannot be represented as LD contacts.

    Returns a list of (negated: bool, var_name: str).
    If the condition is 'TRUE' (power rail), returns an empty list.
    """
    if cond.strip().upper() == 'TRUE':
        return []

    raw_parts = re.split(r'\bAND\b', cond, flags=re.IGNORECASE)
    contact_parts = []
    for part in raw_parts:
        part = part.strip().strip('()')
        if not part or part.upper() == 'TRUE':
            continue
        # Skip parts with REAL/INT comparison operators — not valid as LD contacts
        if _COMPARE_RE.search(part):
            continue
        # Parse NOT prefix
        neg = bool(re.match(r'\s*NOT\s*\(?\s*', part, re.IGNORECASE) and
                   re.match(r'\s*NOT\b', part, re.IGNORECASE))
        var = re.sub(r'^\s*NOT\s*\(?\s*', '', part, flags=re.IGNORECASE).strip().rstrip(')')
        var = var.strip()
        if var and re.match(r'^[A-Za-z_]\w*$', var):
            contact_parts.append((neg, var))
    return contact_parts


def _ld_body(st_code):
    """Return just the rung XML, without the outer wrapper."""
    assignments = _parse_assignments(st_code)
    rungs_xml   = []
    y           = 100
    for i, a in enumerate(assignments):
        rid     = i + 1
        cid     = rid * 10 + 1
        oid     = rid * 10 + 2
        negated = str(a['negate_coil']).lower()

        contact_parts = _ld_condition_parts(a['condition'])

        contacts_xml = ''
        prev_id = None
        for j, (neg, var) in enumerate(contact_parts):
            contact_id = cid + j
            neg_str = 'true' if neg else 'false'
            if prev_id:
                conn = (f'<connectionPointIn>\n          <relPosition x="0" y="10"/>\n'
                        f'          <connection refLocalId="{prev_id}"/>\n        </connectionPointIn>')
            else:
                conn = '<connectionPointIn>\n          <relPosition x="0" y="10"/>\n        </connectionPointIn>'
            contacts_xml += (
                f'      <contact localId="{contact_id}" negated="{neg_str}">\n'
                f'        <position x="{100+j*140}" y="{y}"/>\n'
                f'        {conn}\n'
                f'        <connectionPointOut><relPosition x="20" y="10"/></connectionPointOut>\n'
                f'        <variable>{_sanitize(var)}</variable>\n'
                f'      </contact>\n'
            )
            prev_id = contact_id

        # If no contacts (all conditions were REAL comparisons or condition='TRUE'),
        # connect the coil directly with no contacts (power rail → coil).
        if contact_parts:
            last_contact_id = cid + len(contact_parts) - 1
            coil_conn = (f'<connectionPointIn>\n'
                         f'          <relPosition x="0" y="10"/>\n'
                         f'          <connection refLocalId="{last_contact_id}"/>\n'
                         f'        </connectionPointIn>')
            coil_x = 100 + len(contact_parts) * 140
        else:
            coil_conn = '<connectionPointIn>\n          <relPosition x="0" y="10"/>\n        </connectionPointIn>'
            coil_x = 100

        coil_xml = (
            f'      <coil localId="{oid}" negated="{negated}">\n'
            f'        <position x="{coil_x}" y="{y}"/>\n'
            f'        {coil_conn}\n'
            f'        <connectionPointOut><relPosition x="20" y="10"/></connectionPointOut>\n'
            f'        <variable>{_sanitize(a["output"])}</variable>\n'
            f'      </coil>\n'
        )
        rungs_xml.append(
            f'    <rung localId="{rid}">\n{contacts_xml}{coil_xml}    </rung>'
        )
        y += 80
    return '\n'.join(rungs_xml)


def st_to_ld_xml(st_code, system_name='GeneratedLD'):
    inputs, outputs, locals_ = _parse_var_block(st_code)
    iface = _interface_xml(inputs, outputs, locals_)
    return _wrap_plcopen_xml(system_name, 'LD', _ld_body(st_code), iface)


# --- FBD Generator ---

def _fbd_body(st_code):
    """Return just the block XML, without the outer wrapper."""
    assignments = _parse_assignments(st_code)
    blocks_xml  = []
    y           = 100
    for i, a in enumerate(assignments):
        bid    = i + 1
        cond   = a['condition']
        output = a['output']
        cond_up = cond.upper().strip()

        # Split AND parts; separate boolean vars from comparison expressions
        raw_parts = [p.strip() for p in re.split(r'\bAND\b', cond, flags=re.IGNORECASE) if p.strip()]
        bool_inputs  = []  # simple boolean variable references
        comp_inputs  = []  # comparison expressions like TEMP > 80.0

        for part in raw_parts:
            part_clean = part.strip().strip('()')
            if not part_clean or part_clean.upper() == 'TRUE':
                continue
            if _COMPARE_RE.search(part_clean):
                # e.g. "TEMPERATURE_SENSOR > 90.0"  →  operand, operator, operand
                m_cmp = re.match(
                    r'([\w.]+)\s*([<>]=?|<>|=)\s*([\w.]+)',
                    part_clean.strip())
                if m_cmp:
                    lhs, op, rhs = m_cmp.group(1), m_cmp.group(2), m_cmp.group(3)
                    op_map = {'>': 'GT', '>=': 'GE', '<': 'LT', '<=': 'LE',
                              '<>': 'NE', '=': 'EQ'}
                    comp_inputs.append((op_map.get(op, 'GT'), lhs, rhs))
                else:
                    comp_inputs.append(('GT', _sanitize(part_clean), '0'))
            else:
                neg = bool(re.match(r'\s*NOT\b', part_clean, re.IGNORECASE))
                var = re.sub(r'^\s*NOT\s*\(?\s*', '', part_clean,
                             flags=re.IGNORECASE).strip().rstrip(')')
                if var:
                    bool_inputs.append((neg, var))

        # Build FBD: emit comparison blocks first (GT/LT/GE/LE), then the AND gate
        comp_block_ids = []
        for k, (op_type, lhs, rhs) in enumerate(comp_inputs):
            cb_id = bid * 100 + k + 1
            comp_block_ids.append(cb_id)
            blocks_xml.append(
                f'    <block localId="{cb_id}" typeName="{op_type}" instanceName="{op_type}_{cb_id}">\n'
                f'      <position x="100" y="{y + k*80}"/>\n'
                f'      <inputVariables>\n'
                f'        <variable formalParameter="IN1" negated="false"><expression>{_sanitize(lhs)}</expression></variable>\n'
                f'        <variable formalParameter="IN2" negated="false"><expression>{_sanitize(rhs)}</expression></variable>\n'
                f'      </inputVariables>\n'
                f'      <inOutVariables/>\n'
                f'      <outputVariables>\n'
                f'        <variable formalParameter="OUT" negated="false"><expression>_cmp_{cb_id}</expression></variable>\n'
                f'      </outputVariables>\n'
                f'    </block>'
            )

        # Combine all inputs into a gate block (AND/MOVE)
        all_inputs = [(False, f'_cmp_{cb_id}') for cb_id in comp_block_ids] + bool_inputs
        if cond_up == 'TRUE' or not all_inputs:
            fb_type = 'MOVE'
            gate_inputs = [a['value']]
        elif len(all_inputs) == 1:
            fb_type  = 'MOVE'
            neg, var = all_inputs[0]
            neg_str  = 'true' if neg else 'false'
            gate_inputs = [var]
        else:
            fb_type    = 'AND'
            gate_inputs = [var for _, var in all_inputs]

        in_vars = ''.join(
            f'        <variable formalParameter="IN{j+1}" negated="false"><expression>{_sanitize(inp)}</expression></variable>\n'
            for j, inp in enumerate(gate_inputs[:8])
        )
        blocks_xml.append(
            f'    <block localId="{bid}" typeName="{fb_type}" instanceName="{fb_type}_{bid}">\n'
            f'      <position x="300" y="{y}"/>\n'
            f'      <inputVariables>\n{in_vars}      </inputVariables>\n'
            f'      <inOutVariables/>\n'
            f'      <outputVariables>\n'
            f'        <variable formalParameter="OUT" negated="false">'
            f'<expression>{_sanitize(output)}</expression></variable>\n'
            f'      </outputVariables>\n'
            f'    </block>'
        )
        y += 100 + len(comp_inputs) * 80
    return '\n'.join(blocks_xml)


def st_to_fbd_xml(st_code, system_name='GeneratedFBD'):
    inputs, outputs, locals_ = _parse_var_block(st_code)
    iface = _interface_xml(inputs, outputs, locals_)
    return _wrap_plcopen_xml(system_name, 'FBD', _fbd_body(st_code), iface)


# --- Utilities ---

def _sanitize(name):
    return re.sub(r'[^a-zA-Z0-9_]', '_', name.strip())


# ---------------------------------------------------------------------------
# VAR-block parser  →  builds <interface> XML for the <pou>
# ---------------------------------------------------------------------------

def _parse_var_block(st_code):
    """Return (inputs, outputs, locals) each as list of (name, type) tuples."""
    def _extract(keyword_open, keyword_close):
        pat = re.compile(
            keyword_open + r'\b(.*?)' + keyword_close + r'\b',
            re.IGNORECASE | re.DOTALL)
        result = []
        for m in pat.finditer(st_code):
            for line in m.group(1).splitlines():
                line = line.strip().rstrip(';')
                if ':' in line and not line.startswith('(*'):
                    names, typ = line.split(':', 1)
                    typ = typ.split(':=')[0].strip()
                    for n in names.split(','):
                        n = n.strip()
                        if n:
                            result.append((n, typ))
        return result

    inputs  = _extract(r'VAR_INPUT',  r'END_VAR')
    outputs = _extract(r'VAR_OUTPUT', r'END_VAR')
    # plain VAR block
    locals_ = []
    for m in re.finditer(r'\bVAR\b(.*?)\bEND_VAR\b', st_code, re.IGNORECASE | re.DOTALL):
        # make sure it's not VAR_INPUT / VAR_OUTPUT / VAR_EXTERNAL etc.
        before = st_code[max(0, m.start()-10):m.start()]
        if re.search(r'(INPUT|OUTPUT|EXTERNAL|GLOBAL)\s*$', before, re.IGNORECASE):
            continue
        for line in m.group(1).splitlines():
            line = line.strip().rstrip(';')
            if ':' in line and not line.startswith('(*'):
                names, typ = line.split(':', 1)
                typ = typ.split(':=')[0].strip()
                for n in names.split(','):
                    n = n.strip()
                    if n:
                        locals_.append((n, typ))
    return inputs, outputs, locals_


def _interface_xml(inputs, outputs, locals_):
    """Render <interface> element from variable lists."""
    def _vars(tag, items):
        if not items:
            return f'      <{tag}/>\n'
        inner = ''.join(
            f'          <variable name="{n}"><type><{t}/></type></variable>\n'
            for n, t in items)
        return f'      <{tag}>\n{inner}      </{tag}>\n'

    return (
        '    <interface>\n' +
        _vars('inputVars',  inputs) +
        _vars('outputVars', outputs) +
        _vars('localVars',  locals_) +
        '    </interface>\n'
    )


# ---------------------------------------------------------------------------
# TC6-compliant XML wrapper  (PLCopen TC6 / IEC 61131-10)
# ---------------------------------------------------------------------------

def _wrap_plcopen_xml(system_name, lang, body_xml, interface_xml=""):
    """
    Produce a fully schema-valid PLCopen TC6 XML document.

    Required by edge.autonomylogic.com and OpenPLC Editor:
      • xsi namespace + schemaLocation on <project>
      • <fileHeader> with contentDescription attribute
      • <contentHeader> with modificationDateTime + <coordinateInfo>
      • <interface> inside <pou>
      • <instances>/<configurations> section
    """
    if not interface_xml:
        interface_xml = '    <interface>\n      <inputVars/>\n      <outputVars/>\n      <localVars/>\n    </interface>\n'

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://www.plcopen.org/xml/tc6_0200"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://www.plcopen.org/xml/tc6_0200 http://www.plcopen.org/xml/tc6_0200/TC6_XML_V201.xsd">
  <fileHeader companyName="ResearchProject" productName="LLM-PLC-Gen"
              productVersion="1.0" creationDateTime="{_NOW}"
              contentDescription="Auto-generated by LLM-PLC research framework"/>
  <contentHeader name="{system_name}" modificationDateTime="{_NOW}">
    <coordinateInfo>
      <fbd><scaling x="1" y="1"/></fbd>
      <ld><scaling x="1" y="1"/></ld>
      <sfc><scaling x="1" y="1"/></sfc>
    </coordinateInfo>
  </contentHeader>
  <types>
    <pous>
      <pou name="{system_name}" pouType="program">
{interface_xml}        <body>
          <{lang.lower()}>
{body_xml}
          </{lang.lower()}>
        </body>
      </pou>
    </pous>
  </types>
  <instances>
    <configurations>
      <configuration name="Config0">
        <resource name="Res0">
          <task name="MainTask" priority="1" interval="T#20ms">
            <pouInstance name="Instance0" typeName="{system_name}"/>
          </task>
        </resource>
      </configuration>
    </configurations>
  </instances>
</project>
"""


# ---------------------------------------------------------------------------
# ST → PLCopen TC6 XML  (for direct import of ST programs)
# ---------------------------------------------------------------------------

def st_to_plcopen_xml(st_code, system_name="GeneratedST"):
    """
    Wrap raw ST code in a valid PLCopen TC6 XML document.
    edge.autonomylogic.com accepts ST POUs this way via File → Import PLCopen XML.
    """
    inputs, outputs, locals_ = _parse_var_block(st_code)
    iface = _interface_xml(inputs, outputs, locals_)

    # Strip PROGRAM…END_PROGRAM wrapper; keep only the body between END_VAR and END_PROGRAM
    body = st_code
    m = re.search(r'\bEND_VAR\b(.*)', body, re.IGNORECASE | re.DOTALL)
    if m:
        body = m.group(1).strip()
    body = re.sub(r'\bEND_PROGRAM\b.*', '', body, flags=re.IGNORECASE | re.DOTALL).strip()

    escaped = body.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

    st_body = f'            <ST><xhtml xmlns="http://www.w3.org/1999/xhtml">{escaped}</xhtml></ST>'

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://www.plcopen.org/xml/tc6_0200"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://www.plcopen.org/xml/tc6_0200 http://www.plcopen.org/xml/tc6_0200/TC6_XML_V201.xsd">
  <fileHeader companyName="ResearchProject" productName="LLM-PLC-Gen"
              productVersion="1.0" creationDateTime="{_NOW}"
              contentDescription="Auto-generated by LLM-PLC research framework"/>
  <contentHeader name="{system_name}" modificationDateTime="{_NOW}">
    <coordinateInfo>
      <fbd><scaling x="1" y="1"/></fbd>
      <ld><scaling x="1" y="1"/></ld>
      <sfc><scaling x="1" y="1"/></sfc>
    </coordinateInfo>
  </contentHeader>
  <types>
    <pous>
      <pou name="{system_name}" pouType="program">
{iface}        <body>
{st_body}
        </body>
      </pou>
    </pous>
  </types>
  <instances>
    <configurations>
      <configuration name="Config0">
        <resource name="Res0">
          <task name="MainTask" priority="1" interval="T#20ms">
            <pouInstance name="Instance0" typeName="{system_name}"/>
          </task>
        </resource>
      </configuration>
    </configurations>
  </instances>
</project>
"""


def _interface_xml_from_task(task):
    """
    Build <interface> XML using the task's normalized_requirement so that
    field inputs end up in <inputVars> (→ X addresses),
    field outputs in <outputVars> (→ Y addresses),
    internal variables in <localVars> (→ M/T/C addresses).
    Falls back to the plain VAR-block parser if task is None.
    """
    nr = (task or {}).get('normalized_requirement', {})
    inputs   = [(v['name'], v.get('type','BOOL')) for v in nr.get('inputs', [])]
    outputs  = [(v['name'], v.get('type','BOOL')) for v in nr.get('outputs', [])]
    internals= [(v['name'], v.get('type','BOOL')) for v in nr.get('internal_variables', [])]
    return _interface_xml(inputs, outputs, internals)


def validate_plcopen_xml(xml_path: str, expected_vars: list = None) -> dict:
    """
    Validate a PLCopen TC6 XML file structurally.

    Checks performed:
      1. File is well-formed XML (parse succeeds)
      2. Root element is <project> in the PLCopen TC6 namespace
      3. Expected output variable names appear in <outputVars> or <localVars>

    This is a structural proxy for compilation success — it confirms the
    generated XML document is importable in principle, without requiring a
    running OpenPLC instance.  Full runtime validation is out of scope
    (see methodology limitations).

    Args:
        xml_path: Path to the PLCopen XML file.
        expected_vars: List of output variable name strings to check for.

    Returns:
        Dict with 'parse_ok' (bool), 'namespace_ok' (bool),
        'variables_present' (bool), 'missing_vars' (list), 'valid' (bool).
    """
    import xml.etree.ElementTree as ET

    result = {
        "parse_ok": False,
        "namespace_ok": False,
        "variables_present": False,
        "missing_vars": [],
        "valid": False,
    }

    try:
        tree = ET.parse(xml_path)
        result["parse_ok"] = True
        root = tree.getroot()
        # PLCopen TC6 namespace check
        ns = "http://www.plcopen.org/xml/tc6_0200"
        result["namespace_ok"] = ns in root.tag

        if expected_vars:
            # Collect all variable names declared in the XML interface section
            declared_in_xml = set()
            for var_elem in root.iter(f"{{{ns}}}variable"):
                name_attr = var_elem.get("name", "")
                if name_attr:
                    declared_in_xml.add(name_attr.upper())
            missing = [v for v in expected_vars if v.upper() not in declared_in_xml]
            result["missing_vars"] = missing
            result["variables_present"] = len(missing) == 0
        else:
            result["variables_present"] = True  # no vars to check

        result["valid"] = result["parse_ok"] and result["namespace_ok"] and result["variables_present"]
    except ET.ParseError as e:
        result["error"] = str(e)
    except Exception as e:
        result["error"] = str(e)

    return result


def translate_and_save(st_code, system_name, output_dir, task=None):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    ld_path  = out / f"{system_name}_LD.xml"
    fbd_path = out / f"{system_name}_FBD.xml"
    st_path  = out / f"{system_name}_ST.xml"

    # Build proper interface from task metadata if available
    if task:
        iface = _interface_xml_from_task(task)
        inputs, outputs, locals_ = _parse_var_block(st_code)  # still needed for fallback
    else:
        inputs, outputs, locals_ = _parse_var_block(st_code)
        iface = _interface_xml(inputs, outputs, locals_)

    ld_path.write_text(
        _wrap_plcopen_xml(system_name, 'LD',
                          _ld_body(st_code),
                          iface if task else None),
        encoding='utf-8')
    fbd_path.write_text(
        _wrap_plcopen_xml(system_name, 'FBD',
                          _fbd_body(st_code),
                          iface if task else None),
        encoding='utf-8')
    st_path.write_text(st_to_plcopen_xml(st_code, system_name), encoding='utf-8')
    print(f'[Mapper] LD  -> {ld_path}')
    print(f'[Mapper] FBD -> {fbd_path}')
    print(f'[Mapper] ST  -> {st_path}')

    # Structural XML validation (upgrade from naive string-search proxy)
    expected_out_vars = []
    if task:
        nr = task.get('normalized_requirement', {})
        expected_out_vars = [v['name'] for v in nr.get('outputs', [])]

    ld_validation  = validate_plcopen_xml(str(ld_path),  expected_out_vars)
    fbd_validation = validate_plcopen_xml(str(fbd_path), expected_out_vars)

    if ld_validation.get('missing_vars'):
        print(f'[Mapper] LD  validation: missing vars {ld_validation["missing_vars"]}')
    if fbd_validation.get('missing_vars'):
        print(f'[Mapper] FBD validation: missing vars {fbd_validation["missing_vars"]}')

    return {
        'ld': str(ld_path),
        'fbd': str(fbd_path),
        'st_xml': str(st_path),
        'ld_validation': ld_validation,
        'fbd_validation': fbd_validation,
    }
