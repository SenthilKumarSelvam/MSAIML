"""
Phase 4: Empirical Evaluation and Metrics Collection
Computes all quantitative metrics defined in the research proposal:
- Compilation success rate
- Syntax error count
- BLEU score (lexical similarity)
- Development time
- Manual corrections count
- Logical equivalence across ST / LD / FBD
"""

import json
import time
from pathlib import Path
from datetime import datetime

# Optional: install with  pip install nltk
try:
    from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False


# ─── Experiment Log Schema ────────────────────────────────────────────────────

def create_experiment_log(
    task_id: str,
    condition: str,
    complexity: str
) -> dict:
    """
    Initialise a blank experiment log entry.

    Args:
        task_id: Identifier for the benchmark task (e.g., 'motor_control_medium').
        condition: One of 'manual', 'direct_llm', 'framework'.
        complexity: One of 'low', 'medium', 'high'.

    Returns:
        A dictionary representing one experimental run.
    """
    return {
        "task_id": task_id,
        "condition": condition,
        "complexity": complexity,
        "timestamp": datetime.now().isoformat(),

        # RQ1 — Compiler-guided feedback metrics
        "compilation_success": None,
        "syntax_errors_initial": None,
        "syntax_errors_final": None,
        "iterations_needed": None,
        "iteration_log": [],

        # RQ2 — Requirement normalization metrics
        "logical_inconsistencies": None,
        "manual_corrections_count": None,
        "manual_corrections_time_min": None,
        "functional_correctness_rate": None,

        # RQ3 — Cross-language equivalence metrics
        "ld_compilation_success": None,
        "fbd_compilation_success": None,
        "semantic_equivalence_score": None,   # 0.0 – 1.0
        "equivalence_level": None,            # 'full', 'partial', 'none'

        # RQ4 — Efficiency metrics
        "dev_time_minutes": None,
        "task_completed_in_budget": None,
        "nasa_tlx_score": None,

        # RQ5 — Engineer trust metrics (web review form)
        # Five category verdicts: 'acceptable' | 'needs_improvement' | 'wrong'
        "review_logic": None,              # Functional logic correctness
        "review_logic_comment": "",
        "review_interlocks": None,         # Interlocks & enable conditions
        "review_interlocks_comment": "",
        "review_safety": None,             # Safety constraints
        "review_safety_comment": "",
        "review_iec": None,                # IEC 61131-3 compliance
        "review_iec_comment": "",
        "review_structure": None,          # Program structure & clarity
        "review_structure_comment": "",
        # Overall decision: 'accept' | 'needs_revision' | 'reject'
        "review_decision": None,
        "escalated_for_review": None,
        "review_time_minutes": None,
        # (nasa_tlx_score is under RQ4 above)

        # Legacy CLI review fields (review_tool.py) — kept for backwards compatibility
        # These are NOT populated by the web review form
        "expert_rating_correctness": None,
        "expert_rating_maintainability": None,
        "expert_rating_safety": None,
        "expert_rating_iec_adherence": None,
        "accepted_without_correction": None,

        # Supplementary
        "bleu_score": None,
        "notes": "",

        # New metrics (from literature)
        "hallucination_rate": None,        # fraction of identifiers not in spec
        "statement_coverage": None,        # fraction of ST lines exercised by tests
        "model_used": None,                # e.g. 'gpt-4o-mini'
        "prompt_style": None,              # 'standard' | 'chain_of_thought' | 'program_of_thought'

        # Normalization metrics (populated when --live-normalize is used)
        "normalization_fidelity": None,    # fraction of reference output vars reproduced by live LLM normalization
        "syntax_errors_delta": None,       # syntax_errors_initial - syntax_errors_final (errors resolved by refinement)

        # Study administration
        "participant_id": None,            # e.g. 'P01' — set via --participant-id flag
        "experiment_number": None,          # e.g. 1, 2, 3 — groups related runs for comparison
        "rag_used": None,                   # True / False — whether RAG retrieval was active

        # AI-guided revision history (populated by /review/<filename>/regenerate)
        "regeneration_history": [],        # list of revision entries {revision, timestamp, issues_addressed,
                                           #   compilation_success, functional_correctness_rate, statement_coverage,
                                           #   syntax_errors, saved_as, suggestion}
        "current_code_version": 1,         # incremented on each accepted regeneration cycle
    }


# ─── Metric Computation ───────────────────────────────────────────────────────

def compute_bleu(generated_code: str, reference_code: str) -> float:
    """
    Compute BLEU score between generated and reference ST programs.

    Args:
        generated_code: LLM-generated code string.
        reference_code: Manually written reference code string.

    Returns:
        BLEU score between 0.0 and 1.0.
    """
    if not NLTK_AVAILABLE:
        print("[Evaluator] NLTK not available, skipping BLEU calculation.")
        return -1.0

    hypothesis = generated_code.split()
    reference = [reference_code.split()]
    smoothie = SmoothingFunction().method1
    return sentence_bleu(reference, hypothesis, smoothing_function=smoothie)


def compute_semantic_equivalence(
    st_test_results: list,
    ld_test_results: list,
    fbd_test_results: list
) -> dict:
    """
    Compute semantic equivalence across ST, LD, FBD based on test case pass/fail vectors.

    Args:
        st_test_results:  List of bool — pass/fail for each test case in ST.
        ld_test_results:  List of bool — pass/fail for each test case in LD.
        fbd_test_results: List of bool — pass/fail for each test case in FBD.

    Returns:
        Dictionary with 'score' (float) and 'level' (str).
    """
    if not st_test_results:
        return {"score": 0.0, "level": "none"}

    n = len(st_test_results)
    agree_ld  = sum(s == l for s, l in zip(st_test_results, ld_test_results))  / n
    agree_fbd = sum(s == f for s, f in zip(st_test_results, fbd_test_results)) / n
    avg_score = (agree_ld + agree_fbd) / 2

    if avg_score >= 0.95:
        level = "full"
    elif avg_score >= 0.6:
        level = "partial"
    else:
        level = "none"

    return {"score": round(avg_score, 4), "level": level}


# ─── New Metrics (Literature-aligned) ────────────────────────────────────────

def compute_hallucination_rate(generated_code: str, task: dict) -> float:
    """
    Fraction of unique identifiers in the generated program body that were NOT
    declared in the task specification (inputs / outputs / internal variables).

    0.0 = every identifier is spec-declared (no hallucinations)
    1.0 = all identifiers are undeclared (fully hallucinated)

    Returns -1.0 if the task spec declares no variables (cannot compare).
    """
    import re as _re

    ST_KEYWORDS = {
        "IF", "THEN", "ELSE", "ELSIF", "END_IF", "AND", "OR", "NOT",
        "TRUE", "FALSE", "PROGRAM", "END_PROGRAM", "VAR", "END_VAR",
        "BOOL", "INT", "UINT", "DINT", "LINT", "REAL", "LREAL", "TIME",
        "TON", "TOF", "TP", "CTU", "CTD", "FOR", "TO", "BY", "DO",
        "END_FOR", "WHILE", "END_WHILE", "CASE", "OF", "END_CASE",
        "RETURN", "EXIT", "Q", "ET", "CV", "IN", "PT", "R", "CLK", "PV",
        # Common ST identifiers that are not hallucinations
        "MAIN", "MAINPROGRAM", "VAR_INPUT", "VAR_OUTPUT", "VAR_IN_OUT",
        "VAR_GLOBAL", "VAR_TEMP", "T", "S",
    }

    # Declared variable names from task spec
    # Check ALL variable groups: inputs, outputs, internal_variables, timers,
    # counters, interlocks — from both normalized_requirement and top-level keys.
    nr = task.get("normalized_requirement", {})
    vars_section = task.get("variables", {})   # legacy fallback
    declared: set = set()
    _VAR_GROUPS = ("inputs", "outputs", "internal_variables", "timers", "counters")
    for vgroup in _VAR_GROUPS:
        # From normalized_requirement
        for var in nr.get(vgroup, []) or []:
            if isinstance(var, dict):
                name = var.get("name", "")
                if name:
                    declared.add(name.upper())
                    # Timer/counter member bits (e.g. TIMER_Q, TIMER_ET) are not hallucinations
                    vtype = var.get("type", "").upper()
                    if vtype in ("TON", "TOF", "TP", "CTU", "CTD"):
                        for suffix in ("_Q", "_ET", "_CV", "_IN", "_PT"):
                            declared.add(name.upper() + suffix)
        # From top-level task keys (Task Builder format)
        short_key = vgroup.replace("_variables", "")
        for var in task.get(vgroup, []) or []:
            if isinstance(var, dict):
                name = var.get("name", "")
                if name:
                    declared.add(name.upper())
                    vtype = var.get("type", "").upper()
                    if vtype in ("TON", "TOF", "TP", "CTU", "CTD"):
                        for suffix in ("_Q", "_ET", "_CV", "_IN", "_PT"):
                            declared.add(name.upper() + suffix)
        # Legacy fallback
        for var in vars_section.get(short_key, []) or []:
            if isinstance(var, dict):
                name = var.get("name", "")
                if name:
                    declared.add(name.upper())
    # Also accept 'internal' key for legacy task JSONs
    for var in vars_section.get("internal", []) or []:
        if isinstance(var, dict):
            name = var.get("name", "")
            if name:
                declared.add(name.upper())
    # Add system/program name so it's not counted as hallucination
    for key in ("system_name", "task_id"):
        sn = task.get(key, "") or nr.get(key, "")
        if sn:
            # Add both the raw name and underscore-collapsed version
            declared.add(sn.upper().replace(" ", ""))
            declared.add(_re.sub(r'[^A-Z0-9]', '', sn.upper()))

    if not declared:
        return -1.0  # no spec baseline to compare against

    # Strip VAR block — only examine the executable body
    body = generated_code
    code_upper = body.upper()
    start = code_upper.rfind("END_VAR")
    if start != -1:
        body = body[start + len("END_VAR"):]

    # Strip ST comments before extracting identifiers — comments contain
    # natural-language words (SAFETY, PHASE, ENSURE, …) that inflate the
    # hallucination rate if counted as identifiers.
    body = _re.sub(r'\(\*.*?\*\)', ' ', body, flags=_re.DOTALL)  # (* ... *)
    body = _re.sub(r'//[^\n]*', ' ', body)                        # // ...

    tokens = set(_re.findall(r"\b[A-Za-z_]\w*\b", body))
    identifiers = {t.upper() for t in tokens} - ST_KEYWORDS

    if not identifiers:
        return 0.0

    undeclared = identifiers - declared
    return round(len(undeclared) / len(identifiers), 4)


def compute_statement_coverage(st_code: str, test_cases: list) -> float:
    """
    Fraction of executable ST statements exercised by the given test cases.
    Delegates to the coverage-instrumented test runner.

    Returns 0.0 if test_cases is empty or transpilation fails.
    Returns -1.0 if st_code has no measurable statements.
    """
    if not test_cases:
        return 0.0
    try:
        from src.test_runner import run_test_cases_with_coverage
        _, cov = run_test_cases_with_coverage(st_code, test_cases)
        return cov
    except Exception:
        return 0.0


class Timer:
    """Simple context manager for recording elapsed time."""

    def __init__(self):
        self._start = None
        self.elapsed_minutes = 0.0
        self.elapsed_seconds = 0.0

    def __enter__(self):
        self._start = time.perf_counter()
        return self

    def __exit__(self, *_):
        elapsed = time.perf_counter() - self._start
        self.elapsed_seconds = round(elapsed, 2)
        self.elapsed_minutes = round(elapsed / 60.0, 4)


# ─── Log Persistence ──────────────────────────────────────────────────────────

def save_log(log: dict, output_dir: str = "results/experiment_logs") -> str:
    """
    Save an experiment log to a JSON file.

    Args:
        log: The experiment log dictionary.
        output_dir: Directory to write logs into.

    Returns:
        Path of the saved file.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    prompt_style = (log.get("prompt_style") or "na").strip().lower().replace(" ", "_")
    filename = f"{log['task_id']}_{log['condition']}_{prompt_style}_{ts}.json"
    path = out / filename
    # Extremely defensive collision guard (same microsecond on some filesystems/processes)
    suffix = 1
    while path.exists():
        path = out / f"{log['task_id']}_{log['condition']}_{prompt_style}_{ts}_{suffix}.json"
        suffix += 1
    path.write_text(json.dumps(log, indent=2), encoding="utf-8")
    print(f"[Evaluator] Log saved → {path}")
    return str(path)


def load_all_logs(log_dir: str = "results/experiment_logs") -> list:
    """
    Load all experiment log JSON files from a directory.

    Args:
        log_dir: Directory containing log JSON files.

    Returns:
        List of log dictionaries.
    """
    logs = []
    for p in Path(log_dir).glob("*.json"):
        with open(p, encoding="utf-8") as f:
            logs.append(json.load(f))
    return logs


def summarize_results(logs: list) -> dict:
    """
    Compute aggregate statistics across all experiment logs.

    Args:
        logs: List of experiment log dictionaries.

    Returns:
        Summary statistics dictionary grouped by condition.
    """
    from collections import defaultdict

    groups = defaultdict(list)
    for log in logs:
        groups[log["condition"]].append(log)

    summary = {}
    for condition, entries in groups.items():
        n = len(entries)

        def avg(key):
            vals = [e[key] for e in entries if e.get(key) is not None]
            return round(sum(vals) / len(vals), 4) if vals else None

        def rate(key):
            vals = [e[key] for e in entries if e.get(key) is not None]
            return round(sum(bool(v) for v in vals) / len(vals), 4) if vals else None

        # RQ5 — web review form verdicts
        # Count 'acceptable' verdicts as passing for rate calculations
        def verdict_rate(key):
            vals = [e[key] for e in entries if e.get(key) is not None]
            return round(sum(1 for v in vals if v == "acceptable") / len(vals), 4) if vals else None

        def decision_rate(value):
            vals = [e["review_decision"] for e in entries if e.get("review_decision") is not None]
            return round(sum(1 for v in vals if v == value) / len(vals), 4) if vals else None

        summary[condition] = {
            "n": n,
            # RQ1
            "compilation_success_rate":     rate("compilation_success"),
            "avg_iterations":               avg("iterations_needed"),
            "avg_syntax_errors_initial":    avg("syntax_errors_initial"),
            "avg_syntax_errors_final":      avg("syntax_errors_final"),
            "avg_syntax_errors_delta":      avg("syntax_errors_delta"),
            # RQ2
            "avg_logical_inconsistencies":  avg("logical_inconsistencies"),
            "avg_manual_corrections":       avg("manual_corrections_count"),
            "avg_functional_correctness":   avg("functional_correctness_rate"),
            "avg_hallucination_rate":       avg("hallucination_rate"),
            "avg_statement_coverage":       avg("statement_coverage"),
            "avg_normalization_fidelity":   avg("normalization_fidelity"),
            # RQ3
            "ld_compilation_success_rate":  rate("ld_compilation_success"),
            "fbd_compilation_success_rate": rate("fbd_compilation_success"),
            "avg_semantic_equivalence":     avg("semantic_equivalence_score"),
            # RQ4
            "avg_dev_time_minutes":         avg("dev_time_minutes"),
            "task_budget_completion_rate":  rate("task_completed_in_budget"),
            "avg_nasa_tlx":                 avg("nasa_tlx_score"),
            # RQ5 — categorical verdict rates (fraction rated 'acceptable')
            "review_logic_acceptable_rate":       verdict_rate("review_logic"),
            "review_interlocks_acceptable_rate":  verdict_rate("review_interlocks"),
            "review_safety_acceptable_rate":      verdict_rate("review_safety"),
            "review_iec_acceptable_rate":         verdict_rate("review_iec"),
            "review_structure_acceptable_rate":   verdict_rate("review_structure"),
            "review_accept_rate":                 decision_rate("accept"),
            "review_needs_revision_rate":         decision_rate("needs_revision"),
            "review_reject_rate":                 decision_rate("reject"),
            "escalation_rate":                    rate("escalated_for_review"),
            "avg_review_time_minutes":            avg("review_time_minutes"),
            # Supplementary
            "avg_bleu_score":               avg("bleu_score"),
        }

    return summary
