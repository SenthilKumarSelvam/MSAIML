"""
Phase 1: Requirement Normalization
Transforms informal industrial control requirements into structured, 
machine-interpretable specifications using LLM assistance.
"""

import json
import openai
from pathlib import Path


NORMALIZE_PROMPT = """
You are an expert IEC 61131-3 PLC engineer. Convert the following informal industrial
control requirement into a strictly structured JSON format.

Output ONLY valid JSON with these exact fields:
{{
  "system_name": "PascalCase name derived from the requirement, no spaces",
  "description": "brief one-line description",
  "inputs": [
    {{"name": "UPPER_SNAKE_CASE", "type": "BOOL|INT|REAL|TIME", "description": "what it represents"}}
  ],
  "outputs": [
    {{"name": "UPPER_SNAKE_CASE", "type": "BOOL|INT|REAL", "description": "what it drives"}}
  ],
  "timers": [
    {{"name": "UPPER_SNAKE_CASE", "type": "TON|TOF|TP", "preset": "T#5s", "description": "purpose"}}
  ],
  "counters": [
    {{"name": "UPPER_SNAKE_CASE", "type": "CTU|CTD|CTUD", "preset": 10, "description": "what is counted"}}
  ],
  "internal_variables": [
    {{"name": "UPPER_SNAKE_CASE", "type": "BOOL|INT|REAL", "initial_value": "value", "description": "purpose"}}
  ],
  "control_conditions": [
    {{"condition": "IF ... THEN ... (IEC 61131-3 ST syntax)", "priority": "high|medium|low"}}
  ],
  "safety_constraints": ["list of safety / interlock rules as plain-English strings"],
  "complexity": "low|medium|high"
}}

CRITICAL — VARIABLE NAMING AND SCOPE RULES (violations produce incorrect PLC code):

1. DERIVE NAMES FROM TEXT: Every variable name MUST be traceable to a noun or device
   explicitly named in this requirement. Do NOT invent generic names.
   BAD: INPUT_1, OUTPUT_2, LEVEL_HIGH (if text does not mention level/tank)
   GOOD: ZONE1_ENTRY, JAM_SENSOR_Z3, ZONE2_MOTOR, PRODUCT_COUNT

2. SENSOR TYPE FOLLOWS TEXT:
   - "entry/exit/proximity/occupancy sensor" → BOOL sensor named after its function, NOT a pushbutton.
   - "level sensor / float switch / tank full" → LEVEL_HIGH / LEVEL_LOW (only when text says so).
   - The word "sensor" alone does NOT imply LEVEL_HIGH or LEVEL_LOW.

3. TIMER PRESETS FROM TEXT: Use the exact duration stated ("15 seconds" → T#15s).
   Name timers after their purpose ("jam detection zone 2" → JAM_TIMER_Z2, TON, T#15s).

4. COUNTER TYPES FROM SEMANTICS:
   - "product / item / batch count" → CTUD.  Fault accumulation → CTU.
   - Name after what is counted: PRODUCT_COUNT, not MOTOR_CNT.

5. ZONE / STATION INDEXING: N zones → N-indexed sets: ZONE1_*, ZONE2_*, ..., ZONEN_*.
   For 5 zones: inputs must include ZONE1_ENTRY, ZONE2_ENTRY, ZONE3_ENTRY, ZONE4_ENTRY, ZONE5_ENTRY
   (and likewise exit sensors, jam sensors, timers, motor outputs — one complete set per zone).

6. NO CROSS-DOMAIN CONTAMINATION: Add NO variables from unrelated domains
   (no LEVEL_HIGH in a conveyor spec; no ZONE_OCCUPIED in a pump spec).

7. NEVER ABBREVIATE — ENUMERATE EVERY INSTANCE EXPLICITLY:
   You MUST list every single variable, timer, and counter individually in the JSON arrays.
   Never use "..." or imply a repeated pattern — write out all N entries in full.
   - 5 zones → list all 5 sensor inputs, all 5 motor outputs, all 5 jam timers.
   - Omitting any instance (e.g. only listing zone 1 and zone 5) is a fatal bug.

Informal Requirement:
{raw_requirement}
"""


def normalize_requirement(raw_text: str, client: openai.OpenAI, model: str = "gpt-4") -> dict:
    """
    Normalize a raw informal requirement into a structured JSON specification.

    Args:
        raw_text: The informal requirement string.
        client: Authenticated OpenAI client.
        model: LLM model to use.

    Returns:
        Parsed dictionary of the structured requirement.
    """
    prompt = NORMALIZE_PROMPT.format(raw_requirement=raw_text)

    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2  # Low temperature for deterministic structured output
    )

    raw_output = response.choices[0].message.content.strip()

    # Strip markdown code fences if present
    if raw_output.startswith("```"):
        raw_output = raw_output.split("```")[1]
        if raw_output.startswith("json"):
            raw_output = raw_output[4:]

    try:
        structured = json.loads(raw_output)
    except json.JSONDecodeError as e:
        raise ValueError(f"LLM did not return valid JSON: {e}\nRaw output:\n{raw_output}")

    return structured


def normalize_from_file(input_path: str, output_path: str, client: openai.OpenAI) -> dict:
    """
    Read a raw requirement from file, normalize it, and save the result.

    Args:
        input_path: Path to the .txt file with informal requirement.
        output_path: Path to save the normalized .json file.
        client: Authenticated OpenAI client.

    Returns:
        The structured requirement dictionary.
    """
    raw_text = Path(input_path).read_text(encoding="utf-8")
    structured = normalize_requirement(raw_text, client)

    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(json.dumps(structured, indent=2), encoding="utf-8")

    print(f"[Normalizer] Saved structured requirement to {output_path}")
    return structured


def format_for_prompt(structured: dict, gap_block: str = "") -> str:
    """
    Convert a structured requirement dictionary into a human-readable
    string suitable for use in LLM code generation prompts.

    Args:
        structured: The normalized requirement dictionary.
        gap_block:  Optional gap-detection injection from Agent 3.

    Returns:
        A formatted string representation with explicit engineering guidance.
    """
    lines = [
        f"System Name : {structured.get('system_name', 'Unknown')}",
        f"Description : {structured.get('description', '')}",
        "",
        "─── MANDATORY VARIABLE NAMES (use EXACTLY as listed) ───",
        "",
        "INPUTS:",
    ]
    for inp in structured.get("inputs", []):
        lines.append(f"  - {inp['name']} : {inp['type']}  // {inp.get('description', '')}")

    lines.append("\nOUTPUTS:")
    for out in structured.get("outputs", []):
        lines.append(f"  - {out['name']} : {out['type']}  // {out.get('description', '')}")

    ivars = structured.get("internal_variables", [])
    if ivars:
        lines.append("\nINTERNAL VARIABLES:")
        for var in ivars:
            init = var.get("initial_value", "0")
            lines.append(f"  - {var['name']} : {var['type']} := {init}  // {var.get('description', '')}")

    timers = structured.get("timers", [])
    if timers:
        lines.append("\nTIMERS:")
        for tm in timers:
            preset = tm.get("preset", "T#1s")
            lines.append(f"  - {tm['name']} : {tm.get('type', 'TON')}  // PT={preset}; {tm.get('description', '')}")

    counters = structured.get("counters", [])
    if counters:
        lines.append("\nCOUNTERS:")
        for c in counters:
            lines.append(f"  - {c['name']} : {c.get('type', 'CTU')}  // {c.get('description', '')}")

    lines.append("\n─── CONTROL CONDITIONS (implement ALL of these) ───")
    lines.append("  Priority order: [HIGH] executes before [MEDIUM] before [LOW]")
    lines.append("  Safety/E-STOP conditions ALWAYS come first in the program body.\n")
    for cond in structured.get("control_conditions", []):
        lines.append(f"  [{cond.get('priority', '').upper()}] {cond['condition']}")

    constraints = structured.get("safety_constraints", [])
    if constraints:
        lines.append("\n─── SAFETY CONSTRAINTS (non-negotiable) ───")
        for sc in constraints:
            lines.append(f"  ! {sc}")

    lines.append(
        "\nNOTE: Do NOT rename variables. Do NOT add variables not listed above "
        "unless they are anonymous timer/counter instances required by the logic."
    )

    # Agent 3: inject gap-detection warnings at end of prompt
    if gap_block and gap_block.strip():
        lines.append(gap_block)

    return "\n".join(lines)
