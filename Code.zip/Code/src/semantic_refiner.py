"""
Agent 2 — Semantic Refinement Loop
=====================================
After the syntax compiler loop passes, runs test cases against the
generated ST code. If any test cases FAIL, builds a structured
failure report and asks the LLM to fix the LOGIC (not just syntax),
then re-runs tests. Repeats up to MAX_SEMANTIC_ITERATIONS times.

This directly addresses the core problem: an LLM can produce code
that compiles cleanly but implements wrong logic. The compiler loop
catches syntax errors; this agent catches semantic/logic errors.

Key outputs stored in the experiment log:
  semantic_refinement_iterations : int   — how many logic-fix cycles ran
  semantic_refinement_log        : list  — per-iteration details
  final_st_code                  : str   — code after semantic refinement
  (st_test_results and functional_correctness_rate are updated in-place)
"""

from __future__ import annotations
import re
import json
import config

# ─── Prompts ─────────────────────────────────────────────────────────────────

_SEMANTIC_FIX_SYSTEM = """\
You are a senior IEC 61131-3 PLC software engineer specialising in
safety-critical industrial automation.
Your task: fix LOGIC ERRORS in a Structured Text (ST) program.
The program compiles without syntax errors, but test cases reveal
that the control logic is WRONG.

Rules:
- Keep EXACT variable names — do not rename any variable
- Keep the PROGRAM ... END_PROGRAM structure intact
- Do NOT introduce new variables unless they are declared in the spec
- Maintain the E-STOP / safety fence as the FIRST branch
- Return ONLY the corrected ST code — no markdown, no explanation
"""

_SEMANTIC_FIX_TEMPLATE = """\
=== SPECIFICATION (what the code MUST implement) ===
{spec_summary}

=== CURRENT ST CODE (compiles but has logic errors) ===
{current_code}

=== FAILING TEST CASES ===
{failures_block}

=== INSTRUCTIONS ===
Fix the logic so ALL test cases pass.
Return the corrected complete IEC 61131-3 ST program.
"""


# ─── Public entry point ───────────────────────────────────────────────────────

def semantic_refinement_loop(
    st_code: str,
    test_cases: list,
    normalized_requirement: dict,
    client=None,
    max_iterations: int = None,
) -> dict:
    """
    Iteratively fix ST code logic until all test cases pass or max iterations reached.

    Args:
        st_code:                 The compiled (syntax-correct) ST code.
        test_cases:              List of test case dicts from the benchmark task.
        normalized_requirement:  Spec dict (for context in the LLM prompt).
        client:                  OpenAI / Gemini client (None → MOCK mode).
        max_iterations:          Max logic-fix cycles (default: config.MAX_SEMANTIC_ITERATIONS).

    Returns:
        {
          "final_code":                   str,
          "final_test_results":           list[dict],
          "final_correctness_rate":       float,
          "semantic_refinement_iterations": int,
          "semantic_refinement_log":      list[dict],
          "improved":                     bool,
        }
    """
    from src.test_runner import run_test_cases_with_coverage, compute_functional_correctness

    if max_iterations is None:
        max_iterations = getattr(config, "MAX_SEMANTIC_ITERATIONS", 3)

    # ── Baseline: run tests on code coming in ───────────────────────────────
    results, coverage = run_test_cases_with_coverage(st_code, test_cases)
    initial_pass_rate = compute_functional_correctness(results)
    refinement_log = []

    # If already perfect — nothing to do
    if initial_pass_rate >= 1.0:
        return {
            "final_code":                      st_code,
            "final_test_results":              results,
            "final_correctness_rate":          initial_pass_rate,
            "semantic_refinement_iterations":  0,
            "semantic_refinement_log":         [],
            "improved":                        False,
        }

    # MOCK mode: no LLM available — report failures but don't fix
    if config.MOCK_LLM or client is None:
        print(f"[Agent 2] MOCK mode — {_count_failures(results)} test(s) failed, "
              "skipping logic refinement (no LLM).")
        return {
            "final_code":                      st_code,
            "final_test_results":              results,
            "final_correctness_rate":          initial_pass_rate,
            "semantic_refinement_iterations":  0,
            "semantic_refinement_log":         [],
            "improved":                        False,
        }

    spec_summary = _build_spec_summary(normalized_requirement)
    current_code = st_code
    best_code    = st_code
    best_results = results
    best_rate    = initial_pass_rate

    for iteration in range(1, max_iterations + 1):
        failures = [r for r in results if not r["passed"]]
        n_fail   = len(failures)
        n_pass   = len(results) - n_fail
        print(f"[Agent 2] Iteration {iteration}: {n_fail} test(s) failing, "
              f"{n_pass}/{len(results)} passing — calling LLM for logic fix...")

        failures_block = _format_failures(failures)

        # Call LLM to fix logic
        try:
            fixed_code = _call_llm_logic_fix(
                current_code, spec_summary, failures_block, client
            )
        except Exception as exc:
            print(f"[Agent 2] LLM logic fix failed: {exc}")
            refinement_log.append({
                "iteration":  iteration,
                "failures_in": n_fail,
                "failures_out": n_fail,
                "error": str(exc),
            })
            break

        # Re-run tests on fixed code
        new_results, new_coverage = run_test_cases_with_coverage(fixed_code, test_cases)
        new_rate = compute_functional_correctness(new_results)
        new_fail = _count_failures(new_results)

        refinement_log.append({
            "iteration":           iteration,
            "failures_in":         n_fail,
            "failures_out":        new_fail,
            "pass_rate_before":    round(initial_pass_rate, 4),
            "pass_rate_after":     round(new_rate, 4),
        })

        if new_rate > best_rate:
            best_code    = fixed_code
            best_results = new_results
            best_rate    = new_rate
            print(f"[Agent 2] Improvement: {n_fail} → {new_fail} failures "
                  f"({new_rate:.0%} pass rate)")

        current_code = fixed_code
        results      = new_results

        if new_rate >= 1.0:
            print(f"[Agent 2] All tests passing after {iteration} iteration(s).")
            break

    improved = best_rate > initial_pass_rate

    return {
        "final_code":                      best_code,
        "final_test_results":              best_results,
        "final_correctness_rate":          best_rate,
        "semantic_refinement_iterations":  len(refinement_log),
        "semantic_refinement_log":         refinement_log,
        "improved":                        improved,
    }


# ─── LLM call ─────────────────────────────────────────────────────────────────

def _call_llm_logic_fix(
    current_code: str,
    spec_summary: str,
    failures_block: str,
    client,
) -> str:
    """Send the logic-fix prompt using the run-scoped client and return fixed code."""
    user_prompt = _SEMANTIC_FIX_TEMPLATE.format(
        spec_summary=spec_summary,
        current_code=current_code,
        failures_block=failures_block,
    )
    for _ in range(2):
        resp = client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[
                {"role": "system", "content": _SEMANTIC_FIX_SYSTEM},
                {"role": "user",   "content": user_prompt},
            ],
            temperature=0.15,
            max_tokens=4096,
        )
        msg_content = resp.choices[0].message.content
        if msg_content is None:
            raw = ""
        elif isinstance(msg_content, str):
            raw = msg_content.strip()
        elif isinstance(msg_content, list):
            raw = "\n".join(
                part.get("text", "") if isinstance(part, dict) else str(part)
                for part in msg_content
            ).strip()
        else:
            raw = str(msg_content).strip() if msg_content else ""

        if raw:
            return _strip_fences(raw)

    raise RuntimeError("LLM returned empty logic-fix response.")


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _build_spec_summary(normalized_requirement: dict) -> str:
    """Concise spec summary for the LLM prompt."""
    lines = []
    nr = normalized_requirement
    lines.append(f"System: {nr.get('system_name', '')} — {nr.get('description', '')}")
    lines.append("\nInputs:  " + ", ".join(
        f"{v['name']}:{v['type']}" for v in nr.get("inputs", [])
    ))
    lines.append("Outputs: " + ", ".join(
        f"{v['name']}:{v['type']}" for v in nr.get("outputs", [])
    ))
    if nr.get("safety_constraints"):
        lines.append("\nSafety constraints:")
        for sc in nr["safety_constraints"]:
            lines.append(f"  ! {sc}")
    if nr.get("control_conditions"):
        lines.append("\nControl conditions:")
        for cc in nr["control_conditions"]:
            pri = cc.get("priority", "medium").upper()
            lines.append(f"  [{pri}] {cc['condition']}")
    return "\n".join(lines)


def _format_failures(failures: list) -> str:
    """Format failing test cases into a readable block for the LLM with enhanced diagnostics."""
    lines = []
    for tc in failures:
        lines.append(f"Test: {tc.get('id','?')} — {tc.get('description','')}")
        # inputs
        inp = tc.get("inputs", {})
        if inp:
            lines.append(f"  Inputs:   {json.dumps(inp)}")
        # expected vs actual
        exp = tc.get("expected", {})
        act = tc.get("actual",   {})
        if exp:
            lines.append(f"  Expected: {json.dumps(exp)}")
        if act:
            lines.append(f"  Actual:   {json.dumps(act)}")
        if tc.get("error"):
            lines.append(f"  Error:    {tc['error']}")
        # highlight mismatches with enhanced diagnostics
        mismatches = {k: (exp.get(k), act.get(k))
                      for k in exp if k in act and exp[k] != act[k]}
        if mismatches:
            for var, (e_val, a_val) in mismatches.items():
                issue_type = _predict_failure_type(var, e_val, a_val)
                lines.append(f"  MISMATCH: {var} expected={e_val}, got={a_val}")
                lines.append(f"           → {issue_type}")
        # Add any variable state at failure if available
        if tc.get("state_at_failure"):
            lines.append(f"  State at failure: {json.dumps(tc['state_at_failure'])}")
        lines.append("")
    return "\n".join(lines).strip()


def _predict_failure_type(var: str, expected, actual) -> str:
    """Predict the type of logic error from mismatch pattern."""
    if expected is True and actual is False:
        return "Output should be ON but is OFF → missing or too-restrictive enabling condition"
    elif expected is False and actual is True:
        return "Output should be OFF but is ON → missing safety check or unintended transition"
    elif isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        if actual < expected:
            return f"Value too low → condition may be missing or logic is incomplete"
        else:
            return f"Value too high → unwanted override or missing reset condition"
    return "Logic error in state transition"


def _count_failures(results: list) -> int:
    return sum(1 for r in results if not r.get("passed"))


def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        lines = lines[1:] if lines[0].startswith("```") else lines
        lines = lines[:-1] if lines and lines[-1].startswith("```") else lines
        text = "\n".join(lines)
    return text.strip()
