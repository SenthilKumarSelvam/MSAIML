"""
Phase 2/3 Validation: Test Case Execution Engine
Interprets IEC 61131-3 Structured Text programs against predefined
test cases by converting ST syntax to Python and executing in a
sandboxed namespace.

Supports: boolean logic, IF/ELSIF/ELSE/END_IF, simple assignments,
          TON timer Q-bit injection, comparison operators.
"""

import re
from typing import Any


def _canonical_name(name: str) -> str:
    """Case/format-insensitive canonical token for PLC identifiers."""
    return re.sub(r"[^A-Za-z0-9]", "", str(name)).upper()


class _AliasNamespace(dict):
    """
    Dict used as exec locals that treats identifier variants as the same symbol.
    Example: E_STOP, EStop, E_Stop all resolve to one backing entry.
    """

    def __init__(self, *args, **kwargs):
        super().__init__()
        self._canon_to_real: dict[str, str] = {}
        if args or kwargs:
            self.update(*args, **kwargs)

    def _real_key(self, key: Any) -> Any:
        if not isinstance(key, str):
            return key
        canon = _canonical_name(key)
        if canon in self._canon_to_real:
            return self._canon_to_real[canon]
        self._canon_to_real[canon] = key
        return key

    def __setitem__(self, key: Any, value: Any) -> None:
        super().__setitem__(self._real_key(key), value)

    def __getitem__(self, key: Any) -> Any:
        return super().__getitem__(self._real_key(key))

    def get(self, key: Any, default: Any = None) -> Any:
        return super().get(self._real_key(key), default)


# ─── ST → Python Transpiler ───────────────────────────────────────────────────

def _st_to_python(st_code: str) -> str:
    """
    Convert a subset of IEC 61131-3 ST syntax to executable Python.

    Handles:
      - IF / ELSIF / ELSE / END_IF
      - := assignments
      - AND / OR / NOT / TRUE / FALSE / <>
      - Timer Q-bit references (TIMER.Q → TIMER_Q)
    """
    lines_out = []
    indent_stack = [0]            # stack of current indent levels
    current_indent = 0

    # Strip PROGRAM / VAR blocks — handled separately
    body = _extract_program_body(st_code)

    # Pre-split any multi-statement lines (e.g. "A := 1; B := 2;")
    expanded_lines = []
    for raw_line in body.splitlines():
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("(*") or stripped.startswith("//"):
            expanded_lines.append(raw_line)
            continue
        # Split on semicolons but only if we have multiple := on the same line
        if stripped.count(":=") > 1 or (stripped.count(";") > 1 and ":=" in stripped):
            parts = [p.strip() for p in stripped.split(";") if p.strip()]
            expanded_lines.extend(parts)
        else:
            expanded_lines.append(raw_line)

    for raw_line in expanded_lines:
        line = raw_line.strip()
        if not line or line.startswith("(*") or line.startswith("//"):
            continue

        # Strip ST comments: (* ... *) and // ...
        line = re.sub(r'\(\*.*?\*\)', '', line).strip()
        line = re.sub(r'//.*$', '', line).strip()
        if not line:
            continue

        # Strip trailing semicolons for cleaner matching
        line = re.sub(r';\s*$', '', line).strip()

        # Resolve END_IF / END_FOR / END_WHILE / END_CASE → dedent
        if re.match(r"END_(IF|FOR|WHILE|CASE)\s*;?$", line, re.IGNORECASE):
            if len(indent_stack) > 1:
                indent_stack.pop()
                current_indent = indent_stack[-1]
            continue

        # ELSE
        if re.match(r"^ELSE\s*;?$", line, re.IGNORECASE):
            # pop the previous if/elif branch, return to base level
            if len(indent_stack) > 1:
                indent_stack.pop()
            current_indent = indent_stack[-1]
            py_line = " " * current_indent + "else:"
            lines_out.append(py_line)
            current_indent += 4
            indent_stack.append(current_indent)
            continue

        # ELSIF condition THEN
        elsifm = re.match(r"^ELSIF\s+(.+?)\s+THEN\s*;?$", line, re.IGNORECASE)
        if elsifm:
            # pop the previous if/elif branch, return to base level
            if len(indent_stack) > 1:
                indent_stack.pop()
            current_indent = indent_stack[-1]
            cond = _convert_expr(elsifm.group(1))
            py_line = " " * current_indent + f"elif {cond}:"
            lines_out.append(py_line)
            current_indent += 4
            indent_stack.append(current_indent)
            continue

        # IF condition THEN
        ifm = re.match(r"^IF\s+(.+?)\s+THEN\s*;?$", line, re.IGNORECASE)
        if ifm:
            cond = _convert_expr(ifm.group(1))
            py_line = " " * current_indent + f"if {cond}:"
            lines_out.append(py_line)
            current_indent += 4
            indent_stack.append(current_indent)
            continue

        # Assignment: VAR := EXPR;
        assign = re.match(r"^(\w[\w.]*)\s*:=\s*(.+?)\s*;?\s*$", line)
        if assign:
            lhs = _convert_varname(assign.group(1))
            rhs = _convert_expr(assign.group(2))
            lines_out.append(" " * current_indent + f"{lhs} = {rhs}")
            continue

        fb_line = _convert_fb_call(line)
        if fb_line:
            lines_out.append(" " * current_indent + fb_line)
            continue

        # Skip lines we can't parse but record them as a no-op so indentation isn't broken
        lines_out.append(" " * current_indent + f"pass  # unparsed: {line[:60]}")

    return "\n".join(lines_out)


def _extract_program_body(st_code: str) -> str:
    """Return only the executable body (after END_VAR, before END_PROGRAM)."""
    code = st_code.upper()
    start = code.rfind("END_VAR")
    end   = code.rfind("END_PROGRAM")
    if start == -1 or end == -1:
        return st_code
    return st_code[start + len("END_VAR"):end].strip()


def _convert_varname(name: str) -> str:
    """Convert timer.Q style references to valid Python identifiers."""
    return name.replace(".", "_")


def _convert_expr(expr: str) -> str:
    """Convert an ST expression to a Python expression."""
    # Timer member access  e.g. STAR_TIMER.Q → STAR_TIMER_Q
    expr = re.sub(r"(\w+)\.(\w+)", lambda m: m.group(1) + "_" + m.group(2), expr)
    # Boolean keywords
    expr = re.sub(r"\bAND\b",   "and",   expr, flags=re.IGNORECASE)
    expr = re.sub(r"\bOR\b",    "or",    expr, flags=re.IGNORECASE)
    expr = re.sub(r"\bNOT\b",   "not",   expr, flags=re.IGNORECASE)
    expr = re.sub(r"\bTRUE\b",  "True",  expr, flags=re.IGNORECASE)
    expr = re.sub(r"\bFALSE\b", "False", expr, flags=re.IGNORECASE)
    # Inequality: <> → !=
    expr = expr.replace("<>", "!=")
    # Equality: lone = not preceded by < > ! : → ==
    expr = re.sub(r"(?<![<>!:=])=(?!=)", "==", expr)
    return expr


def _convert_fb_call(line: str) -> str | None:
        """
        Convert simple function-block calls to Python state updates.

        Supported shape:
            NAME(IN := <expr>, ...)

        Emulation model (single-scan simplification):
            NAME_Q = bool(<expr>)
        """
        m = re.match(r"^(\w+)\s*\((.*)\)\s*;?$", line)
        if not m:
                return None

        block_name = m.group(1)
        args = m.group(2)

        # Split args on top-level commas so parenthesized expressions remain intact.
        parts = []
        buf = []
        depth = 0
        for ch in args:
            if ch == "(":
                depth += 1
            elif ch == ")" and depth > 0:
                depth -= 1
            if ch == "," and depth == 0:
                part = "".join(buf).strip()
                if part:
                    parts.append(part)
                buf = []
                continue
            buf.append(ch)
        tail = "".join(buf).strip()
        if tail:
            parts.append(tail)

        in_expr_raw = None
        for part in parts:
            mm = re.match(r"^IN\s*:=\s*(.+)$", part, re.IGNORECASE)
            if mm:
                in_expr_raw = mm.group(1).strip()
                break

        if not in_expr_raw:
                return None

        in_expr = _convert_expr(in_expr_raw)
        return f"{block_name}_Q = bool({in_expr})"


# ─── Variable Declaration Parser ─────────────────────────────────────────────

def _parse_var_declarations(st_code: str) -> dict:
    """
    Extract declared variables and their initial values from VAR blocks.
    Returns a dict of {name: default_value}.
    Supports BOOL (default False), INT/REAL (default 0).
    """
    defaults = {}
    in_var = False
    for line in st_code.splitlines():
        stripped = line.strip().upper()
        if stripped.startswith("VAR") and not stripped.startswith("VAR_"):
            in_var = True
            continue
        if stripped.startswith("END_VAR"):
            in_var = False
            continue
        if not in_var:
            continue

        # Pattern: NAME : TYPE [:= INITIAL];
        m = re.match(
            r"(\w+)\s*:\s*(\w+)(?:\s*:=\s*([^;]+))?\s*;",
            line.strip(), re.IGNORECASE
        )
        if m:
            name    = m.group(1)
            typ     = m.group(2).upper()
            initial = m.group(3)
            if initial:
                iv = initial.strip().upper()
                if iv == "TRUE":
                    defaults[name] = True
                elif iv == "FALSE":
                    defaults[name] = False
                else:
                    try:
                        defaults[name] = int(iv)
                    except ValueError:
                        try:
                            defaults[name] = float(iv)
                        except ValueError:
                            defaults[name] = False
            else:
                if typ == "BOOL":
                    defaults[name] = False
                elif typ in ("INT", "UINT", "DINT", "LINT"):
                    defaults[name] = 0
                elif typ in ("REAL", "LREAL"):
                    defaults[name] = 0.0
                elif typ in ("TON", "TOF", "TP", "CTU", "CTD"):
                    # Timer/counter blocks: expose ALL member bits as separate vars
                    defaults[name] = None
                    defaults[name + "_Q"]  = False   # output bit
                    defaults[name + "_ET"] = 0       # elapsed time
                    defaults[name + "_CV"] = 0       # counter value
                    defaults[name + "_IN"] = False   # input enable
                    defaults[name + "_PT"] = 0       # preset time
                else:
                    defaults[name] = None
    return defaults


# ─── Public API ───────────────────────────────────────────────────────────────

def run_test_cases(st_code: str, test_cases: list) -> list:
    """
    Execute a list of test cases against an ST program.

    Each test case dict has:
        id, description, inputs (dict), expected_outputs (dict)
    Optional 'notes' key can inject extra variables
    (e.g., "Evaluate after STAR_TIMER.Q = TRUE").

    Returns a list of result dicts with pass/fail and details.
    """
    try:
        py_code = _st_to_python(st_code)
    except Exception as e:
        return [{"id": tc.get("id", "?"), "passed": False,
                 "error": f"Transpile error: {e}"} for tc in test_cases]

    declared_defaults = _parse_var_declarations(st_code)
    results = []

    for tc in test_cases:
        tc_id     = tc.get("id", "?")
        inputs    = dict(tc.get("inputs", {}))
        expected  = dict(tc.get("expected_outputs", {}))
        notes     = tc.get("notes", "")

        # Build execution namespace
        namespace: _AliasNamespace = _AliasNamespace()

        # 1. Declared defaults (initial values)
        for name, val in declared_defaults.items():
            namespace[name] = val

        # 2. Apply pre_state (optional — sets internal variable values before inputs,
        #    used for stateful test cases that assume a prior execution cycle)
        pre_state = dict(tc.get("pre_state", {}))
        namespace.update(pre_state)

        # 3. Apply test inputs (override pre_state where inputs are specified)
        namespace.update(inputs)

        # 4. Parse notes for timer Q-bit injection
        #    e.g. "Evaluate after STAR_TIMER.Q = TRUE"
        for m in re.finditer(r"(\w+)\.Q\s*=\s*(TRUE|FALSE)", notes, re.IGNORECASE):
            key = m.group(1) + "_Q"
            namespace[key] = (m.group(2).upper() == "TRUE")

        # 5. Execute transpiled code (multiple scans for sequential/stateful programs)
        #    PLC programs run cyclically.  A single scan often only sets internal
        #    state flags; the outputs change on subsequent scans.  Running 3 scans
        #    lets simple sequential logic progress through its state machine.
        _MAX_SCANS = 3
        try:
            for _scan in range(_MAX_SCANS):
                exec(py_code, {}, namespace)
        except Exception as e:
            results.append({
                "id": tc_id,
                "description": tc.get("description", ""),
                "passed": False,
                "error": str(e),
                "actual": {},
                "expected": expected
            })
            continue

        # 6. Compare outputs
        actual = {k: namespace.get(k) for k in expected}
        passed = all(actual.get(k) == expected[k] for k in expected)

        results.append({
            "id": tc_id,
            "description": tc.get("description", ""),
            "passed": passed,
            "actual": actual,
            "expected": expected,
            "error": None
        })

    return results


# ─── Coverage-Instrumented Execution ────────────────────────────────────────

def _st_to_python_covered(st_code: str) -> tuple:
    """
    Like _st_to_python but injects `_cov.add(N)` before each executable
    statement so statement coverage can be measured.

    Returns:
        (py_code: str, total_statements: int)
    """
    lines_out = []
    indent_stack = [0]
    current_indent = 0
    stmt_count = 0

    body = _extract_program_body(st_code)

    # Pre-split multi-statement lines
    expanded_lines = []
    for raw_line in body.splitlines():
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("(*") or stripped.startswith("//"):
            expanded_lines.append(raw_line)
            continue
        if stripped.count(":=") > 1 or (stripped.count(";") > 1 and ":=" in stripped):
            parts = [p.strip() for p in stripped.split(";") if p.strip()]
            expanded_lines.extend(parts)
        else:
            expanded_lines.append(raw_line)

    for raw_line in expanded_lines:
        line = raw_line.strip()
        if not line or line.startswith("(*") or line.startswith("//"):
            continue

        # Strip ST comments: (* ... *) and // ...
        line = re.sub(r'\(\*.*?\*\)', '', line).strip()
        line = re.sub(r'//.*$', '', line).strip()
        if not line:
            continue

        # Strip trailing semicolons for cleaner matching
        line = re.sub(r';\s*$', '', line).strip()

        if re.match(r"END_(IF|FOR|WHILE|CASE)\s*;?$", line, re.IGNORECASE):
            if len(indent_stack) > 1:
                indent_stack.pop()
                current_indent = indent_stack[-1]
            continue

        if re.match(r"^ELSE\s*;?$", line, re.IGNORECASE):
            if len(indent_stack) > 1:
                indent_stack.pop()
            current_indent = indent_stack[-1]
            lines_out.append(" " * current_indent + "else:")
            current_indent += 4
            indent_stack.append(current_indent)
            continue

        elsifm = re.match(r"^ELSIF\s+(.+?)\s+THEN\s*;?$", line, re.IGNORECASE)
        if elsifm:
            if len(indent_stack) > 1:
                indent_stack.pop()
            current_indent = indent_stack[-1]
            cond = _convert_expr(elsifm.group(1))
            lines_out.append(" " * current_indent + f"elif {cond}:")
            current_indent += 4
            indent_stack.append(current_indent)
            # marker goes INSIDE the elif block so Python syntax stays valid
            stmt_count += 1
            lines_out.append(" " * current_indent + f"_cov.add({stmt_count})")
            continue

        ifm = re.match(r"^IF\s+(.+?)\s+THEN\s*;?$", line, re.IGNORECASE)
        if ifm:
            cond = _convert_expr(ifm.group(1))
            lines_out.append(" " * current_indent + f"if {cond}:")
            current_indent += 4
            indent_stack.append(current_indent)
            # marker goes INSIDE the if block
            stmt_count += 1
            lines_out.append(" " * current_indent + f"_cov.add({stmt_count})")
            continue

        assign = re.match(r"^(\w[\w.]*)\s*:=\s*(.+?)\s*;?\s*$", line)
        if assign:
            lhs = _convert_varname(assign.group(1))
            rhs = _convert_expr(assign.group(2))
            stmt_count += 1
            lines_out.append(" " * current_indent + f"_cov.add({stmt_count})")
            lines_out.append(" " * current_indent + f"{lhs} = {rhs}")
            continue

        fb_line = _convert_fb_call(line)
        if fb_line:
            stmt_count += 1
            lines_out.append(" " * current_indent + f"_cov.add({stmt_count})")
            lines_out.append(" " * current_indent + fb_line)
            continue

        stmt_count += 1
        lines_out.append(" " * current_indent + f"_cov.add({stmt_count})")
        lines_out.append(" " * current_indent + f"pass  # unparsed: {line[:60]}")

    return "\n".join(lines_out), stmt_count


def run_test_cases_with_coverage(st_code: str, test_cases: list) -> tuple:
    """
    Execute test cases and measure statement coverage.

    Returns:
        (results: list, coverage_pct: float)  — coverage_pct is 0.0–1.0
    """
    try:
        py_code_cov, total_stmts = _st_to_python_covered(st_code)
    except Exception:
        return run_test_cases(st_code, test_cases), 0.0

    if total_stmts == 0:
        return run_test_cases(st_code, test_cases), 0.0

    declared_defaults = _parse_var_declarations(st_code)
    all_covered: set = set()
    results = []

    for tc in test_cases:
        tc_id    = tc.get("id", "?")
        inputs   = dict(tc.get("inputs", {}))
        expected = dict(tc.get("expected_outputs", {}))
        notes    = tc.get("notes", "")

        namespace: _AliasNamespace = _AliasNamespace({"_cov": set()})
        for name, val in declared_defaults.items():
            namespace[name] = val
        pre_state = dict(tc.get("pre_state", {}))
        namespace.update(pre_state)
        namespace.update(inputs)
        for m in re.finditer(r"(\w+)\.Q\s*=\s*(TRUE|FALSE)", notes, re.IGNORECASE):
            key = m.group(1) + "_Q"
            namespace[key] = (m.group(2).upper() == "TRUE")

        try:
            for _scan in range(3):
                exec(py_code_cov, {}, namespace)
            all_covered.update(namespace.get("_cov", set()))
        except Exception as e:
            results.append({
                "id": tc_id, "description": tc.get("description", ""),
                "passed": False, "error": str(e), "actual": {}, "expected": expected
            })
            continue

        actual = {k: namespace.get(k) for k in expected}
        passed = all(actual.get(k) == expected[k] for k in expected)
        results.append({
            "id": tc_id, "description": tc.get("description", ""),
            "passed": passed, "actual": actual, "expected": expected, "error": None
        })

    coverage_pct = round(len(all_covered) / total_stmts, 4)
    return results, coverage_pct


def compute_functional_correctness(test_results: list) -> float:
    """
    Return the fraction of test cases that passed (0.0 – 1.0).
    Returns -1.0 if no results.
    """
    if not test_results:
        return -1.0
    passed = sum(1 for r in test_results if r.get("passed", False))
    return round(passed / len(test_results), 4)


def format_test_report(test_results: list) -> str:
    """Return a human-readable test report string."""
    lines = []
    for r in test_results:
        symbol = "✓" if r["passed"] else "✗"
        lines.append(f"  [{symbol}] {r['id']}: {r.get('description','')}")
        if not r["passed"]:
            lines.append(f"        Expected : {r.get('expected')}")
            lines.append(f"        Actual   : {r.get('actual')}")
            if r.get("error"):
                lines.append(f"        Error    : {r['error']}")
    passed = sum(1 for r in test_results if r["passed"])
    lines.append(f"\n  Result: {passed}/{len(test_results)} passed")
    return "\n".join(lines)
