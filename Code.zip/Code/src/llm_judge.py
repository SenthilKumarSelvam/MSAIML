"""
Agent 1 — Spec Compliance Verifier
===================================
Uses an LLM judge (or deterministic fallback in MOCK mode) to verify that
every control_condition in the normalized requirement is implemented in the
generated ST code.

Replaces BLEU as the primary correctness metric because BLEU only measures
token overlap, not whether the specified *logic* is actually present.

Key outputs stored in the experiment log:
  spec_compliance_score    : float [0-1]  fraction of conditions met
  spec_compliance_detail   : list[dict]   per-condition verdict

Each verdict dict contains:
  condition   : str    the control_condition text from the spec
  priority    : str    high / medium / low
  verdict     : str    YES / PARTIAL / MISSING
  evidence    : str    quoted code fragment or explanation
  confidence  : float  0.0-1.0
"""

from __future__ import annotations
import json
import re
import config


# ─── Public entry point ───────────────────────────────────────────────────────

def check_spec_compliance(
    normalized_requirement: dict,
    generated_st_code: str,
    client=None,
) -> dict:
    """
    Evaluate how well generated_st_code satisfies every control_condition
    in normalized_requirement.

    Args:
        normalized_requirement: Task spec dict with 'control_conditions' list.
        generated_st_code:      The final compiled ST code string.
        client:                 OpenAI / Gemini client (may be None in MOCK mode).

    Returns:
        {
          "spec_compliance_score": float,
          "spec_compliance_detail": list[verdict_dict],
          "conditions_checked": int,
          "conditions_met": int,         # YES count
          "conditions_partial": int,     # PARTIAL count
          "conditions_missing": int,     # MISSING count
        }
    """
    conditions = normalized_requirement.get("control_conditions", [])
    if not conditions:
        return _empty_result("no control_conditions in spec")

    if config.MOCK_LLM or client is None:
        detail = _mock_judge(conditions, generated_st_code)
    else:
        try:
            detail = _llm_judge(conditions, generated_st_code, client)
        except Exception as exc:
            print(f"[SpecCompliance] LLM judge failed ({exc}), falling back to pattern check.")
            detail = _mock_judge(conditions, generated_st_code)

    yes     = sum(1 for d in detail if d["verdict"] == "YES")
    partial = sum(1 for d in detail if d["verdict"] == "PARTIAL")
    missing = sum(1 for d in detail if d["verdict"] == "MISSING")
    total   = len(detail)
    # Score: YES=1.0, PARTIAL=0.5, MISSING=0.0
    score   = round((yes + partial * 0.5) / total, 4) if total else 0.0

    return {
        "spec_compliance_score":   score,
        "spec_compliance_detail":  detail,
        "conditions_checked":      total,
        "conditions_met":          yes,
        "conditions_partial":      partial,
        "conditions_missing":      missing,
    }


# ─── LLM judge ────────────────────────────────────────────────────────────────

_JUDGE_SYSTEM = """\
You are a senior IEC 61131-3 PLC verification engineer.
You will be given a list of control conditions from a PLC specification and
a generated Structured Text (ST) program.
For EACH condition, determine whether the ST code implements it:

  YES     — fully and correctly implemented
  PARTIAL — partially implemented (e.g. condition present but safety fence missing,
             or only one branch of a multi-branch condition is covered)
  MISSING — not implemented at all

Respond ONLY with a valid JSON array. Each element must have:
  "condition"  : exact condition text
  "verdict"    : "YES" | "PARTIAL" | "MISSING"
  "evidence"   : short quote from the ST code proving your verdict, or "not found"
  "confidence" : float 0.0-1.0
"""

def _llm_judge(conditions: list, st_code: str, client) -> list[dict]:
    """Call the run-scoped LLM client to judge each condition."""
    conditions_block = "\n".join(
        f"{i+1}. [{c.get('priority','medium').upper()}] {c['condition']}"
        for i, c in enumerate(conditions)
    )
    user_prompt = (
        f"=== CONTROL CONDITIONS TO VERIFY ===\n{conditions_block}\n\n"
        f"=== GENERATED ST CODE ===\n{st_code}\n\n"
        "Return a JSON array with one verdict object per condition."
    )

    try:
        resp = client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[
                {"role": "system", "content": _JUDGE_SYSTEM},
                {"role": "user",   "content": user_prompt},
            ],
            temperature=0.1,
            response_format={"type": "json_object"},
            max_tokens=4096,
        )
    except Exception:
        # Some OpenAI-compatible backends do not support response_format.
        resp = client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[
                {"role": "system", "content": _JUDGE_SYSTEM},
                {"role": "user",   "content": user_prompt},
            ],
            temperature=0.1,
            max_tokens=4096,
        )
    raw = resp.choices[0].message.content.strip()

    # Parse JSON — the model may return a bare array OR {"results": [...]}
    parsed = json.loads(_strip_fences(raw))
    if isinstance(parsed, dict):
        # unwrap common wrappers
        for key in ("results", "conditions", "verdicts", "items"):
            if key in parsed and isinstance(parsed[key], list):
                parsed = parsed[key]
                break
        else:
            # try first list value
            for v in parsed.values():
                if isinstance(v, list):
                    parsed = v
                    break

    # Align parsed results back to original conditions (by index, robust to reordering)
    detail = []
    cond_texts = [c["condition"] for c in conditions]
    used = set()
    for cond_obj in conditions:
        ctext = cond_obj["condition"]
        # find best match in parsed by condition text similarity
        best = None
        for item in parsed:
            if isinstance(item, dict) and item.get("condition", "").strip() == ctext:
                best = item
                break
        if best is None:
            # try index-order fallback
            idx = cond_texts.index(ctext)
            if idx < len(parsed) and idx not in used:
                best = parsed[idx]
                used.add(idx)
        if best:
            detail.append({
                "condition":  ctext,
                "priority":   cond_obj.get("priority", "medium"),
                "verdict":    best.get("verdict", "MISSING").upper(),
                "evidence":   best.get("evidence", ""),
                "confidence": float(best.get("confidence", 0.5)),
            })
        else:
            detail.append({
                "condition":  ctext,
                "priority":   cond_obj.get("priority", "medium"),
                "verdict":    "MISSING",
                "evidence":   "no LLM verdict returned",
                "confidence": 0.0,
            })
    return detail


# ─── Mock / pattern-based judge (MOCK_LLM mode) ───────────────────────────────

def _mock_judge(conditions: list, st_code: str) -> list[dict]:
    """
    Deterministic pattern-based compliance check — no API call needed.

    Strategy:
      - Extract all UPPER_SNAKE_CASE identifiers and keywords from the condition.
      - Search for them in the ST code.
      - YES    : ≥80 % of identifiers found in the correct context
      - PARTIAL: 30-79 % found
      - MISSING: <30 % found
    """
    code_upper = st_code.upper()
    detail = []
    for cond_obj in conditions:
        ctext = cond_obj["condition"]
        priority = cond_obj.get("priority", "medium")

        # Extract identifiers from the condition text
        identifiers = re.findall(r"[A-Z][A-Z0-9_]{2,}", ctext.upper())
        # Filter out pure ST keywords that will always appear
        _ST_KEYWORDS = {
            "IF", "THEN", "ELSE", "END_IF", "AND", "OR", "NOT", "TRUE", "FALSE",
            "FOR", "TO", "DO", "END_FOR", "WHILE", "END_WHILE", "REPEAT",
            "UNTIL", "END_REPEAT", "VAR", "END_VAR", "BOOL", "INT", "REAL",
            "TIME", "TON", "TOF", "TP", "CTU", "CTD", "PROGRAM", "END_PROGRAM",
        }
        identifiers = [i for i in identifiers if i not in _ST_KEYWORDS]

        if not identifiers:
            # Condition is purely structural; check for key ST constructs
            has_if = "IF" in code_upper
            detail.append({
                "condition":  ctext,
                "priority":   priority,
                "verdict":    "YES" if has_if else "PARTIAL",
                "evidence":   "structural condition — keywords found" if has_if else "no IF block found",
                "confidence": 0.6,
            })
            continue

        found = [i for i in identifiers if i in code_upper]
        ratio = len(found) / len(identifiers)

        if ratio >= 0.8:
            verdict  = "YES"
            evidence = f"Found: {', '.join(found)}"
            conf     = 0.75
        elif ratio >= 0.3:
            missing_ids = [i for i in identifiers if i not in code_upper]
            verdict  = "PARTIAL"
            evidence = f"Found: {', '.join(found)}; Missing: {', '.join(missing_ids)}"
            conf     = 0.6
        else:
            verdict  = "MISSING"
            evidence = f"Not found: {', '.join(identifiers)}"
            conf     = 0.7

        detail.append({
            "condition":  ctext,
            "priority":   priority,
            "verdict":    verdict,
            "evidence":   evidence,
            "confidence": conf,
        })
    return detail


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _empty_result(reason: str) -> dict:
    return {
        "spec_compliance_score":  None,
        "spec_compliance_detail": [],
        "conditions_checked":     0,
        "conditions_met":         0,
        "conditions_partial":     0,
        "conditions_missing":     0,
        "_note":                  reason,
    }


def _strip_fences(text: str) -> str:
    """Remove ```json ... ``` wrappers from LLM output."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        # drop first (```json) and last (```) lines
        lines = lines[1:] if lines[0].startswith("```") else lines
        lines = lines[:-1] if lines and lines[-1].startswith("```") else lines
        text = "\n".join(lines)
    return text


def format_compliance_report(result: dict) -> str:
    """Human-readable one-line summary of compliance result."""
    if result["spec_compliance_score"] is None:
        return "[SpecCompliance] Skipped — " + result.get("_note", "")
    score = result["spec_compliance_score"]
    met  = result["conditions_met"]
    part = result["conditions_partial"]
    miss = result["conditions_missing"]
    total = result["conditions_checked"]
    bar = "█" * int(score * 20) + "░" * (20 - int(score * 20))
    return (
        f"[SpecCompliance] Score: {score:.0%}  [{bar}]\n"
        f"  ✓ YES={met}  ~ PARTIAL={part}  ✗ MISSING={miss}  / {total} conditions"
    )
