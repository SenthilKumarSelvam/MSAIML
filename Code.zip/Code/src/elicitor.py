"""
Requirement Elicitation Module
Presents domain-specific questions for each PLC scenario type and merges
the user's answers back into a richer normalized requirement dict that is
then passed to the LLM generator.
"""

from __future__ import annotations
import copy
from typing import Any


# ─── Question Bank ─────────────────────────────────────────────────────────
# Each scenario has a list of question-group dicts:
#   { id, label, type, options, default, hint, depends_on, depends_value }
# type: "number" | "select" | "multiselect" | "yesno" | "text"

QUESTION_BANK: dict[str, list[dict]] = {

    "conveyor": [
        # ── Step 1: System Overview ──────────────────────────────────────────
        {
            "step": 1, "id": "num_zones", "label": "How many conveyor zones are there?",
            "type": "number", "default": 3, "min": 1, "max": 8,
            "hint": "Each zone has its own belt motor.",
        },
        {
            "step": 1, "id": "belt_direction",
            "label": "Belt direction",
            "type": "select",
            "options": [
                {"value": "unidirectional", "label": "Unidirectional (forward only)"},
                {"value": "bidirectional",  "label": "Bidirectional (forward + reverse)"},
            ],
            "default": "unidirectional",
        },
        {
            "step": 1, "id": "product_type",
            "label": "What type of product is transported?",
            "type": "text", "default": "general goods",
            "hint": "E.g. boxes, bottles, metal parts…",
        },
        {
            "step": 1, "id": "handoff_mode",
            "label": "Zone handoff mode",
            "type": "select",
            "options": [
                {"value": "automatic", "label": "Automatic (exit sensor triggers next zone)"},
                {"value": "manual",    "label": "Manual (operator confirms handoff)"},
            ],
            "default": "automatic",
        },
        # ── Step 2: Sensors / Inputs ─────────────────────────────────────────
        {
            "step": 2, "id": "has_entry_sensor",
            "label": "Does each zone have a product entry sensor?",
            "type": "yesno", "default": True,
            "hint": "Proximity or photoelectric sensor detecting product arrival.",
        },
        {
            "step": 2, "id": "has_exit_sensor",
            "label": "Does each zone have a product exit sensor?",
            "type": "yesno", "default": True,
        },
        {
            "step": 2, "id": "has_jam_sensor",
            "label": "Does each zone have a jam / blockage sensor?",
            "type": "yesno", "default": True,
            "hint": "Detects when a product is stuck.",
        },
        {
            "step": 2, "id": "has_speed_sensor",
            "label": "Is there a belt speed (encoder) sensor per zone?",
            "type": "yesno", "default": False,
        },
        # ── Step 3: Outputs / Actuators ──────────────────────────────────────
        {
            "step": 3, "id": "has_master_stop",
            "label": "Is there a Master (Emergency) Stop button?",
            "type": "yesno", "default": True,
            "hint": "Single button that immediately halts all zones.",
        },
        {
            "step": 3, "id": "has_zone_alarm",
            "label": "Does each zone have a jam alarm output (light / buzzer)?",
            "type": "yesno", "default": True,
        },
        {
            "step": 3, "id": "has_speed_control",
            "label": "Is there variable speed control (VFD) per zone?",
            "type": "yesno", "default": False,
        },
        # ── Step 4: Safety / Interlocks ──────────────────────────────────────
        {
            "step": 4, "id": "jam_stops_all",
            "label": "Should a jam stop ALL zones or ONLY the jammed zone?",
            "type": "select",
            "options": [
                {"value": "zone_only", "label": "Only the jammed zone stops"},
                {"value": "all_zones", "label": "All zones stop on any jam"},
            ],
            "default": "zone_only",
        },
        {
            "step": 4, "id": "belt_start_delay",
            "label": "Startup delay between zones (seconds, 0 = no delay)",
            "type": "number", "default": 0, "min": 0, "max": 30,
            "hint": "Prevents simultaneous motor startup surge.",
        },
        {
            "step": 4, "id": "extra_interlocks",
            "label": "Any additional interlocks or safety requirements?",
            "type": "text", "default": "",
            "hint": "Free text — e.g. 'Belt C must not start unless loading dock door is closed'",
        },
    ],

    "motor_control": [
        {
            "step": 1, "id": "num_motors",
            "label": "How many motors does this program control?",
            "type": "number", "default": 1, "min": 1, "max": 8,
        },
        {
            "step": 1, "id": "motor_type",
            "label": "Motor starter type",
            "type": "select",
            "options": [
                {"value": "direct",     "label": "Direct On-Line (DOL)"},
                {"value": "star_delta", "label": "Star-Delta"},
                {"value": "vfd",        "label": "Variable Frequency Drive (VFD)"},
                {"value": "reversible", "label": "Reversible (FWD / REV)"},
            ],
            "default": "direct",
        },
        {
            "step": 1, "id": "start_stop_type",
            "label": "Start / Stop button type",
            "type": "select",
            "options": [
                {"value": "momentary",  "label": "Momentary (latching logic in PLC)"},
                {"value": "maintained", "label": "Maintained (held pressed = running)"},
            ],
            "default": "momentary",
        },
        {
            "step": 2, "id": "has_overload",
            "label": "Is there a motor overload / thermal protection input?",
            "type": "yesno", "default": True,
        },
        {
            "step": 2, "id": "has_run_feedback",
            "label": "Is there a 'motor running' feedback contact / auxiliary?",
            "type": "yesno", "default": False,
        },
        {
            "step": 2, "id": "auto_start_timer",
            "label": "Automatic restart delay after fault cleared (seconds, 0 = manual reset)",
            "type": "number", "default": 0, "min": 0, "max": 120,
        },
        {
            "step": 3, "id": "has_run_indicator",
            "label": "Output: Run indicator lamp?",
            "type": "yesno", "default": True,
        },
        {
            "step": 3, "id": "has_fault_indicator",
            "label": "Output: Fault indicator lamp?",
            "type": "yesno", "default": True,
        },
        {
            "step": 4, "id": "interlock_with",
            "label": "Interlocks: must another system be active before this motor starts?",
            "type": "text", "default": "",
            "hint": "E.g. 'Cooling fan must run before main motor starts'",
        },
        {
            "step": 4, "id": "extra_interlocks",
            "label": "Any additional safety or interlock requirements?",
            "type": "text", "default": "",
        },
    ],

    "tank_level": [
        {
            "step": 1, "id": "num_tanks",
            "label": "How many tanks are controlled?",
            "type": "number", "default": 1, "min": 1, "max": 4,
        },
        {
            "step": 1, "id": "fluid_type",
            "label": "What fluid / substance is stored?",
            "type": "text", "default": "water",
            "hint": "E.g. water, chemical, oil…",
        },
        {
            "step": 1, "id": "control_type",
            "label": "Level control strategy",
            "type": "select",
            "options": [
                {"value": "on_off",       "label": "On/Off (high/low setpoints)"},
                {"value": "proportional", "label": "Proportional (continuous level sensor)"},
            ],
            "default": "on_off",
        },
        {
            "step": 2, "id": "has_high_sensor",
            "label": "High-level sensor (float switch or level probe at max)?",
            "type": "yesno", "default": True,
        },
        {
            "step": 2, "id": "has_low_sensor",
            "label": "Low-level sensor (float switch or level probe at min)?",
            "type": "yesno", "default": True,
        },
        {
            "step": 2, "id": "has_overflow_sensor",
            "label": "Overflow / very-high-level emergency sensor?",
            "type": "yesno", "default": False,
        },
        {
            "step": 3, "id": "pump_type",
            "label": "Which pumps are controlled?",
            "type": "select",
            "options": [
                {"value": "inlet",      "label": "Inlet pump only (fill)"},
                {"value": "outlet",     "label": "Outlet pump only (drain)"},
                {"value": "both",       "label": "Both inlet and outlet pumps"},
            ],
            "default": "inlet",
        },
        {
            "step": 3, "id": "has_inlet_valve",
            "label": "Is there a motorised inlet valve (in addition to or instead of pump)?",
            "type": "yesno", "default": False,
        },
        {
            "step": 4, "id": "has_overflow_alarm",
            "label": "Overflow alarm output?",
            "type": "yesno", "default": True,
        },
        {
            "step": 4, "id": "has_empty_alarm",
            "label": "Tank-empty alarm output?",
            "type": "yesno", "default": False,
        },
        {
            "step": 4, "id": "extra_interlocks",
            "label": "Any additional interlocks or constraints?",
            "type": "text", "default": "",
            "hint": "E.g. 'Pump must not run dry when tank is empty'",
        },
    ],

    "batch_reactor": [
        {
            "step": 1, "id": "num_steps",
            "label": "How many recipe / batch steps are there?",
            "type": "number", "default": 4, "min": 2, "max": 10,
        },
        {
            "step": 1, "id": "has_temperature_control",
            "label": "Is there temperature control (heating / cooling)?",
            "type": "yesno", "default": True,
        },
        {
            "step": 1, "id": "has_agitator",
            "label": "Is there a mixing agitator?",
            "type": "yesno", "default": True,
        },
        {
            "step": 2, "id": "num_valves",
            "label": "How many process valves are there (ingredient inlets + drain)?",
            "type": "number", "default": 3, "min": 1, "max": 12,
        },
        {
            "step": 2, "id": "has_pressure_sensor",
            "label": "Is there a vessel pressure sensor?",
            "type": "yesno", "default": False,
        },
        {
            "step": 2, "id": "has_level_sensor",
            "label": "Is there a reactor level sensor?",
            "type": "yesno", "default": True,
        },
        {
            "step": 3, "id": "has_emergency_stop",
            "label": "Emergency stop / abort functionality?",
            "type": "yesno", "default": True,
        },
        {
            "step": 3, "id": "abort_action",
            "label": "On abort: what should happen?",
            "type": "select",
            "options": [
                {"value": "stop_all",  "label": "Stop all actuators immediately"},
                {"value": "safe_dump", "label": "Open drain valve and stop heater/agitator"},
            ],
            "default": "stop_all",
        },
        {
            "step": 4, "id": "extra_interlocks",
            "label": "Any additional safety interlocks?",
            "type": "text", "default": "",
            "hint": "E.g. 'Heater must not activate unless agitator is running'",
        },
    ],
}

STEP_LABELS = {
    1: "System Overview",
    2: "Sensors & Inputs",
    3: "Outputs & Actuators",
    4: "Safety & Interlocks",
}


def get_questions(scenario: str) -> list[dict]:
    """Return the ordered question list for a given scenario."""
    return QUESTION_BANK.get(scenario, [])


def get_steps(scenario: str) -> dict[int, list[dict]]:
    """Return questions grouped by step number."""
    questions = get_questions(scenario)
    steps: dict[int, list[dict]] = {}
    for q in questions:
        s = q["step"]
        steps.setdefault(s, []).append(q)
    return steps


# ─── Requirement Enricher ───────────────────────────────────────────────────

def enrich_requirement(task: dict, answers: dict[str, Any]) -> dict:
    """
    Merge elicited answers into the task's normalized_requirement.
    Returns a new task dict (original is not mutated).
    """
    task = copy.deepcopy(task)
    scenario = task.get("scenario", "")
    req = task.setdefault("normalized_requirement", {})

    if scenario == "conveyor":
        _enrich_conveyor(req, answers)
    elif scenario == "motor_control":
        _enrich_motor(req, answers)
    elif scenario == "tank_level":
        _enrich_tank(req, answers)
    elif scenario == "batch_reactor":
        _enrich_reactor(req, answers)

    # Append any free-text extra interlocks as safety constraints
    extra = (answers.get("extra_interlocks") or "").strip()
    if extra:
        req.setdefault("safety_constraints", []).append(extra)

    # Stamp the raw_requirement with a summary of elicited changes
    summary = _build_summary(scenario, answers)
    if summary:
        task["raw_requirement"] = task.get("raw_requirement", "") + "\n\n[Elicited details]\n" + summary

    return task


def _enrich_conveyor(req: dict, a: dict):
    num_zones   = int(a.get("num_zones", 3))
    has_entry   = _bool(a.get("has_entry_sensor", True))
    has_exit    = _bool(a.get("has_exit_sensor",  True))
    has_jam     = _bool(a.get("has_jam_sensor",   True))
    has_speed   = _bool(a.get("has_speed_sensor", False))
    master_stop = _bool(a.get("has_master_stop",  True))
    has_alarm   = _bool(a.get("has_zone_alarm",   True))
    jam_stops   = a.get("jam_stops_all", "zone_only")
    delay       = int(a.get("belt_start_delay", 0))
    direction   = a.get("belt_direction", "unidirectional")

    inputs, outputs, internals, conditions, safety = [], [], [], [], list(req.get("safety_constraints", []))

    zones = [chr(65 + i) for i in range(num_zones)]  # A, B, C, …

    for z in zones:
        if has_entry:
            inputs.append({"name": f"SENSOR_{z}_ENTRY", "type": "BOOL", "description": f"Product detected entering Zone {z}"})
        if has_exit:
            inputs.append({"name": f"SENSOR_{z}_EXIT",  "type": "BOOL", "description": f"Product leaving Zone {z}"})
        if has_jam:
            inputs.append({"name": f"JAM_{z}", "type": "BOOL", "description": f"Jam detected in Zone {z}"})
        if has_speed:
            inputs.append({"name": f"SPEED_{z}", "type": "INT", "description": f"Zone {z} belt speed encoder (rpm)"})

    if master_stop:
        inputs.append({"name": "MASTER_STOP", "type": "BOOL", "description": "Emergency master stop pushbutton"})

    for z in zones:
        outputs.append({"name": f"BELT_{z}", "type": "BOOL", "description": f"Zone {z} belt motor"})
        if direction == "bidirectional":
            outputs.append({"name": f"BELT_{z}_REV", "type": "BOOL", "description": f"Zone {z} belt reverse"})
        if has_alarm:
            outputs.append({"name": f"ALARM_{z}", "type": "BOOL", "description": f"Zone {z} jam alarm"})

    for z in zones:
        internals.append({"name": f"ZONE_{z}_ACTIVE", "type": "BOOL", "initial_value": "FALSE", "description": f"Zone {z} belt latch"})

    # Control conditions
    if master_stop:
        stop_body = "; ".join(f"ZONE_{z}_ACTIVE := FALSE" for z in zones)
        conditions.append({"condition": f"IF MASTER_STOP THEN {stop_body}", "priority": "high"})
        safety.append("MASTER_STOP must immediately stop all belt motors")

    for z in zones:
        if has_jam:
            if jam_stops == "all_zones":
                stop_body = "; ".join(f"ZONE_{z2}_ACTIVE := FALSE" for z2 in zones)
                conditions.append({"condition": f"IF JAM_{z} THEN {stop_body}; ALARM_{z} := TRUE", "priority": "high"})
                safety.append(f"Jam in Zone {z} stops ALL zones and raises ALARM_{z}")
            else:
                cond = f"IF JAM_{z} THEN ZONE_{z}_ACTIVE := FALSE"
                if has_alarm:
                    cond += f"; ALARM_{z} := TRUE"
                conditions.append({"condition": cond, "priority": "high"})
                safety.append(f"Jam in Zone {z} must stop only that zone and raise its alarm")

    if has_entry:
        entry_cond = f"IF SENSOR_A_ENTRY"
        if master_stop:
            entry_cond += " AND NOT MASTER_STOP"
        conditions.append({"condition": f"{entry_cond} THEN ZONE_A_ACTIVE := TRUE", "priority": "high"})

    for i in range(len(zones) - 1):
        z_curr = zones[i]; z_next = zones[i + 1]
        if has_exit:
            delay_note = f"  (* {delay}s startup delay *)" if delay else ""
            conditions.append({
                "condition": f"IF SENSOR_{z_curr}_EXIT THEN ZONE_{z_curr}_ACTIVE := FALSE; ZONE_{z_next}_ACTIVE := TRUE{delay_note}",
                "priority": "high"
            })

    if has_exit:
        last = zones[-1]
        conditions.append({"condition": f"IF SENSOR_{last}_EXIT THEN ZONE_{last}_ACTIVE := FALSE", "priority": "medium"})

    # Assign outputs from latches
    for z in zones:
        conditions.append({"condition": f"BELT_{z} := ZONE_{z}_ACTIVE", "priority": "low"})

    if delay > 0:
        safety.append(f"Zones must start with a {delay}-second delay between each to limit inrush current")

    safety.append("Belts must not run during active jam condition")

    req["inputs"]             = inputs
    req["outputs"]            = outputs
    req["internal_variables"] = internals
    req["control_conditions"] = conditions
    req["safety_constraints"] = list(dict.fromkeys(safety))  # deduplicate


def _enrich_motor(req: dict, a: dict):
    num         = int(a.get("num_motors", 1))
    mtype       = a.get("motor_type", "direct")
    overload    = _bool(a.get("has_overload", True))
    feedback    = _bool(a.get("has_run_feedback", False))
    run_lamp    = _bool(a.get("has_run_indicator", True))
    fault_lamp  = _bool(a.get("has_fault_indicator", True))
    interlock   = (a.get("interlock_with") or "").strip()

    inputs, outputs, safety = [], [], list(req.get("safety_constraints", []))

    for i in range(1, num + 1):
        sfx = f"_{i}" if num > 1 else ""
        inputs.append({"name": f"START{sfx}",  "type": "BOOL", "description": f"Motor{sfx} start pushbutton"})
        inputs.append({"name": f"STOP{sfx}",   "type": "BOOL", "description": f"Motor{sfx} stop pushbutton"})
        if overload:
            inputs.append({"name": f"OL{sfx}", "type": "BOOL", "description": f"Motor{sfx} overload contact (NC)"})
        if feedback:
            inputs.append({"name": f"RUN_FB{sfx}", "type": "BOOL", "description": f"Motor{sfx} auxiliary run feedback"})
        if mtype == "reversible":
            inputs.append({"name": f"FWD{sfx}", "type": "BOOL", "description": f"Motor{sfx} forward command"})
            inputs.append({"name": f"REV{sfx}", "type": "BOOL", "description": f"Motor{sfx} reverse command"})

        outputs.append({"name": f"MOTOR{sfx}",  "type": "BOOL", "description": f"Motor{sfx} contactor"})
        if mtype == "star_delta":
            outputs.append({"name": f"STAR{sfx}",  "type": "BOOL", "description": f"Motor{sfx} star contactor"})
            outputs.append({"name": f"DELTA{sfx}", "type": "BOOL", "description": f"Motor{sfx} delta contactor"})
        if mtype == "reversible":
            outputs.append({"name": f"MOTOR{sfx}_FWD", "type": "BOOL", "description": f"Motor{sfx} forward contactor"})
            outputs.append({"name": f"MOTOR{sfx}_REV", "type": "BOOL", "description": f"Motor{sfx} reverse contactor"})
        if run_lamp:
            outputs.append({"name": f"RUN_LAMP{sfx}", "type": "BOOL", "description": f"Motor{sfx} running indicator lamp"})
        if fault_lamp:
            outputs.append({"name": f"FAULT_LAMP{sfx}", "type": "BOOL", "description": f"Motor{sfx} fault indicator lamp"})

    if overload:
        safety.append("Motor must not start or must trip if overload contact is active")
    if mtype == "reversible":
        safety.append("Forward and reverse contactors must be hardware and software interlocked (never both ON)")
    if interlock:
        safety.append(f"Interlock: {interlock}")

    req["inputs"]             = inputs
    req["outputs"]            = outputs
    req["safety_constraints"] = list(dict.fromkeys(safety))


def _enrich_tank(req: dict, a: dict):
    num_tanks    = int(a.get("num_tanks", 1))
    high_sensor  = _bool(a.get("has_high_sensor",     True))
    low_sensor   = _bool(a.get("has_low_sensor",      True))
    overflow_s   = _bool(a.get("has_overflow_sensor", False))
    pump_type    = a.get("pump_type", "inlet")
    inlet_valve  = _bool(a.get("has_inlet_valve",     False))
    ovf_alarm    = _bool(a.get("has_overflow_alarm",  True))
    empty_alarm  = _bool(a.get("has_empty_alarm",     False))

    inputs, outputs, safety = [], [], list(req.get("safety_constraints", []))

    for i in range(1, num_tanks + 1):
        sfx = f"_{i}" if num_tanks > 1 else ""
        if high_sensor:
            inputs.append({"name": f"LEVEL_HIGH{sfx}", "type": "BOOL", "description": f"Tank{sfx} high-level switch"})
        if low_sensor:
            inputs.append({"name": f"LEVEL_LOW{sfx}",  "type": "BOOL", "description": f"Tank{sfx} low-level switch"})
        if overflow_s:
            inputs.append({"name": f"LEVEL_OVF{sfx}",  "type": "BOOL", "description": f"Tank{sfx} overflow emergency sensor"})

        if pump_type in ("inlet", "both"):
            outputs.append({"name": f"PUMP_IN{sfx}",  "type": "BOOL", "description": f"Tank{sfx} inlet pump"})
        if pump_type in ("outlet", "both"):
            outputs.append({"name": f"PUMP_OUT{sfx}", "type": "BOOL", "description": f"Tank{sfx} outlet pump"})
        if inlet_valve:
            outputs.append({"name": f"VALVE_IN{sfx}", "type": "BOOL", "description": f"Tank{sfx} inlet valve"})
        if ovf_alarm:
            outputs.append({"name": f"ALARM_OVF{sfx}", "type": "BOOL", "description": f"Tank{sfx} overflow alarm"})
        if empty_alarm:
            outputs.append({"name": f"ALARM_EMPTY{sfx}", "type": "BOOL", "description": f"Tank{sfx} empty alarm"})

    if overflow_s:
        safety.append("Override: inlet must close/stop immediately on overflow sensor")
    if pump_type in ("inlet", "both") and low_sensor:
        safety.append("Inlet pump must not run when tank is at low level and draining")

    req["inputs"]             = inputs
    req["outputs"]            = outputs
    req["safety_constraints"] = list(dict.fromkeys(safety))


def _enrich_reactor(req: dict, a: dict):
    steps    = int(a.get("num_steps",   4))
    temp     = _bool(a.get("has_temperature_control", True))
    agitator = _bool(a.get("has_agitator", True))
    valves   = int(a.get("num_valves",  3))
    pressure = _bool(a.get("has_pressure_sensor", False))
    e_stop   = _bool(a.get("has_emergency_stop",  True))
    abort    = a.get("abort_action", "stop_all")

    inputs, outputs, safety = [], [], list(req.get("safety_constraints", []))

    inputs.append({"name": "BATCH_START", "type": "BOOL", "description": "Start batch sequence"})
    inputs.append({"name": "BATCH_ABORT", "type": "BOOL", "description": "Abort / emergency stop"})
    if temp:
        inputs.append({"name": "TEMP_PV",    "type": "REAL", "description": "Reactor temperature (°C)"})
        inputs.append({"name": "TEMP_SP",    "type": "REAL", "description": "Temperature setpoint (°C)"})
    if pressure:
        inputs.append({"name": "PRESSURE_PV", "type": "REAL", "description": "Reactor pressure (bar)"})
    inputs.append({"name": "LEVEL_HIGH", "type": "BOOL", "description": "Reactor high-level sensor"})

    for v in range(1, valves + 1):
        inputs.append({"name": f"VALVE_{v}_FB", "type": "BOOL", "description": f"Valve {v} position feedback"})
        outputs.append({"name": f"VALVE_{v}", "type": "BOOL", "description": f"Valve {v} open command"})

    if temp:
        outputs.append({"name": "HEATER",  "type": "BOOL", "description": "Heating element"})
        outputs.append({"name": "COOLER",  "type": "BOOL", "description": "Cooling water valve"})
    if agitator:
        outputs.append({"name": "AGITATOR", "type": "BOOL", "description": "Mixing agitator motor"})

    outputs.append({"name": "BATCH_RUNNING", "type": "BOOL", "description": "Batch in progress indicator"})
    outputs.append({"name": "BATCH_DONE",    "type": "BOOL", "description": "Batch complete signal"})
    outputs.append({"name": "ALARM_FAULT",   "type": "BOOL", "description": "Batch fault alarm"})

    req["inputs"]  = inputs
    req["outputs"] = outputs

    if agitator and temp:
        safety.append("Heater must not activate unless agitator is running")
    if e_stop:
        if abort == "safe_dump":
            safety.append("On ABORT: open drain valve, stop heater and agitator immediately")
        else:
            safety.append("On ABORT: stop all actuators and close all valves immediately")
    if pressure:
        safety.append("If pressure exceeds safe limit, abort batch and open vent valve")

    req["safety_constraints"] = list(dict.fromkeys(safety))


def _bool(val) -> bool:
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        return val.lower() in ("true", "1", "yes", "on")
    return bool(val)


def _build_summary(scenario: str, answers: dict) -> str:
    lines = []
    for k, v in answers.items():
        if v not in (None, "", False):
            lines.append(f"  - {k}: {v}")
    return "\n".join(lines)
