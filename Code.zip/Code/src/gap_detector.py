"""
Agent 3 — Requirements Gap Detector
======================================
Runs BEFORE Phase 2 (code generation). Compares the raw industrial
requirement text against the normalized/pre-validated spec and
detects concepts that were dropped, renamed, or absent from the spec.

The detected gaps are injected into the LLM code-generation prompt
so the LLM can compensate for normalization losses.

Key outputs:
  gap_report        : dict   — structured gap analysis
  gap_prompt_block  : str    — text block to inject into generation prompt
  gaps_detected     : int    — total number of gaps found
"""

from __future__ import annotations
import re
import json
import config

# ─── Gap categories ───────────────────────────────────────────────────────────

# Domain keyword patterns → what should appear in the spec if present
_DOMAIN_PATTERNS = [
    # Safety
    ("E-STOP / Emergency Stop",         r"\b(e.?stop|emergency.?stop|safety.?stop)\b",
     ["E_STOP", "ESTOP", "EMERGENCY"]),
    ("Overload protection",             r"\b(overload|overcurrent|ol.?relay|thermal)\b",
     ["OVERLOAD", "OL", "OL_FAULT"]),
    ("Limit switch",                    r"\b(limit.?switch|lsp|lsn|end.?stop)\b",
     ["LSP", "LSN", "LIMIT"]),
    # Sequence / State
    ("Start / Run command",             r"\b(start.?(button|pb|switch)|run.?command)\b",
     ["START", "START_PB", "RUN"]),
    ("Stop command",                    r"\b(stop.?(button|pb|switch)|stop.?command)\b",
     ["STOP", "STOP_PB"]),
    ("Auto / Manual mode",              r"\b(auto|manual|mode.?select)\b",
     ["AUTO", "MANUAL", "MODE"]),
    # Timing
    ("Timer / Delay",                   r"\b(timer|delay|time.?out|on.?delay|off.?delay)\b",
     ["TON", "TOF", "TP", "TIMER", "DELAY"]),
    ("Debounce / One-shot",             r"\b(debounce|one.?shot|pulse)\b",
     ["R_TRIG", "F_TRIG", "TP"]),
    # Counting / Batching
    ("Counter / Batch",                 r"\b(counter|count|batch|cycle.?count)\b",
     ["CTU", "CTD", "COUNTER", "COUNT"]),
    # Alarm / Fault
    ("Alarm / Fault output",            r"\b(alarm|fault|error|warning|alert)\b",
     ["ALARM", "FAULT", "ERROR", "ALERT"]),
    # Motor / Actuator
    ("Motor direction / Reversing",     r"\b(reverse|forward|direction|motor.?dir)\b",
     ["REVERSE", "FORWARD", "FWD", "REV"]),
    ("Speed / VFD",                     r"\b(speed|vfd|frequency|rpm|hz)\b",
     ["SPEED", "VFD", "FREQ"]),
    # Level / Flow / Pressure
    ("Level control",                   r"\b(level|liquid|tank|vessel|high.?level|low.?level)\b",
     ["LEVEL", "HH", "LL", "LT", "LEVEL_HIGH", "LEVEL_LOW"]),
    ("Temperature control",             r"\b(temperature|temp|thermostat|setpoint|pid)\b",
     ["TEMP", "SETPOINT", "PV", "SP", "PID"]),
    ("Pressure",                        r"\b(pressure|psi|bar|pressure.?switch)\b",
     ["PRESSURE", "PSH", "PSL"]),
    # Interlock patterns
    ("Zone / Collision interlock",      r"\b(zone|occupied|interlock|collision|block)\b",
     ["ZONE", "OCCUPIED", "INTERLOCK"]),
    ("Jam / Blockage detection",        r"\b(jam|blockage|stuck|jammed)\b",
     ["JAM", "BLOCKED", "STUCK"]),
    # Conveyor
    ("Conveyor motor",                  r"\b(conveyor|belt|zone.?motor)\b",
     ["MOTOR", "ZONE", "BELT"]),
]


# ─── Public entry point ───────────────────────────────────────────────────────

def detect_requirement_gaps(
    raw_requirement: str,
    normalized_requirement: dict,
) -> dict:
    """
    Compare raw requirement against normalized spec and find gaps.

    Args:
        raw_requirement:       Raw informal text of the requirement.
        normalized_requirement: The pre-validated spec dict.

    Returns:
        {
          "gaps_detected":    int,
          "gap_report":       list[dict],   one entry per detected gap
          "gap_prompt_block": str,          text to inject into generation prompt
        }
    """
    if not raw_requirement or not raw_requirement.strip():
        return {"gaps_detected": 0, "gap_report": [], "gap_prompt_block": ""}

    raw_lower = raw_requirement.lower()

    # Collect all declared variable names (upper-case) from spec
    spec_vars = set()
    for section in ("inputs", "outputs", "internal_variables"):
        for v in normalized_requirement.get(section, []):
            spec_vars.add(v["name"].upper())

    # Collect all text appearing in spec
    spec_text = " ".join([
        str(normalized_requirement.get("description", "")),
        str(normalized_requirement.get("safety_constraints", "")),
        str(normalized_requirement.get("interlocks", "")),
        " ".join(cc["condition"] for cc in normalized_requirement.get("control_conditions", [])),
    ]).upper()

    gap_report = []

    for label, pattern, expected_vars in _DOMAIN_PATTERNS:
        if not re.search(pattern, raw_lower, re.IGNORECASE):
            continue  # concept not in raw req — skip
        # Concept IS mentioned — check if it made it into the spec
        found_in_spec = any(
            ev in spec_vars or ev in spec_text
            for ev in expected_vars
        )
        if not found_in_spec:
            # Extract the matching context snippet from raw req
            m = re.search(pattern, raw_requirement, re.IGNORECASE)
            snippet = m.group(0) if m else "?"
            gap_report.append({
                "concept":         label,
                "raw_snippet":     snippet,
                "expected_vars":   expected_vars,
                "severity":        _severity(label),
            })

    # Also check explicit variable names mentioned in raw text in UPPER_SNAKE_CASE
    # that look like PLC variables but are absent from the spec
    raw_candidate_vars = set(re.findall(r"\b[A-Z][A-Z0-9_]{2,}\b", raw_requirement))
    _ST_KEYWORDS = {
        "IF", "THEN", "ELSE", "END", "END_IF", "AND", "OR", "NOT",
        "TRUE", "FALSE", "FOR", "DO", "TO", "WHILE", "REPEAT", "UNTIL",
        "VAR", "BOOL", "INT", "REAL", "TIME", "TON", "TOF", "TP",
        "CTU", "CTD", "PROGRAM", "BEGIN", "END_VAR", "END_PROGRAM",
        "HIGH", "LOW", "START", "STOP", "RUN",
    }
    for vname in sorted(raw_candidate_vars - _ST_KEYWORDS):
        if len(vname) >= 4 and vname not in spec_vars:
            gap_report.append({
                "concept":       f"Variable '{vname}' mentioned in raw req",
                "raw_snippet":   vname,
                "expected_vars": [vname],
                "severity":      "medium",
            })

    # Build injection block for the LLM prompt
    gap_prompt_block = _build_gap_prompt_block(gap_report, raw_requirement)

    return {
        "gaps_detected":    len(gap_report),
        "gap_report":       gap_report,
        "gap_prompt_block": gap_prompt_block,
    }


# ─── Prompt block builder ─────────────────────────────────────────────────────

def _build_gap_prompt_block(gap_report: list, raw_requirement: str) -> str:
    """
    Build the text block that gets injected into the generation prompt.
    Tells the LLM which concepts are missing from the spec so it can
    infer and implement them anyway.
    """
    if not gap_report:
        return ""

    high_gaps   = [g for g in gap_report if g["severity"] == "high"]
    medium_gaps = [g for g in gap_report if g["severity"] == "medium"]

    lines = [
        "",
        "─── REQUIREMENTS GAP ALERT (Agent 3) ────────────────────────────",
        "The normalized spec may be INCOMPLETE. The following concepts",
        "appear in the original requirement but are MISSING from the spec.",
        "You MUST implement these — infer appropriate variable names if needed.",
        "",
    ]
    if high_gaps:
        lines.append("CRITICAL GAPS (must implement):")
        for g in high_gaps:
            lines.append(f"  ! {g['concept']}")
            lines.append(f"    → raw text: \"{g['raw_snippet']}\"")
            lines.append(f"    → suggested variable names: {', '.join(g['expected_vars'])}")
    if medium_gaps:
        lines.append("PROBABLE GAPS (implement if applicable):")
        for g in medium_gaps[:8]:   # cap to avoid prompt bloat
            lines.append(f"  ~ {g['concept']}")
            lines.append(f"    → suggested: {', '.join(g['expected_vars'])}")
    lines.append("─────────────────────────────────────────────────────────")
    return "\n".join(lines)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _severity(label: str) -> str:
    _high = {"E-STOP", "Overload", "Limit", "Alarm", "Fault"}
    if any(h.lower() in label.lower() for h in _high):
        return "high"
    return "medium"


def format_gap_summary(gap_result: dict) -> str:
    """Human-readable one-liner for pipeline output."""
    n = gap_result.get("gaps_detected", 0)
    if n == 0:
        return "[Agent 3] No spec gaps detected — raw requirement fully captured."
    high = sum(1 for g in gap_result.get("gap_report", []) if g["severity"] == "high")
    return (
        f"[Agent 3] {n} spec gap(s) detected "
        f"({high} critical) — injecting into generation prompt."
    )
