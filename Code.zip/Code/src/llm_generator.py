"""
Phase 2: LLM-Assisted Structured Text (ST) Code Generation
Uses OpenAI GPT-4 with controlled prompt templates to generate 
IEC 61131-3 Structured Text programs from normalized requirements.
"""

import re
import time
import openai
from pathlib import Path
from prompts.templates import load_template


def _is_openrouter_credit_error(exc: Exception) -> bool:
    """Detect OpenRouter-style low-credit errors exposed via APIStatusError 402."""
    text = str(exc)
    return (
        "Error code: 402" in text
        or "requires more credits" in text.lower()
        or "can only afford" in text.lower()
    )


def _affordable_tokens_from_error(exc: Exception) -> int | None:
    """Extract "can only afford N" token budget from provider error text."""
    text = str(exc)
    m = re.search(r"can only afford\s+(\d+)", text, flags=re.IGNORECASE)
    if not m:
        return None
    try:
        return int(m.group(1))
    except Exception:
        return None


# ─── Mock generator (used when MOCK_LLM=true or API quota is exhausted) ──────

def _mock_generate(normalized_req_str: str, prompt_style: str, reference_st: str = "", task_spec: dict = None) -> dict:
    """
    Return the reference ST code when available (pipeline smoke-test with valid logic).
    When no reference exists, derive a real working ST program by parsing the
    format_for_prompt output sections (INPUTS / OUTPUTS / INTERNAL VARIABLES /
    CONTROL CONDITIONS) and emitting proper IEC 61131-3 syntax.

    task_spec: optional raw task dict (with 'inputs' / 'outputs' lists) used as
               a fallback when text parsing finds no variables (e.g. plain raw text).
    """
    if reference_st and reference_st.strip():
        print("[Generator] MOCK mode — using reference_st_code as generated output.")
        return {
            "code": reference_st.strip(),
            "prompt_style": prompt_style,
            "model": "mock-reference",
            "raw_response": "[MOCK] Used task reference_st_code."
        }

    # ── Parse format_for_prompt output ───────────────────────────────────────
    # Sections look like:
    #   INPUTS:\n  - NAME : TYPE  // desc
    #   INTERNAL VARIABLES:\n  - NAME : TYPE := INIT  // desc
    #   CONTROL CONDITIONS:\n  [PRIORITY] <stmt>
    inputs: list    = []   # (name, type)
    outputs: list   = []   # (name, type)
    internals: list = []   # (name, type, initial_value)
    conditions: list = []  # raw condition strings

    current_section: str | None = None
    var_re  = re.compile(r"-\s+([A-Za-z_]\w*)\s*:\s*(\w+)(?:\s*:=\s*(\S+))?")
    cond_re = re.compile(r"\[(?:HIGH|MEDIUM|LOW)\]\s+(.+)", re.IGNORECASE)

    for raw_line in normalized_req_str.splitlines():
        stripped = raw_line.strip()
        # Detect section headers
        if stripped == "INPUTS:":
            current_section = "inputs"
        elif stripped == "OUTPUTS:":
            current_section = "outputs"
        elif stripped in ("INTERNAL VARIABLES:", "INTERNAL_VARIABLES:"):
            current_section = "internals"
        elif stripped == "CONTROL CONDITIONS:":
            current_section = "conditions"
        elif stripped == "SAFETY CONSTRAINTS:":
            current_section = "safety"
        elif stripped.startswith("-") and current_section in ("inputs", "outputs", "internals"):
            m = var_re.search(stripped)
            if m:
                name, dtype, init = m.group(1), m.group(2).upper(), m.group(3)
                if current_section == "inputs":
                    inputs.append((name, dtype))
                elif current_section == "outputs":
                    outputs.append((name, dtype))
                else:
                    init = init or ("FALSE" if dtype == "BOOL" else "0")
                    internals.append((name, dtype, init))
        elif stripped.startswith("[") and current_section == "conditions":
            m = cond_re.match(stripped)
            if m:
                conditions.append(m.group(1).strip())

    # ── Fallback: if text parsing found no variables, use task_spec dict ───────
    if not inputs and not outputs and task_spec:
        inputs  = [(v['name'], v.get('type', 'BOOL').upper()) for v in task_spec.get('inputs', [])]
        outputs = [(v['name'], v.get('type', 'BOOL').upper()) for v in task_spec.get('outputs', [])]
        print("[Generator] MOCK mode — using task_spec I/O (text parsing found no variables).")

    # ── Build VAR block ───────────────────────────────────────────────────────
    var_lines = []
    for n, t in inputs:
        var_lines.append(f"  {n} : {t}; (* input *)")
    for n, t in outputs:
        var_lines.append(f"  {n} : {t}; (* output *)")
    for n, t, iv in internals:
        var_lines.append(f"  {n} : {t} := {iv};")
    if not var_lines:
        var_lines = ["  (* TODO: declare variables *)"]

    # ── Build logic from control conditions ──────────────────────────────────
    def _wrap_stmt(stmt: str) -> str:
        """
        Ensure IF...THEN statements are expanded to multi-line format so that
        the test runner's transpiler regex (IF ... THEN at end-of-line) can
        match them properly.  Plain assignments just get a trailing semicolon.
        """
        s = stmt.rstrip("; \t")
        upper = s.upper()
        if upper.startswith("IF ") and " THEN " in upper and "END_IF" not in upper:
            # Split "IF cond THEN body" → proper multi-line block
            then_idx = upper.index(" THEN ")
            cond_part = s[:then_idx]          # "IF cond"
            body_part = s[then_idx + 6:].strip()  # body after THEN
            return f"{cond_part} THEN\n    {body_part};\n  END_IF;"
        # Plain assignment or already multi-line
        return s + ";"

    logic_lines = ["  " + _wrap_stmt(c) for c in conditions]
    if not logic_lines:
        # Auto-derive simple assignment logic from outputs using inputs
        for n, t in outputs:
            if t == "BOOL" and inputs:
                logic_lines.append(f"  {n} := {inputs[0][0]};")
            elif t in ("INT", "DINT"):
                logic_lines.append(f"  {n} := 0;")
            else:
                logic_lines.append(f"  {n} := FALSE;")

    code = (
        "PROGRAM GeneratedProgram\nVAR\n"
        + "\n".join(var_lines) + "\n"
        "END_VAR\n\n"
        + "\n".join(logic_lines) + "\n"
        "END_PROGRAM\n"
    )
    print("[Generator] MOCK mode — derived ST from normalized requirement spec.")
    return {
        "code": code,
        "prompt_style": prompt_style,
        "model": "mock-derived",
        "raw_response": "[MOCK] Generated from normalized requirement (no API call)."
    }


def generate_st_code(
    normalized_req_str: str,
    client: openai.OpenAI,
    model: str = "gpt-4",
    prompt_style: str = "standard",
    reference_st: str = "",
    rag_context: str = "",
    task_spec: dict = None,
) -> dict:
    """
    Generate IEC 61131-3 Structured Text code from a normalized requirement.

    Args:
        normalized_req_str: Formatted requirement string from normalizer.format_for_prompt().
        client: Authenticated OpenAI client.
        model: LLM model to use.
        prompt_style: One of 'standard', 'chain_of_thought', 'program_of_thought'.

    Returns:
        Dictionary with 'code', 'prompt_style', 'model', and 'raw_response'.
    """
    # Allow running without API credits
    import config as _cfg  # local import to avoid circular
    if _cfg.MOCK_LLM or client is None:
        print("[Generator] MOCK mode — skipping API call, returning stub ST code.")
        return _mock_generate(normalized_req_str, prompt_style, reference_st, task_spec=task_spec)

    template = load_template(f"generation_{prompt_style}.txt")
    rag_block = ""
    if rag_context and rag_context.strip():
        # Format RAG context as few-shot examples with clear structure
        rag_lines = [
            "",
            "=== SIMILAR SOLVED EXAMPLES (reference patterns, do NOT copy variable names) ===",
            "The following similar tasks have been successfully implemented.",
            "Study their control logic structure and pattern, but use ONLY the variable names",
            "from the current requirement specification.",
            ""
        ]
        rag_lines.append(rag_context.strip())
        rag_lines.append("=== END EXAMPLES ===")
        rag_lines.append("")
        rag_block = "\n".join(rag_lines)
    prompt = template.format(requirement=normalized_req_str, rag_context=rag_block)

    max_attempts = max(1, int(getattr(_cfg, "LLM_MAX_RETRIES", 4)))
    timeout_seconds = float(getattr(_cfg, "LLM_REQUEST_TIMEOUT_SECONDS", 900))
    max_output_tokens = max(256, int(getattr(_cfg, "LLM_GENERATION_MAX_TOKENS", 3072)))
    min_output_tokens = max(128, int(getattr(_cfg, "LLM_GENERATION_MIN_TOKENS", 512)))
    
    rag_chars = len(rag_context or "")
    prompt_chars = len(prompt)

    print(
        f"[Generator] Calling model={model} style={prompt_style} "
        f"timeout={timeout_seconds:.0f}s retries={max_attempts} "
        f"prompt_chars={prompt_chars} rag_chars={rag_chars}"
    )

    try:
        response = None
        token_budget = max_output_tokens
        for attempt in range(1, max_attempts + 1):
            try:
                t0 = time.time()
                print(
                    f"[Generator] Attempt {attempt}/{max_attempts}... "
                    f"(max_tokens={token_budget})"
                )
                response = client.chat.completions.create(
                    model=model,
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are a senior IEC 61131-3 PLC software engineer with 20 years of experience "
                                "designing safety-critical industrial automation systems. "
                                "You follow IEC 61131-3 syntax precisely and always apply fail-safe design: "
                                "E-STOP or any safety interlock must de-energise ALL outputs immediately as the "
                                "FIRST action in every program, before any operational logic. "
                                "You implement EVERY control condition stated in the specification using the "
                                "EXACT variable names provided. You never invent new variable names. "
                                "Treat retrieved examples and any prior patterns as control-logic reference only; "
                                "never reuse their identifier names. Identifier set is strictly limited to variables "
                                "declared in the current requirement. "
                                "For conveyor/motor control you always implement collision-prevention interlocks "
                                "(upstream motor stops when downstream zone is occupied) and jam inhibits."
                            )
                        },
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.15,
                    max_tokens=token_budget,
                    timeout=timeout_seconds,
                )
                elapsed = time.time() - t0
                print(f"[Generator] Response received in {elapsed:.1f}s (finish_reason={response.choices[0].finish_reason}).")
                break
            except (openai.APITimeoutError, openai.APIConnectionError) as net_err:
                if attempt >= max_attempts:
                    raise
                backoff = min(2 ** (attempt - 1), 8)
                print(
                    f"[Generator] Network timeout/connection issue (attempt {attempt}/{max_attempts}): {net_err}. "
                    f"Retrying in {backoff}s..."
                )
                time.sleep(backoff)
            except (openai.InternalServerError, openai.RateLimitError) as transient_err:
                # Gemini's free tier (via the OpenAI-compatible endpoint) returns
                # transient 503 UNAVAILABLE / 429 RESOURCE_EXHAUSTED under load.
                # Retry those with backoff; a genuine quota error still raises below.
                msg = str(transient_err)
                if "insufficient_quota" in msg or attempt >= max_attempts:
                    raise
                backoff = min(2 ** (attempt - 1), 8)
                print(
                    f"[Generator] Transient server/rate error (attempt {attempt}/{max_attempts}): {msg[:120]}. "
                    f"Retrying in {backoff}s..."
                )
                time.sleep(backoff)
            except openai.APIStatusError as status_err:
                if _is_openrouter_credit_error(status_err):
                    affordable = _affordable_tokens_from_error(status_err)
                    next_budget = affordable if affordable is not None else (token_budget // 2)
                    next_budget = max(min_output_tokens, min(next_budget, token_budget - 128))
                    if next_budget < token_budget and attempt < max_attempts:
                        print(
                            "[Generator] Provider credit limit hit; reducing max_tokens "
                            f"{token_budget} -> {next_budget} and retrying..."
                        )
                        token_budget = next_budget
                        continue
                raise

        if response is None:
            raise RuntimeError("Generation failed: no response after retries.")
    except openai.RateLimitError as e:
        if "insufficient_quota" in str(e):
            print(
                "[Generator] ERROR: OpenAI quota exhausted.\n"
                "  → Add credits at https://platform.openai.com/settings/billing\n"
                "  → OR set MOCK_LLM=true in .env to run without API calls."
            )
        else:
            print(f"[Generator] Rate limit hit, retrying is needed: {e}")
        raise
    except openai.AuthenticationError:
        print(
            "[Generator] ERROR: Invalid API key.\n"
            "  → Check OPENAI_API_KEY in your .env file."
        )
        raise

    msg_content = response.choices[0].message.content
    finish_reason = response.choices[0].finish_reason
    
    # Check for token limit reached (finish_reason='length' means output was truncated)
    if finish_reason == "length":
        print(
            f"[Generator] WARNING: Output truncated (finish_reason='length'). "
            f"Response may be incomplete. Trying to extract partial code..."
        )
    
    # Thinking models (Gemini 2.5-pro) can return content=None when the entire
    # output budget was consumed by internal reasoning.  Retry once with a
    # doubled budget before giving up.
    if msg_content is None and finish_reason == "length":
        retry_budget = min(token_budget * 2, 65536)
        print(
            f"[Generator] content=None with finish_reason='length' — thinking model "
            f"likely used all tokens for reasoning. Retrying with max_tokens={retry_budget}..."
        )
        try:
            t0 = time.time()
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are a senior IEC 61131-3 PLC software engineer with 20 years of experience "
                            "designing safety-critical industrial automation systems. "
                            "You follow IEC 61131-3 syntax precisely and always apply fail-safe design: "
                            "E-STOP or any safety interlock must de-energise ALL outputs immediately as the "
                            "FIRST action in every program, before any operational logic. "
                            "You implement EVERY control condition stated in the specification using the "
                            "EXACT variable names provided. You never invent new variable names. "
                            "Treat retrieved examples and any prior patterns as control-logic reference only; "
                            "never reuse their identifier names. Identifier set is strictly limited to variables "
                            "declared in the current requirement. "
                            "For conveyor/motor control you always implement collision-prevention interlocks "
                            "(upstream motor stops when downstream zone is occupied) and jam inhibits."
                        )
                    },
                    {"role": "user", "content": prompt}
                ],
                temperature=0.15,
                max_tokens=retry_budget,
                timeout=timeout_seconds,
            )
            elapsed = time.time() - t0
            msg_content = response.choices[0].message.content
            finish_reason = response.choices[0].finish_reason
            print(f"[Generator] Retry response in {elapsed:.1f}s (finish_reason={finish_reason}).")
        except Exception as retry_err:
            print(f"[Generator] Retry with higher budget failed: {retry_err}")
    
    if msg_content is None:
        raise RuntimeError(
            f"LLM returned empty response (finish_reason={finish_reason}). "
            f"Choices: {response.choices}. "
            f"Try increasing LLM_GENERATION_MAX_TOKENS or disabling RAG."
        )
    
    raw = msg_content.strip() if isinstance(msg_content, str) else str(msg_content).strip()
    code = _sanitize_generated_st(_extract_code_block(raw))

    # ── Completeness check: if END_PROGRAM is missing the LLM truncated the
    # output (common with CoT/PoT prompts that spend tokens on analysis first).
    # Make one focused completion call to finish the program.
    if "END_PROGRAM" not in code.upper():
        print(
            f"[Generator] WARNING: Generated code is missing END_PROGRAM "
            f"(likely truncated). Requesting completion..."
        )
        completion_prompt = (
            "The following IEC 61131-3 Structured Text program is INCOMPLETE "
            "(it was cut off before END_PROGRAM). "
            "Continue the program EXACTLY from where it was cut off. "
            "Do NOT repeat any code already shown. "
            "Write ONLY the remaining ST code lines (starting from where the "
            "truncation happened) through to END_PROGRAM.\n\n"
            f"--- INCOMPLETE PROGRAM SO FAR ---\n{code}\n--- END OF INCOMPLETE PART ---"
        )
        try:
            completion_response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": (
                        "You are an IEC 61131-3 PLC software engineer. "
                        "Complete the truncated ST program exactly as instructed."
                    )},
                    {"role": "user", "content": completion_prompt},
                ],
                temperature=0.1,
                max_tokens=token_budget,
                timeout=timeout_seconds,
            )
            completion_text = completion_response.choices[0].message.content or ""
            # The completion is raw ST continuation — no code fence expected
            continuation = _sanitize_generated_st(_extract_code_block(completion_text.strip()))
            code = code.rstrip() + "\n" + continuation
            print(f"[Generator] Completion added {len(continuation.splitlines())} lines.")
        except Exception as comp_err:
            print(f"[Generator] Completion call failed: {comp_err}. Using truncated code.")

    return {
        "code": code,
        "prompt_style": prompt_style,
        "model": model,
        "raw_response": raw
    }


def _extract_code_block(text: str) -> str:
    """
    Strip markdown code fences from LLM output if present.
    
    Args:
        text: Raw LLM response string.
        
    Returns:
        Clean code string.
    """
    if text is None:
        return ""
    text = str(text).strip()
    if "```" in text:
        parts = text.split("```")
        # The code is typically in parts[1]
        code = parts[1]
        # Remove language hint if any (e.g., "st\n" or "iecst\n")
        if "\n" in code:
            first_line, rest = code.split("\n", 1)
            if first_line.strip().lower() in ("st", "iecst", "structured_text", "text"):
                return rest.strip()
        return code.strip()
    return text.strip()


def _sanitize_generated_st(code: str) -> str:
    """
    Remove obvious non-ST artifacts and normalize common token mistakes.
    """
    cleaned_lines = []
    for line in code.splitlines():
        s = line.strip()
        u = s.upper()
        # Drop heading-like pseudo-code lines that are not ST syntax.
        if u.startswith("LAYER ") or u.startswith("PHASE "):
            continue
        cleaned_lines.append(line)

    out = "\n".join(cleaned_lines)
    # Normalize invalid token sequence often emitted by LLMs.
    out = re.sub(r"\bELSE\s+IF\b", "ELSIF", out, flags=re.IGNORECASE)
    return out.strip()


def save_generated_code(code: str, output_path: str) -> None:
    """
    Save generated ST code to a .st file.
    
    Args:
        code: The Structured Text program string.
        output_path: Destination file path.
    """
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(code, encoding="utf-8")
    print(f"[Generator] Saved ST code to {output_path}")
