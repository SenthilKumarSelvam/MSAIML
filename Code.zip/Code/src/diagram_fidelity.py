"""
Agent 4 — Diagram Fidelity Verifier
=====================================
After the vision model extracts a structured spec from a workflow diagram image,
this agent re-reads the image and the extracted spec side-by-side and checks
whether every element visible in the diagram was captured correctly.

This catches silent extraction failures BEFORE code generation starts, allowing
the user to correct the spec rather than discover the gap after a failed evaluation.

Key outputs returned alongside the extracted spec:
  fidelity_score         : float [0-1]
  fidelity_verdict       : str   "good" | "acceptable" | "poor"
  missed_elements        : list[str]   elements visible in diagram but not in spec
  ambiguous_elements     : list[str]   elements that might be misinterpreted
  fidelity_warnings      : list[str]   human-readable warnings for the UI
  fidelity_checked       : bool        whether the check actually ran
"""

from __future__ import annotations
import json
import re
import config


# ─── Thresholds ───────────────────────────────────────────────────────────────

FIDELITY_GOOD       = 0.85   # ≥ 85 %  → green, no warning
FIDELITY_ACCEPTABLE = 0.65   # ≥ 65 %  → amber warning
# < 65 %  → red warning, block or flag prominently


# ─── Public entry point ───────────────────────────────────────────────────────

def verify_diagram_fidelity(
    image_b64: str,
    image_type: str,
    extracted_spec: dict,
    client=None,
) -> dict:
    """
    Verify that extracted_spec faithfully represents what is in the diagram image.

    Args:
        image_b64:      Base64-encoded diagram image.
        image_type:     MIME type, e.g. 'image/png'.
        extracted_spec: The JSON spec produced by the vision model.
        client:         OpenAI client (may be None; Gemini used by default).

    Returns:
        Fidelity report dict (see module docstring for fields).
    """
    llm_ran = False
    if config.MOCK_LLM or (client is None and not config.GEMINI_API_KEY):
        report = _mock_fidelity(extracted_spec)
    else:
        try:
            if config.GEMINI_API_KEY:
                report = _gemini_fidelity(image_b64, image_type, extracted_spec)
            else:
                report = _openai_fidelity(image_b64, image_type, extracted_spec, client)
            llm_ran = True
        except Exception as exc:
            print(f"[DiagramFidelity] LLM check failed ({exc}), using structural check.")
            report = _mock_fidelity(extracted_spec)

    # ── Always enrich with verdict + human-readable warnings ──────────────────
    report["fidelity_checked"] = llm_ran
    score = report.get("fidelity_score", 0.0) or 0.0
    if score >= FIDELITY_GOOD:
        report["fidelity_verdict"] = "good"
    elif score >= FIDELITY_ACCEPTABLE:
        report["fidelity_verdict"] = "acceptable"
    else:
        report["fidelity_verdict"] = "poor"

    # Build human-readable warnings for the UI
    warnings = []
    for elem in report.get("missed_elements", []):
        warnings.append(f"Diagram element not captured in spec: \"{elem}\"")
    for elem in report.get("ambiguous_elements", []):
        warnings.append(f"Possibly misinterpreted: \"{elem}\"")
    if score < FIDELITY_ACCEPTABLE:
        warnings.insert(0, f"Low fidelity ({score:.0%}) — review spec carefully before generating code.")
    report["fidelity_warnings"] = warnings
    return report


# ─── Gemini vision judge ──────────────────────────────────────────────────────

_FIDELITY_SYSTEM = """\
You are an expert PLC requirements analyst verifying the accuracy of an automated
diagram-to-specification extraction.

You will be shown:
1. A workflow/P&ID diagram image.
2. The structured JSON spec extracted from it by an AI vision model.

Your task:
- Identify every input sensor, output actuator, decision box, process step,
  safety interlock, timer, and annotation visible in the diagram.
- For each element, check whether it appears correctly in the extracted spec.
- Report elements that are MISSING (visible in diagram, absent from spec)
  and elements that are AMBIGUOUS (captured but possibly mislabelled/mistyped).

Respond ONLY with a single valid JSON object:
{
  "fidelity_score": <float 0.0-1.0>,
  "elements_visible": <int — total countable elements in diagram>,
  "elements_captured": <int — elements correctly in spec>,
  "missed_elements": ["description of each missed element"],
  "ambiguous_elements": ["description of each ambiguous element"],
  "summary": "one sentence overall assessment"
}
"""

def _gemini_fidelity(image_b64: str, image_type: str, spec: dict) -> dict:
    import google.generativeai as genai
    import base64
    genai.configure(api_key=config.GEMINI_API_KEY)
    model = genai.GenerativeModel(config.GEMINI_MODEL)

    spec_json = json.dumps(spec, indent=2)
    image_bytes = base64.b64decode(image_b64)

    import google.generativeai.types as types
    resp = model.generate_content(
        [
            _FIDELITY_SYSTEM,
            types.Part.from_bytes(data=image_bytes, mime_type=image_type),
            f"\n=== EXTRACTED SPEC ===\n{spec_json}\n\nPlease verify fidelity.",
        ],
        generation_config={"temperature": 0.1, "max_output_tokens": 2048},
    )
    raw = resp.text.strip()
    return json.loads(_strip_fences(raw))


def _openai_fidelity(image_b64: str, image_type: str, spec: dict, client) -> dict:
    spec_json = json.dumps(spec, indent=2)
    resp = client.chat.completions.create(
        model=config.LLM_MODEL,
        messages=[
            {"role": "system", "content": _FIDELITY_SYSTEM},
            {"role": "user", "content": [
                {"type": "image_url", "image_url": {
                    "url": f"data:{image_type};base64,{image_b64}", "detail": "high"
                }},
                {"type": "text", "text": f"=== EXTRACTED SPEC ===\n{spec_json}\n\nPlease verify fidelity."},
            ]},
        ],
        temperature=0.1,
        response_format={"type": "json_object"},
        max_tokens=2048,
    )
    raw = resp.choices[0].message.content.strip()
    return json.loads(_strip_fences(raw))


# ─── Mock / structural check (MOCK_LLM or no API key) ────────────────────────

def _mock_fidelity(spec: dict) -> dict:
    """
    Structural sanity checks on the extracted spec — no image re-analysis.
    Flags common extraction failure patterns:
      • No inputs extracted
      • No outputs extracted
      • Fewer than 2 control conditions
      • Any variable name is generic (e.g. INPUT_1, OUTPUT_1)
    """
    issues = []
    inputs  = spec.get("inputs", [])
    outputs = spec.get("outputs", [])
    conds   = spec.get("control_conditions", [])
    interlocks = spec.get("interlocks", [])

    if not inputs:
        issues.append("No inputs were extracted — check diagram for sensor labels")
    if not outputs:
        issues.append("No outputs were extracted — check diagram for actuator labels")
    if len(conds) < 2:
        issues.append("Fewer than 2 control conditions extracted — diagram may have more decision branches")
    if not interlocks:
        issues.append("No interlocks/safety conditions found — check if diagram has E-STOP or safety paths")

    # Detect suspiciously generic names
    generic_re = re.compile(r"^(INPUT|OUTPUT|VAR|SENSOR|ACTUATOR)_?\d+$", re.IGNORECASE)
    for v in inputs + outputs:
        if generic_re.match(v.get("name", "")):
            issues.append(f"Generic variable name detected: {v['name']} — extraction may have failed to read label")

    # Score: start at 1.0, deduct per issue
    deduction_per_issue = 0.15
    score = max(0.0, round(1.0 - len(issues) * deduction_per_issue, 4))

    total = len(inputs) + len(outputs) + len(conds)
    captured = total - len(issues) if total else 0

    return {
        "fidelity_score":     score,
        "elements_visible":   total,
        "elements_captured":  max(0, captured),
        "missed_elements":    issues,
        "ambiguous_elements": [],
        "summary":            "Structural check only (no image re-analysis in mock mode).",
        "fidelity_checked":   False,  # will be overwritten by caller if LLM ran
    }


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        lines = lines[1:] if lines[0].startswith("```") else lines
        lines = lines[:-1] if lines and lines[-1].startswith("```") else lines
        text = "\n".join(lines)
    return text


def fidelity_badge(report: dict) -> dict:
    """Return a dict suitable for JSON response enrichment."""
    verdict = report.get("fidelity_verdict", "unknown")
    score   = report.get("fidelity_score", 0.0)
    color_map = {"good": "success", "acceptable": "warning", "poor": "danger", "unknown": "secondary"}
    return {
        "fidelity_score":   score,
        "fidelity_verdict": verdict,
        "fidelity_color":   color_map.get(verdict, "secondary"),
        "fidelity_label":   f"{score:.0%} fidelity",
        "fidelity_warnings": report.get("fidelity_warnings", []),
        "missed_elements":   report.get("missed_elements", []),
        "ambiguous_elements": report.get("ambiguous_elements", []),
    }
