"""
RQ2 Support: Logical Inconsistency Detector
Identifies structural and logical inconsistencies in normalized
requirement specifications before they propagate into generated code.

Checks performed:
  1. Variables used in conditions but not declared as inputs/outputs/internals
  2. Output variables never assigned in any control condition
  3. Safety constraints not reflected in any control condition
  4. Conflicting control conditions (same output set to TRUE and FALSE unconditionally)
  5. Missing safety-critical variable declarations (E_STOP, OVERLOAD patterns)
"""

import re


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _all_variable_names(req: dict) -> set:
    """Collect every declared variable name from the requirement dict."""
    names = set()
    for section in ("inputs", "outputs", "internal_variables", "timers", "counters"):
        for var in req.get(section, []):
            names.add(var["name"].upper())
    return names


def _variables_in_text(text: str) -> set:
    """Extract word tokens that look like variable names from a string."""
    tokens = re.findall(r"\b([A-Z][A-Z0-9_]*)\b", text.upper())
    # Filter out ST keywords
    keywords = {
        "IF", "THEN", "ELSE", "ELSIF", "END_IF", "WHILE", "FOR", "DO",
        "TO", "BY", "END_FOR", "END_WHILE", "AND", "OR", "NOT", "TRUE",
        "FALSE", "BOOL", "INT", "REAL", "TIME", "TON", "TOF", "TP",
        "CTU", "CTD", "HIGH", "LOW", "START", "STOP", "SWITCH",
        # Common FB parameter names that should not be treated as variables.
        "IN", "PT", "Q", "ET", "CU", "CD", "R", "PV", "CV", "RESET"
    }
    return {t for t in tokens if t not in keywords and len(t) > 1}


def _extract_predicate_text(condition_text: str) -> str:
    """Return only the IF/ELSIF predicate (before THEN) when present."""
    text_upper = condition_text.upper()
    if "THEN" in text_upper and ("IF" in text_upper or "ELSIF" in text_upper):
        return text_upper.split("THEN", 1)[0]
    return text_upper


# ─── Individual Checks ───────────────────────────────────────────────────────

def _check_undeclared_variables(req: dict) -> list:
    """Variables referenced in conditions that are not declared anywhere."""
    declared = _all_variable_names(req)
    issues = []
    for cond in req.get("control_conditions", []):
        used = _variables_in_text(_extract_predicate_text(cond["condition"]))
        undeclared = used - declared
        for var in sorted(undeclared):
            issues.append(
                f"Variable '{var}' used in condition but not declared: "
                f"\"{cond['condition'][:60]}\""
            )
    return issues


def _check_unassigned_outputs(req: dict) -> list:
    """Output variables that never appear on the left-hand side of any condition."""
    outputs = {v["name"].upper() for v in req.get("outputs", [])}
    assigned = set()
    for cond in req.get("control_conditions", []):
        # Match   VARNAME :=   pattern
        lhs_matches = re.findall(r"\b(\w+)\s*:=", cond["condition"].upper())
        assigned.update(lhs_matches)
    # Also check description text
    desc = req.get("description", "").upper()
    issues = []
    for out in sorted(outputs):
        if out not in assigned:
            issues.append(
                f"Output '{out}' is declared but never assigned in any control condition."
            )
    return issues


def _check_safety_not_reflected(req: dict) -> list:
    """Safety constraints that share no variable names with any control condition."""
    issues = []
    cond_text = " ".join(
        c["condition"] for c in req.get("control_conditions", [])
    ).upper()
    for constraint in req.get("safety_constraints", []):
        vars_in_constraint = _variables_in_text(constraint)
        vars_in_conditions = _variables_in_text(cond_text)
        overlap = vars_in_constraint & vars_in_conditions
        if not overlap:
            issues.append(
                f"Safety constraint not reflected in any control condition: "
                f"\"{constraint[:80]}\""
            )
    return issues


def _check_conflicting_assignments(req: dict) -> list:
    """Outputs unconditionally set to both TRUE and FALSE across different conditions."""
    assignments: dict[str, set] = {}
    for cond in req.get("control_conditions", []):
        text = cond["condition"].upper()
        # Simple unconditional check — no IF keyword
        if "IF" not in text:
            for m in re.finditer(r"\b(\w+)\s*:=\s*(TRUE|FALSE)\b", text):
                var, val = m.group(1), m.group(2)
                assignments.setdefault(var, set()).add(val)

    issues = []
    for var, vals in assignments.items():
        if "TRUE" in vals and "FALSE" in vals:
            issues.append(
                f"Conflicting unconditional assignments: '{var}' is set to "
                f"both TRUE and FALSE across conditions."
            )
    return issues


def _check_missing_safety_variables(req: dict) -> list:
    """Warn if raw requirement mentions safety keywords but nothing is declared."""
    raw = req.get("description", "") + " ".join(
        req.get("safety_constraints", [])
    )
    raw_upper = raw.upper()
    declared = _all_variable_names(req)
    issues = []

    safety_patterns = [
        ("EMERGENCY STOP", ["E_STOP", "ESTOP", "EMERGENCY"]),
        ("OVERLOAD", ["OVERLOAD", "OL", "FAULT"]),
        ("LIMIT SWITCH", ["LSP", "LSN", "LIMIT"]),
    ]
    for label, expected_vars in safety_patterns:
        if label in raw_upper:
            if not any(ev in declared for ev in expected_vars):
                issues.append(
                    f"Requirement mentions '{label}' but no matching "
                    f"variable ({', '.join(expected_vars)}) is declared."
                )
    return issues


# ─── Public API ───────────────────────────────────────────────────────────────

def detect_inconsistencies(normalized_req: dict) -> dict:
    """
    Run all inconsistency checks on a normalized requirement dict.

    Args:
        normalized_req: The structured requirement dictionary.

    Returns:
        Dict with 'count' (int) and 'issues' (list of str).
    """
    issues = []
    issues.extend(_check_undeclared_variables(normalized_req))
    issues.extend(_check_unassigned_outputs(normalized_req))
    issues.extend(_check_safety_not_reflected(normalized_req))
    issues.extend(_check_conflicting_assignments(normalized_req))
    issues.extend(_check_missing_safety_variables(normalized_req))

    return {
        "count": len(issues),
        "issues": issues
    }


def compare_raw_vs_normalized(raw_text: str, normalized_req: dict) -> dict:
    """
    Compare raw requirement text against the normalized spec to identify
    concepts mentioned in the raw text that were dropped or changed.

    Args:
        raw_text: The original informal requirement string.
        normalized_req: The structured requirement dictionary.

    Returns:
        Dict with 'dropped_concepts' and 'count'.
    """
    raw_upper = raw_text.upper()
    declared  = {v["name"].upper() for section in ("inputs", "outputs", "internal_variables", "timers", "counters")
                 for v in normalized_req.get(section, [])}
    cond_text = " ".join(c["condition"] for c in normalized_req.get("control_conditions", []))

    # Key industrial concepts that should make it into the spec if mentioned
    concept_keywords = {
        "EMERGENCY STOP": ["E_STOP", "ESTOP"],
        "OVERLOAD": ["OVERLOAD", "OL"],
        "ALARM": ["ALARM", "ALERT"],
        "TIMER": ["TIMER", "TON", "TOF"],
        "COUNTER": ["COUNTER", "CTU", "CTD"],
        "ANALOG": ["ANALOG", "REAL", "SETPOINT"],
        "SENSOR": ["SENSOR", "LEVEL", "TEMP", "PRESS"],
    }

    dropped = []
    for concept, keywords in concept_keywords.items():
        if concept in raw_upper:
            found_in_spec = any(
                kw in " ".join([
                    cond_text,
                    str(normalized_req.get("inputs", [])),
                    str(normalized_req.get("outputs", [])),
                    str(normalized_req.get("internal_variables", [])),
                    str(normalized_req.get("timers", [])),
                    str(normalized_req.get("counters", []))
                ]).upper()
                for kw in keywords
            )
            if not found_in_spec:
                dropped.append(
                    f"Concept '{concept}' appears in raw requirement but "
                    f"is not reflected in the normalized specification."
                )

    return {
        "count": len(dropped),
        "dropped_concepts": dropped
    }
