"""
RAG (Retrieval-Augmented Generation) module for the LLM-Assisted PLC Framework.

Provides two retrieval modes:
  1. Analysis retrieval  — find similar tasks to improve requirement categorisation.
  2. Code-gen retrieval  — find similar solved tasks and inject their ST code as
                           few-shot examples inside the generation prompt.

Storage backend:
  • ChromaDB (persisted on disk) with OpenAI text-embedding-3-small when an API
    key is available.
  • Pure-Python TF-IDF cosine similarity when MOCK_LLM=true or chromadb is not
    installed — no extra dependencies required.
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any, Optional


# ─── TF-IDF fallback (no extra dependencies) ─────────────────────────────────

class _TFIDFIndex:
    """Lightweight TF-IDF retriever over a list of text documents."""

    def __init__(self) -> None:
        self._docs: list[dict] = []          # {"text": ..., "meta": ...}
        self._tfidf: list[dict[str, float]] = []
        self._idf: dict[str, float] = {}

    # ── Tokenisation ──────────────────────────────────────────────────────────

    @staticmethod
    def _tokenise(text: str) -> list[str]:
        return re.findall(r"\b[a-z_][a-z0-9_]{1,}\b", text.lower())

    # ── Index building ────────────────────────────────────────────────────────

    def add(self, text: str, meta: dict) -> None:
        self._docs.append({"text": text, "meta": meta})

    def build(self) -> None:
        """Compute TF-IDF vectors for all added documents."""
        N = len(self._docs)
        if N == 0:
            return

        # Document frequency counts
        df: dict[str, int] = {}
        all_tf: list[dict[str, float]] = []

        for doc in self._docs:
            tokens = self._tokenise(doc["text"])
            tf: dict[str, float] = {}
            for t in tokens:
                tf[t] = tf.get(t, 0) + 1
            total = len(tokens) or 1
            tf = {t: c / total for t, c in tf.items()}
            all_tf.append(tf)
            for t in tf:
                df[t] = df.get(t, 0) + 1

        # IDF
        self._idf = {t: math.log(N / (df[t] + 1) + 1) for t in df}

        # TF-IDF vectors
        self._tfidf = [
            {t: tf_val * self._idf.get(t, 0) for t, tf_val in tf.items()}
            for tf in all_tf
        ]

    def query(self, text: str, k: int = 3) -> list[dict]:
        """Return top-k most similar document metas."""
        if not self._docs:
            return []
        q_tokens = self._tokenise(text)
        total = len(q_tokens) or 1
        q_tf: dict[str, float] = {}
        for t in q_tokens:
            q_tf[t] = q_tf.get(t, 0) + 1
        q_vec = {t: (c / total) * self._idf.get(t, 0) for t, c in q_tf.items()}

        def _dot(a: dict, b: dict) -> float:
            return sum(a.get(t, 0) * b.get(t, 0) for t in a)

        def _norm(v: dict) -> float:
            return math.sqrt(sum(x ** 2 for x in v.values())) or 1e-9

        scores = [
            _dot(q_vec, dv) / (_norm(q_vec) * _norm(dv))
            for dv in self._tfidf
        ]
        top = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:k]
        return [
            {"score": scores[i], **self._docs[i]["meta"]}
            for i in top
            if scores[i] > 0.01           # ignore near-zero similarity
        ]


# ─── Main retriever ───────────────────────────────────────────────────────────

class RagRetriever:
    """
    Wraps either ChromaDB (real mode) or TF-IDF (mock/fallback mode).

    Usage:
        rag = RagRetriever(benchmark_dir="data/benchmark_tasks",
                           persist_dir="data/rag_store",
                           openai_client=client)   # or None for mock
        rag.index_tasks()                           # build index once

        # During analysis
        similar = rag.query_analysis("control 3 motors with SIMOCODE", k=3)

        # During code generation
        examples = rag.codegen_context("motor with estop and timer", k=2)
    """

    # ── Init ──────────────────────────────────────────────────────────────────

    def __init__(
        self,
        benchmark_dir: str | Path,
        persist_dir: str | Path,
        openai_client=None,
        use_chroma: bool = True,
    ) -> None:
        self.benchmark_dir = Path(benchmark_dir)
        self.persist_dir   = Path(persist_dir)
        self._oclient      = openai_client          # openai.OpenAI | None
        self._chroma_col   = None                   # chromadb collection | None
        self._tfidf        = _TFIDFIndex()
        self._tasks: list[dict] = []
        self._indexed      = False

        if use_chroma:
            self._chroma_col = self._init_chroma()

    def _init_chroma(self):
        """Try to initialise a persistent ChromaDB collection.  Returns None on failure."""
        try:
            import chromadb  # type: ignore
            from chromadb.utils import embedding_functions  # type: ignore

            self.persist_dir.mkdir(parents=True, exist_ok=True)
            chroma_client = chromadb.PersistentClient(path=str(self.persist_dir))

            if self._oclient is not None:
                # Use OpenAI text-embedding-3-small (fast, cheap)
                import config as _cfg
                ef = embedding_functions.OpenAIEmbeddingFunction(
                    api_key=_cfg.OPENAI_API_KEY,
                    model_name="text-embedding-3-small",
                )
            else:
                # Sentence-transformers built-in default (all-MiniLM-L6-v2)
                ef = embedding_functions.DefaultEmbeddingFunction()

            col = chroma_client.get_or_create_collection(
                name="plc_tasks",
                embedding_function=ef,
                metadata={"hnsw:space": "cosine"},
            )
            print("[RAG] ChromaDB collection ready.")
            return col

        except Exception as exc:
            print(f"[RAG] ChromaDB unavailable ({exc}), using TF-IDF fallback.")
            return None

    # ── Text helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _task_embed_text(task: dict) -> str:
        """Build a rich plain-text representation of a task for embedding."""
        nr = task.get("normalized_requirement", {})
        parts = [
            task.get("raw_requirement", ""),
            nr.get("description", ""),
            nr.get("system_name", ""),
        ]
        parts += [i["name"] + " " + i.get("description", "")
                  for i in nr.get("inputs", [])]
        parts += [o["name"] + " " + o.get("description", "")
                  for o in nr.get("outputs", [])]
        parts += [c.get("condition", "") for c in nr.get("control_conditions", [])]
        parts += nr.get("safety_constraints", [])
        return " ".join(p for p in parts if p).strip()

    @staticmethod
    def _task_analysis_snippet(task: dict) -> str:
        """Short structured snippet used as analysis RAG context."""
        nr  = task.get("normalized_requirement", {})
        tid = task.get("task_id", "unknown")
        lines = [f"# Similar task: {tid}  (complexity: {task.get('complexity','?')})"]
        lines.append(f"# {nr.get('description','')}")
        lines.append("Inputs:  " + ", ".join(
            f"{i['name']}:{i['type']}" for i in nr.get("inputs", [])))
        lines.append("Outputs: " + ", ".join(
            f"{o['name']}:{o['type']}" for o in nr.get("outputs", [])))
        loco = nr.get("internal_variables", [])
        if loco:
            lines.append("Internal: " + ", ".join(
                f"{v['name']}:{v['type']}" for v in loco))
        interlocks = nr.get("safety_constraints", [])
        if interlocks:
            lines.append("Interlocks: " + "; ".join(interlocks[:3]))
        return "\n".join(lines)

    @staticmethod
    def _codegen_example(task: dict) -> str:
        """Format a retrieved task as a labelled few-shot code example."""
        nr  = task.get("normalized_requirement", {})
        tid = task.get("task_id", "unknown")
        st  = task.get("reference_st_code", "").strip()
        if not st:
            return ""
        from src.normalizer import format_for_prompt  # local to avoid circular
        req_str = format_for_prompt(nr)
        return (
            f"=== EXAMPLE TASK: {tid} ===\n"
            f"REQUIREMENT:\n{req_str}\n\n"
            f"CORRECT ST CODE:\n```\n{st}\n```\n"
            f"=== END EXAMPLE ==="
        )

    # ── Indexing ──────────────────────────────────────────────────────────────

    def index_tasks(self, force: bool = False) -> int:
        """
        Load all benchmark tasks and build the search index.
        Skips tasks without reference_st_code (no code example to retrieve).

        Args:
            force: Rebuild even if the ChromaDB collection already has items.

        Returns:
            Number of tasks indexed.
        """
        self._tasks = []
        for p in sorted(self.benchmark_dir.glob("*.json")):
            try:
                t = json.loads(p.read_text(encoding="utf-8"))
                self._tasks.append(t)
            except Exception:
                pass

        if self._chroma_col is not None:
            # ChromaDB path
            existing = self._chroma_col.count()
            if existing > 0 and not force:
                print(f"[RAG] ChromaDB already has {existing} documents — skipping re-index.")
                self._indexed = True
                return existing

            if force and existing > 0:
                ids = self._chroma_col.get()["ids"]
                if ids:
                    self._chroma_col.delete(ids=ids)

            ids, texts, metas = [], [], []
            for t in self._tasks:
                tid   = t.get("task_id", "")
                embed = self._task_embed_text(t)
                if not embed:
                    continue
                ids.append(tid)
                texts.append(embed)
                metas.append({
                    "task_id":    tid,
                    "complexity": t.get("complexity", ""),
                    "has_ref_st": bool(t.get("reference_st_code", "")),
                })

            if ids:
                self._chroma_col.add(documents=texts, ids=ids, metadatas=metas)
                print(f"[RAG] ChromaDB indexed {len(ids)} tasks.")

            self._indexed = True
            return len(ids)

        else:
            # TF-IDF fallback path
            self._tfidf = _TFIDFIndex()
            count = 0
            for t in self._tasks:
                embed = self._task_embed_text(t)
                if not embed:
                    continue
                self._tfidf.add(embed, meta={"task_id": t.get("task_id", "")})
                count += 1
            self._tfidf.build()
            print(f"[RAG] TF-IDF index built with {count} tasks.")
            self._indexed = True
            return count

    def _ensure_indexed(self) -> None:
        if not self._indexed:
            self.index_tasks()

    def _task_by_id(self, task_id: str) -> Optional[dict]:
        for t in self._tasks:
            if t.get("task_id") == task_id:
                return t
        return None

    # ── Retrieval ─────────────────────────────────────────────────────────────

    def query_analysis(self, raw_req: str, k: int = 3) -> list[dict]:
        """
        Find the k most similar benchmark tasks to the raw requirement text.

        Returns:
            List of task dicts from the benchmark, ordered by similarity.
        """
        self._ensure_indexed()
        if self._chroma_col is not None:
            try:
                res = self._chroma_col.query(
                    query_texts=[raw_req],
                    n_results=min(k, self._chroma_col.count()),
                )
                ids = res["ids"][0] if res["ids"] else []
                return [t for tid in ids for t in [self._task_by_id(tid)] if t]
            except Exception as exc:
                print(f"[RAG] ChromaDB query error: {exc}; falling back to TF-IDF.")

        # TF-IDF
        hits = self._tfidf.query(raw_req, k=k)
        return [t for h in hits for t in [self._task_by_id(h["task_id"])] if t]

    def codegen_context(self, req_str: str, k: int = 2) -> str:
        """
        Build a few-shot context string for the code generation prompt.
        Only includes tasks that have reference_st_code.

        Returns:
            A formatted string ready to be injected into the prompt, or ""
            if no relevant examples were found.
        """
        self._ensure_indexed()
        tasks = self.query_analysis(req_str, k=k + 2)   # fetch extra in case some lack ref code
        examples = []
        for t in tasks:
            if not t.get("reference_st_code", ""):
                continue
            ex = self._codegen_example(t)
            if ex:
                examples.append(ex)
            if len(examples) >= k:
                break

        if not examples:
            return ""

        sep = "\n" + "-" * 60 + "\n"
        return (
            "The following are SOLVED similar tasks. "
            "Study them carefully before writing the new program.\n\n"
            + sep.join(examples)
        )

    def analysis_context(self, raw_req: str, k: int = 3) -> str:
        """
        Build a context string for the requirement analysis prompt listing
        similar tasks' I/O structures.

        Returns:
            Formatted multi-line string, or "".
        """
        self._ensure_indexed()
        tasks = self.query_analysis(raw_req, k=k)

        snippets = []
        for t in tasks:
            s = self._task_analysis_snippet(t)
            if s:
                snippets.append(s)

        if not snippets:
            return ""

        return (
            "The following previously solved tasks are similar to this requirement.\n"
            "Use them as reference for naming variables and structuring I/O:\n\n"
            + "\n\n".join(snippets)
        )
