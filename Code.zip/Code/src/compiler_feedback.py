"""
Phase 3: Compiler-Guided Validation and Iterative Refinement
Compiles Structured Text programs using OpenPLC and feeds errors
back to the LLM for iterative correction.
"""

import re
import subprocess
import tempfile
import openai
from pathlib import Path


REFINEMENT_PROMPT = """
The following IEC 61131-3 Structured Text program failed to compile.

--- CURRENT CODE ---
{current_code}

--- COMPILER ERRORS ---
{errors}

Fix ONLY the errors listed above. Do not change the program logic.
Return the corrected complete program. Output code only, no explanation.
"""


def compile_with_openplc(st_code: str, compiler_path: str = "matiec") -> dict:
    """
    Compile Structured Text code using the matiec/OpenPLC compiler.

    Args:
        st_code: The ST program string.
        compiler_path: Path or command for the IEC 61131-3 compiler.

    Returns:
        Dictionary with 'success' (bool), 'errors' (list of str), 'raw_stderr'.
    """
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".st", delete=False, encoding="utf-8"
    ) as tmp:
        tmp.write(st_code)
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            [compiler_path, tmp_path],
            capture_output=True,
            text=True,
            timeout=30
        )
        stderr = result.stderr + result.stdout
        errors = _parse_error_output(stderr)
        return {
            "success": result.returncode == 0 and len(errors) == 0,
            "errors": errors,
            "raw_stderr": stderr
        }
    except FileNotFoundError:
        # Compiler not found — use syntax-only heuristic check as fallback
        print("[Compiler] WARNING: Compiler not found, using heuristic syntax check.")
        errors = _heuristic_syntax_check(st_code)
        return {
            "success": len(errors) == 0,
            "errors": errors,
            "raw_stderr": "Compiler not available; heuristic check used."
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "errors": ["Compilation timed out."],
            "raw_stderr": "Timeout"
        }
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def _parse_error_output(stderr: str) -> list:
    """
    Parse compiler stderr/stdout into a list of error messages.
    Handles matiec and OpenPLC error formats.
    
    Args:
        stderr: Raw compiler output string.
        
    Returns:
        List of error message strings.
    """
    errors = []
    for line in stderr.splitlines():
        line = line.strip()
        # Match patterns like: "file.st:12:5: error: ..."
        if re.search(r"(error|warning|undefined|undeclared|syntax)", line, re.IGNORECASE):
            errors.append(line)
    return errors


def _heuristic_syntax_check(st_code: str) -> list:
    """
    Fallback heuristic check for common IEC 61131-3 ST syntax issues
    when the compiler is not available.
    
    Args:
        st_code: The ST program string.
        
    Returns:
        List of detected issue strings.
    """
    errors = []

    # Remove common comment/prose noise before token checks.
    # This avoids false positives from words like "for" in explanatory text.
    code_wo_block_comments = re.sub(r"\(\*.*?\*\)", " ", st_code, flags=re.DOTALL)
    code_lines = []
    for ln in code_wo_block_comments.splitlines():
        line = re.sub(r"//.*$", "", ln).strip()
        if not line:
            continue
        # Ignore obvious prose headings accidentally emitted by LLMs.
        if line.upper().startswith("LAYER ") or line.upper().startswith("PHASE "):
            continue
        code_lines.append(line)
    code_upper = "\n".join(code_lines).upper()

    if "PROGRAM" not in code_upper:
        errors.append("Missing PROGRAM declaration.")
    if "END_PROGRAM" not in code_upper:
        errors.append("Missing END_PROGRAM.")
    if "VAR" in code_upper and "END_VAR" not in code_upper:
        errors.append("VAR block not closed with END_VAR.")

    # Count standalone IF/FOR keywords (not ELSIF, not END_IF/END_FOR).
    if_count    = len(re.findall(r'\bIF\b',      code_upper))
    endif_count = len(re.findall(r'\bEND_IF\b',  code_upper))
    for_count   = len(re.findall(r'\bFOR\b',     code_upper))
    endfor_count= len(re.findall(r'\bEND_FOR\b', code_upper))

    if if_count != endif_count:
        errors.append(f"Mismatched IF / END_IF blocks ({if_count} IF vs {endif_count} END_IF).")
    if for_count != endfor_count:
        errors.append(f"Mismatched FOR / END_FOR blocks ({for_count} FOR vs {endfor_count} END_FOR).")

    # Flag invalid ST token that appears in many LLM outputs.
    if re.search(r"\bELSE\s+IF\b", code_upper):
        errors.append("Use ELSIF instead of 'ELSE IF' in IEC ST.")

    # Placeholder prose often sneaks into model outputs and must be rejected.
    if "..." in st_code:
        errors.append("Placeholder '...' detected; program is incomplete.")

    return errors


def fix_with_llm(
    current_code: str,
    errors: list,
    client: openai.OpenAI,
    model: str = "gpt-4"
) -> str:
    """
    Ask the LLM to fix compilation errors in the given ST code.

    Args:
        current_code: The ST program with errors.
        errors: List of compiler error strings.
        client: Authenticated OpenAI client.
        model: LLM model to use.

    Returns:
        Corrected ST code string.
    """
    errors_str = "\n".join(errors)
    prompt = REFINEMENT_PROMPT.format(current_code=current_code, errors=errors_str)

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1
        )
    except openai.APIConnectionError as e:
        if "CERTIFICATE_VERIFY_FAILED" in str(e) or "SSL" in str(e):
            # Corporate proxy — retry once with SSL verification disabled
            print("[Compiler] SSL error during LLM fix — retrying with verify=False.")
            import httpx as _httpx
            _ssl_client = type(client)(
                api_key=client.api_key,
                http_client=_httpx.Client(verify=False)
            )
            response = _ssl_client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1
            )
        else:
            raise

    raw = response.choices[0].message.content.strip()

    # Strip markdown fences if present
    if "```" in raw:
        parts = raw.split("```")
        raw = parts[1]
        if "\n" in raw:
            first_line, rest = raw.split("\n", 1)
            if first_line.strip().lower() in ("st", "iecst", "structured_text"):
                return rest.strip()
    return raw.strip()


def refine_until_compiled(
    st_code: str,
    client: openai.OpenAI,
    max_iterations: int = 5,
    compiler_path: str = "matiec",
    model: str = "gpt-4",
    interactive: bool = True
) -> dict:
    """
    Iteratively compile and fix ST code until it compiles or max iterations reached.

    Args:
        st_code: Initial ST code to refine.
        client: Authenticated OpenAI client.
        max_iterations: Maximum number of refinement cycles.
        compiler_path: Path or command for the IEC 61131-3 compiler.
        model: LLM model to use.

    Returns:
        Dictionary with:
            - 'final_code': last code version
            - 'success': whether it compiled successfully
            - 'iterations': number of cycles used
            - 'iteration_log': list of per-iteration details
    """
    iteration_log = []
    current_code = st_code

    for i in range(max_iterations):
        result = compile_with_openplc(current_code, compiler_path)

        iteration_log.append({
            "iteration": i + 1,
            "success": result["success"],
            "error_count": len(result["errors"]),
            "errors": result["errors"]
        })

        status_msg = "SUCCESS" if result["success"] else f"{len(result['errors'])} error(s)"
        print(f"[Compiler] Iteration {i+1}: {status_msg}")

        if result["success"]:
            return {
                "final_code": current_code,
                "success": True,
                "iterations": i + 1,
                "iteration_log": iteration_log
            }

        # In MOCK mode skip LLM refinement — errors cannot be fixed without API
        import config as _cfg
        if _cfg.MOCK_LLM or client is None:
            print("[Compiler] MOCK mode — skipping LLM fix, accepting code as-is.")
            return {
                "final_code": current_code,
                "success": False,
                "iterations": i + 1,
                "iteration_log": iteration_log
            }

        # Feed errors back to LLM
        current_code = fix_with_llm(current_code, result["errors"], client, model)

    # Max iterations reached without successful compilation.
    # Offer human-in-the-loop correction if running interactively.
    if interactive:
        import sys
        if sys.stdin.isatty():
            last_errors = iteration_log[-1]["errors"] if iteration_log else []
            current_code = prompt_human_correction(current_code, last_errors)

    return {
        "final_code": current_code,
        "success": False,
        "iterations": max_iterations,
        "iteration_log": iteration_log
    }


def prompt_human_correction(current_code: str, errors: list) -> str:
    """
    Human-in-the-loop fallback when the LLM cannot resolve errors within
    the iteration limit. Displays the failing code and errors, then waits
    for the engineer to paste a corrected version.

    Args:
        current_code: The last failing ST code.
        errors: List of remaining compiler error strings.

    Returns:
        Corrected code string (either human-supplied or original if skipped).
    """
    print("\n" + "=" * 60)
    print("[Human-in-the-Loop] Automated refinement reached iteration limit.")
    print(f"  Remaining errors ({len(errors)}):")
    for e in errors:
        print(f"    • {e}")
    print("\n  Current code:\n")
    print(current_code)
    print("=" * 60)
    print("\nOptions:")
    print("  1. Paste corrected code (type END on a new line when done)")
    print("  2. Press Enter to skip and save as-is")
    choice = input("\nYour choice: ").strip()
    if not choice:
        print("[Human-in-the-Loop] Skipped — saving code as-is.")
        return current_code
    lines = []
    print("Paste corrected code (type END on a new line to finish):")
    while True:
        line = input()
        if line.strip().upper() == "END":
            break
        lines.append(line)
    corrected = "\n".join(lines).strip()
    return corrected if corrected else current_code
